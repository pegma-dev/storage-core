const { NODE_ACCOUNT_ID_ENDPOINT_MODE_CONFIG_OPTIONS, resolveAccountIdEndpointModeConfig } = require("@aws-sdk/core/account-id-endpoint");
const { awsEndpointFunctions, emitWarningIfUnsupportedVersion: emitWarningIfUnsupportedVersion$1, createDefaultUserAgentProvider, NODE_APP_ID_CONFIG_OPTIONS, getAwsRegionExtensionConfiguration, resolveAwsRegionExtensionConfiguration, resolveUserAgentConfig, resolveHostHeaderConfig, getUserAgentPlugin, getHostHeaderPlugin, getLoggerPlugin, getRecursionDetectionPlugin } = require("@aws-sdk/core/client");
const { NODE_ENDPOINT_DISCOVERY_CONFIG_OPTIONS, resolveEndpointDiscoveryConfig } = require("@aws-sdk/middleware-endpoint-discovery");
const { getHttpAuthSchemeEndpointRuleSetPlugin, DefaultIdentityProviderConfig, getHttpSigningPlugin, createPaginator } = require("@smithy/core");
const { normalizeProvider, getSmithyContext, makeBuilder, ServiceException, NoOpLogger, emitWarningIfUnsupportedVersion, loadConfigsForDefaultMode, getDefaultExtensionConfiguration, resolveDefaultRuntimeConfig, Client, createWaiter, checkExceptions, WaiterState, createAggregatedClient } = require("@smithy/core/client");
const { Command: $Command } = require("@smithy/core/client");
exports.$Command = $Command;
exports.__Client = Client;
const { resolveDefaultsModeConfig, loadConfig, NODE_USE_FIPS_ENDPOINT_CONFIG_OPTIONS, NODE_USE_DUALSTACK_ENDPOINT_CONFIG_OPTIONS, NODE_REGION_CONFIG_OPTIONS, NODE_REGION_CONFIG_FILE_OPTIONS, resolveRegionConfig } = require("@smithy/core/config");
const { getEndpointPlugin, BinaryDecisionDiagram, EndpointCache, decideEndpoint, customEndpointFunctions, resolveEndpointConfig } = require("@smithy/core/endpoints");
const { parseUrl, getHttpHandlerExtensionConfiguration, resolveHttpHandlerRuntimeConfig, getContentLengthPlugin } = require("@smithy/core/protocols");
const { DEFAULT_RETRY_MODE, NODE_RETRY_MODE_CONFIG_OPTIONS, NODE_MAX_ATTEMPT_CONFIG_OPTIONS, Retry, resolveRetryConfig, getRetryPlugin } = require("@smithy/core/retry");
const { TypeRegistry, getSchemaSerdePlugin } = require("@smithy/core/schema");
const { resolveAwsSdkSigV4Config, AwsSdkSigV4Signer, NODE_AUTH_SCHEME_PREFERENCE_OPTIONS } = require("@aws-sdk/core/httpAuthSchemes");
const { defaultProvider } = require("@aws-sdk/credential-provider-node");
const { toUtf8, fromUtf8, toBase64, fromBase64, calculateBodyLength } = require("@smithy/core/serde");
const { streamCollector, NodeHttpHandler } = require("@smithy/node-http-handler");
const { AwsJson1_0Protocol } = require("@aws-sdk/core/protocols");
const { DynamoDBJsonCodec2 } = require("@aws-sdk/dynamodb-codec");
const { Sha256 } = require("@smithy/core/checksum");

const defaultDynamoDBHttpAuthSchemeParametersProvider = async (config, context, input) => {
    return {
        operation: getSmithyContext(context).operation,
        region: await normalizeProvider(config.region)() || (() => {
            throw new Error("expected `region` to be configured for `aws.auth#sigv4`");
        })(),
    };
};
function createAwsAuthSigv4HttpAuthOption(authParameters) {
    return {
        schemeId: "aws.auth#sigv4",
        signingProperties: {
            name: "dynamodb",
            region: authParameters.region,
        },
        propertiesExtractor: (config, context) => ({
            signingProperties: {
                config,
                context,
            },
        }),
    };
}
const defaultDynamoDBHttpAuthSchemeProvider = (authParameters) => {
    const options = [];
    switch (authParameters.operation) {
        default: {
            options.push(createAwsAuthSigv4HttpAuthOption(authParameters));
        }
    }
    return options;
};
const resolveHttpAuthSchemeConfig = (config) => {
    const config_0 = resolveAwsSdkSigV4Config(config);
    return Object.assign(config_0, {
        authSchemePreference: normalizeProvider(config.authSchemePreference ?? []),
    });
};

const resolveClientEndpointParameters = (options) => {
    return Object.assign(options, {
        useDualstackEndpoint: options.useDualstackEndpoint ?? false,
        useFipsEndpoint: options.useFipsEndpoint ?? false,
        defaultSigningName: "dynamodb",
    });
};
const commonParams = {
    UseFIPS: { type: "builtInParams", name: "useFipsEndpoint" },
    AccountId: { type: "builtInParams", name: "accountId" },
    Endpoint: { type: "builtInParams", name: "endpoint" },
    Region: { type: "builtInParams", name: "region" },
    UseDualStack: { type: "builtInParams", name: "useDualstackEndpoint" },
    AccountIdEndpointMode: { type: "builtInParams", name: "accountIdEndpointMode" },
};

const command = makeBuilder(commonParams, "DynamoDB_20120810", "DynamoDBClient", getEndpointPlugin);
const _ep0 = {};
const _ep1 = {
    ResourceArnList: { type: "operationContextParams", get: (input) => Object.keys(input?.RequestItems ?? {}) },
};
const _ep2 = {
    ResourceArn: { type: "contextParams", name: "TableName" },
};
const _ep3 = {
    ResourceArn: { type: "contextParams", name: "GlobalTableName" },
};
const _ep4 = {
    ResourceArn: { type: "contextParams", name: "BackupArn" },
};
const _ep5 = {
    ResourceArn: { type: "contextParams", name: "ResourceArn" },
};
const _ep6 = {
    ResourceArn: { type: "contextParams", name: "ExportArn" },
};
const _ep7 = {
    ResourceArn: { type: "contextParams", name: "ImportArn" },
};
const _ep8 = {
    ResourceArn: { type: "contextParams", name: "TableArn" },
};
const _ep9 = {
    ResourceArn: { type: "operationContextParams", get: (input) => input?.TableCreationParameters?.TableName },
};
const _ep10 = {
    ResourceArn: { type: "contextParams", name: "TargetTableName" },
};
const _ep11 = {
    IsSearchOperation: { type: "staticContextParams", value: true },
    ResourceArn: { type: "contextParams", name: "TableName" },
};
const _ep12 = {
    ResourceArnList: { type: "operationContextParams", get: (input) => input?.TransactItems?.map((obj) => obj?.Get?.TableName) },
};
const _ep13 = {
    ResourceArnList: { type: "operationContextParams", get: (input) => input?.TransactItems?.map((obj) => [obj?.ConditionCheck?.TableName, obj?.Put?.TableName, obj?.Delete?.TableName, obj?.Update?.TableName].filter((i) => i)).flat() },
};
const _mw0 = (Command, cs, config, o) => [];

class DynamoDBServiceException extends ServiceException {
    constructor(options) {
        super(options);
        Object.setPrototypeOf(this, DynamoDBServiceException.prototype);
    }
}

class BackupInUseException extends DynamoDBServiceException {
    name = "BackupInUseException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "BackupInUseException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, BackupInUseException.prototype);
    }
}
class BackupNotFoundException extends DynamoDBServiceException {
    name = "BackupNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "BackupNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, BackupNotFoundException.prototype);
    }
}
class InternalServerError extends DynamoDBServiceException {
    name = "InternalServerError";
    $fault = "server";
    constructor(opts) {
        super({
            name: "InternalServerError",
            $fault: "server",
            ...opts,
        });
        Object.setPrototypeOf(this, InternalServerError.prototype);
    }
}
class RequestLimitExceeded extends DynamoDBServiceException {
    name = "RequestLimitExceeded";
    $fault = "client";
    ThrottlingReasons;
    constructor(opts) {
        super({
            name: "RequestLimitExceeded",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, RequestLimitExceeded.prototype);
        this.ThrottlingReasons = opts.ThrottlingReasons;
    }
}
class ThrottlingException extends DynamoDBServiceException {
    name = "ThrottlingException";
    $fault = "client";
    throttlingReasons;
    constructor(opts) {
        super({
            name: "ThrottlingException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ThrottlingException.prototype);
        this.throttlingReasons = opts.throttlingReasons;
    }
}
class InvalidEndpointException extends DynamoDBServiceException {
    name = "InvalidEndpointException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidEndpointException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidEndpointException.prototype);
        this.Message = opts.Message;
    }
}
class ProvisionedThroughputExceededException extends DynamoDBServiceException {
    name = "ProvisionedThroughputExceededException";
    $fault = "client";
    ThrottlingReasons;
    constructor(opts) {
        super({
            name: "ProvisionedThroughputExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ProvisionedThroughputExceededException.prototype);
        this.ThrottlingReasons = opts.ThrottlingReasons;
    }
}
class ResourceNotFoundException extends DynamoDBServiceException {
    name = "ResourceNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ResourceNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceNotFoundException.prototype);
    }
}
class ItemCollectionSizeLimitExceededException extends DynamoDBServiceException {
    name = "ItemCollectionSizeLimitExceededException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ItemCollectionSizeLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ItemCollectionSizeLimitExceededException.prototype);
    }
}
class ReplicatedWriteConflictException extends DynamoDBServiceException {
    name = "ReplicatedWriteConflictException";
    $fault = "client";
    $retryable = {};
    constructor(opts) {
        super({
            name: "ReplicatedWriteConflictException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ReplicatedWriteConflictException.prototype);
    }
}
class ContinuousBackupsUnavailableException extends DynamoDBServiceException {
    name = "ContinuousBackupsUnavailableException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ContinuousBackupsUnavailableException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ContinuousBackupsUnavailableException.prototype);
    }
}
class LimitExceededException extends DynamoDBServiceException {
    name = "LimitExceededException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "LimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, LimitExceededException.prototype);
    }
}
class TableInUseException extends DynamoDBServiceException {
    name = "TableInUseException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "TableInUseException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TableInUseException.prototype);
    }
}
class TableNotFoundException extends DynamoDBServiceException {
    name = "TableNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "TableNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TableNotFoundException.prototype);
    }
}
class GlobalTableAlreadyExistsException extends DynamoDBServiceException {
    name = "GlobalTableAlreadyExistsException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "GlobalTableAlreadyExistsException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, GlobalTableAlreadyExistsException.prototype);
    }
}
class ResourceInUseException extends DynamoDBServiceException {
    name = "ResourceInUseException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ResourceInUseException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceInUseException.prototype);
    }
}
class TransactionConflictException extends DynamoDBServiceException {
    name = "TransactionConflictException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "TransactionConflictException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TransactionConflictException.prototype);
    }
}
class PolicyNotFoundException extends DynamoDBServiceException {
    name = "PolicyNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "PolicyNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, PolicyNotFoundException.prototype);
    }
}
class ExportNotFoundException extends DynamoDBServiceException {
    name = "ExportNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ExportNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ExportNotFoundException.prototype);
    }
}
class GlobalTableNotFoundException extends DynamoDBServiceException {
    name = "GlobalTableNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "GlobalTableNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, GlobalTableNotFoundException.prototype);
    }
}
class ImportNotFoundException extends DynamoDBServiceException {
    name = "ImportNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ImportNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ImportNotFoundException.prototype);
    }
}
class DuplicateItemException extends DynamoDBServiceException {
    name = "DuplicateItemException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "DuplicateItemException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, DuplicateItemException.prototype);
    }
}
class IdempotentParameterMismatchException extends DynamoDBServiceException {
    name = "IdempotentParameterMismatchException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "IdempotentParameterMismatchException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, IdempotentParameterMismatchException.prototype);
        this.Message = opts.Message;
    }
}
class TransactionInProgressException extends DynamoDBServiceException {
    name = "TransactionInProgressException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "TransactionInProgressException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TransactionInProgressException.prototype);
        this.Message = opts.Message;
    }
}
class ExportConflictException extends DynamoDBServiceException {
    name = "ExportConflictException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ExportConflictException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ExportConflictException.prototype);
    }
}
class InvalidExportTimeException extends DynamoDBServiceException {
    name = "InvalidExportTimeException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidExportTimeException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidExportTimeException.prototype);
    }
}
class PointInTimeRecoveryUnavailableException extends DynamoDBServiceException {
    name = "PointInTimeRecoveryUnavailableException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "PointInTimeRecoveryUnavailableException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, PointInTimeRecoveryUnavailableException.prototype);
    }
}
class ImportConflictException extends DynamoDBServiceException {
    name = "ImportConflictException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ImportConflictException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ImportConflictException.prototype);
    }
}
class TableAlreadyExistsException extends DynamoDBServiceException {
    name = "TableAlreadyExistsException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "TableAlreadyExistsException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TableAlreadyExistsException.prototype);
    }
}
class InvalidRestoreTimeException extends DynamoDBServiceException {
    name = "InvalidRestoreTimeException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidRestoreTimeException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidRestoreTimeException.prototype);
    }
}
class ReplicaAlreadyExistsException extends DynamoDBServiceException {
    name = "ReplicaAlreadyExistsException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ReplicaAlreadyExistsException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ReplicaAlreadyExistsException.prototype);
    }
}
class ReplicaNotFoundException extends DynamoDBServiceException {
    name = "ReplicaNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ReplicaNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ReplicaNotFoundException.prototype);
    }
}
class IndexNotFoundException extends DynamoDBServiceException {
    name = "IndexNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "IndexNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, IndexNotFoundException.prototype);
    }
}
class ConditionalCheckFailedException extends DynamoDBServiceException {
    name = "ConditionalCheckFailedException";
    $fault = "client";
    Item;
    constructor(opts) {
        super({
            name: "ConditionalCheckFailedException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ConditionalCheckFailedException.prototype);
        this.Item = opts.Item;
    }
}
class TransactionCanceledException extends DynamoDBServiceException {
    name = "TransactionCanceledException";
    $fault = "client";
    Message;
    CancellationReasons;
    constructor(opts) {
        super({
            name: "TransactionCanceledException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TransactionCanceledException.prototype);
        this.Message = opts.Message;
        this.CancellationReasons = opts.CancellationReasons;
    }
}

const _A = "Action";
const _ABA = "ArchivalBackupArn";
const _ACDTP = "ApproximateCreationDateTimePrecision";
const _AD = "AttributeDefinition";
const _ADT = "ArchivalDateTime";
const _ADt = "AttributeDefinitions";
const _AM = "AttributeMap";
const _AMRCU = "AccountMaxReadCapacityUnits";
const _AMWCU = "AccountMaxWriteCapacityUnits";
const _AN = "AttributeName";
const _AR = "ArchivalReason";
const _AS = "ArchivalSummary";
const _ASD = "AutoScalingDisabled";
const _ASPD = "AutoScalingPolicyDescription";
const _ASPDL = "AutoScalingPolicyDescriptionList";
const _ASPU = "AutoScalingPolicyUpdate";
const _ASRA = "AutoScalingRoleArn";
const _ASSD = "AutoScalingSettingsDescription";
const _ASSU = "AutoScalingSettingsUpdate";
const _ASTTSPCD = "AutoScalingTargetTrackingScalingPolicyConfigurationDescription";
const _ASTTSPCU = "AutoScalingTargetTrackingScalingPolicyConfigurationUpdate";
const _AT = "AttributeType";
const _ATG = "AttributesToGet";
const _AU = "AttributeUpdates";
const _AV = "AttributeValue";
const _AVL = "AttributeValueList";
const _AVU = "AttributeValueUpdate";
const _Ad = "Address";
const _At = "Attributes";
const _B = "Backfilling";
const _BA = "BackupArn";
const _BCDT = "BackupCreationDateTime";
const _BD = "BackupDescription";
const _BDa = "BackupDetails";
const _BEDT = "BackupExpiryDateTime";
const _BES = "BatchExecuteStatement";
const _BESI = "BatchExecuteStatementInput";
const _BESO = "BatchExecuteStatementOutput";
const _BGI = "BatchGetItem";
const _BGII = "BatchGetItemInput";
const _BGIO = "BatchGetItemOutput";
const _BGRM = "BatchGetResponseMap";
const _BGRMa = "BatchGetRequestMap";
const _BIUE = "BackupInUseException";
const _BM = "BillingMode";
const _BMO = "BillingModeOverride";
const _BMS = "BillingModeSummary";
const _BN = "BackupName";
const _BNFE = "BackupNotFoundException";
const _BOOL = "BOOL";
const _BS = "BackupStatus";
const _BSB = "BackupSizeBytes";
const _BSBi = "BilledSizeBytes";
const _BSE = "BatchStatementError";
const _BSR = "BatchStatementRequest";
const _BSRa = "BatchStatementResponse";
const _BS_ = "BS";
const _BSa = "BackupSummary";
const _BSac = "BackupSummaries";
const _BT = "BackupType";
const _BWI = "BatchWriteItem";
const _BWII = "BatchWriteItemInput";
const _BWIO = "BatchWriteItemOutput";
const _BWIRM = "BatchWriteItemRequestMap";
const _B_ = "B";
const _C = "Code";
const _CB = "CreateBackup";
const _CBD = "ContinuousBackupsDescription";
const _CBI = "CreateBackupInput";
const _CBO = "CreateBackupOutput";
const _CBS = "ContinuousBackupsStatus";
const _CBUE = "ContinuousBackupsUnavailableException";
const _CC = "ConsumedCapacity";
const _CCFE = "ConditionalCheckFailedException";
const _CCM = "ConsumedCapacityMultiple";
const _CCo = "ConditionCheck";
const _CDT = "CreationDateTime";
const _CE = "ConditionExpression";
const _CGSIA = "CreateGlobalSecondaryIndexAction";
const _CGT = "CreateGlobalTable";
const _CGTI = "CreateGlobalTableInput";
const _CGTO = "CreateGlobalTableOutput";
const _CGTWGMA = "CreateGlobalTableWitnessGroupMemberAction";
const _CIA = "ContributorInsightsAction";
const _CIM = "ContributorInsightsMode";
const _CIRL = "ContributorInsightsRuleList";
const _CIS = "ContributorInsightsSummary";
const _CISo = "ContributorInsightsStatus";
const _CISon = "ContributorInsightsSummaries";
const _CO = "ComparisonOperator";
const _COo = "ConditionalOperator";
const _COs = "CsvOptions";
const _CPIM = "CachePeriodInMinutes";
const _CR = "CancellationReasons";
const _CRA = "CreateReplicaAction";
const _CRGMA = "CreateReplicationGroupMemberAction";
const _CRL = "CancellationReasonList";
const _CRSRA = "ConfirmRemoveSelfResourceAccess";
const _CRT = "ClientRequestToken";
const _CRa = "CancellationReason";
const _CRo = "ConsistentRead";
const _CT = "ClientToken";
const _CTI = "CreateTableInput";
const _CTO = "CreateTableOutput";
const _CTr = "CreateTable";
const _CU = "CapacityUnits";
const _CVIA = "CreateVectorIndexAction";
const _CWLGA = "CloudWatchLogGroupArn";
const _Ca = "Capacity";
const _Co = "Condition";
const _Cou = "Count";
const _Cr = "Create";
const _Cs = "Csv";
const _D = "Dimensions";
const _DB = "DeleteBackup";
const _DBI = "DeleteBackupInput";
const _DBIe = "DescribeBackupInput";
const _DBO = "DeleteBackupOutput";
const _DBOe = "DescribeBackupOutput";
const _DBe = "DescribeBackup";
const _DCB = "DescribeContinuousBackups";
const _DCBI = "DescribeContinuousBackupsInput";
const _DCBO = "DescribeContinuousBackupsOutput";
const _DCI = "DescribeContributorInsights";
const _DCII = "DescribeContributorInsightsInput";
const _DCIO = "DescribeContributorInsightsOutput";
const _DE = "DescribeEndpoints";
const _DEI = "DescribeExportInput";
const _DEO = "DescribeExportOutput";
const _DER = "DescribeEndpointsRequest";
const _DERe = "DescribeEndpointsResponse";
const _DEe = "DescribeExport";
const _DF = "DistanceFunction";
const _DGSIA = "DeleteGlobalSecondaryIndexAction";
const _DGT = "DescribeGlobalTable";
const _DGTI = "DescribeGlobalTableInput";
const _DGTO = "DescribeGlobalTableOutput";
const _DGTS = "DescribeGlobalTableSettings";
const _DGTSI = "DescribeGlobalTableSettingsInput";
const _DGTSO = "DescribeGlobalTableSettingsOutput";
const _DGTWGMA = "DeleteGlobalTableWitnessGroupMemberAction";
const _DI = "DeleteItem";
const _DIE = "DuplicateItemException";
const _DII = "DeleteItemInput";
const _DIIe = "DescribeImportInput";
const _DIO = "DeleteItemOutput";
const _DIOe = "DescribeImportOutput";
const _DIe = "DescribeImport";
const _DKSD = "DescribeKinesisStreamingDestination";
const _DKSDI = "DescribeKinesisStreamingDestinationInput";
const _DKSDO = "DescribeKinesisStreamingDestinationOutput";
const _DKSDi = "DisableKinesisStreamingDestination";
const _DL = "DescribeLimits";
const _DLI = "DescribeLimitsInput";
const _DLO = "DescribeLimitsOutput";
const _DPE = "DeletionProtectionEnabled";
const _DR = "DeleteRequest";
const _DRA = "DeleteReplicaAction";
const _DRGMA = "DeleteReplicationGroupMemberAction";
const _DRP = "DeleteResourcePolicy";
const _DRPI = "DeleteResourcePolicyInput";
const _DRPO = "DeleteResourcePolicyOutput";
const _DS = "DestinationStatus";
const _DSD = "DestinationStatusDescription";
const _DSI = "DisableScaleIn";
const _DT = "DeleteTable";
const _DTI = "DeleteTableInput";
const _DTIe = "DescribeTableInput";
const _DTO = "DeleteTableOutput";
const _DTOe = "DescribeTableOutput";
const _DTRAS = "DescribeTableReplicaAutoScaling";
const _DTRASI = "DescribeTableReplicaAutoScalingInput";
const _DTRASO = "DescribeTableReplicaAutoScalingOutput";
const _DTTL = "DescribeTimeToLive";
const _DTTLI = "DescribeTimeToLiveInput";
const _DTTLO = "DescribeTimeToLiveOutput";
const _DTe = "DescribeTable";
const _DVIA = "DeleteVectorIndexAction";
const _De = "Delimiter";
const _Del = "Delete";
const _E = "Error";
const _EA = "ExportArn";
const _EAM = "ExpectedAttributeMap";
const _EAN = "ExpressionAttributeNames";
const _EAV = "ExpressionAttributeValues";
const _EAVM = "ExpressionAttributeValueMap";
const _EAVx = "ExpectedAttributeValue";
const _EC = "ErrorCount";
const _ECE = "ExportConflictException";
const _ED = "ExportDescription";
const _EDx = "ExceptionDescription";
const _EF = "ExportFormat";
const _EFT = "ExportFromTime";
const _EKSC = "EnableKinesisStreamingConfiguration";
const _EKSD = "EnableKinesisStreamingDestination";
const _EM = "ExportManifest";
const _EN = "ExceptionName";
const _ENFE = "ExportNotFoundException";
const _ERDT = "EarliestRestorableDateTime";
const _ERI = "ExpectedRevisionId";
const _ES = "ExportStatus";
const _ESBA = "ExclusiveStartBackupArn";
const _ESGTN = "ExclusiveStartGlobalTableName";
const _ESI = "ExecuteStatementInput";
const _ESK = "ExclusiveStartKey";
const _ESO = "ExecuteStatementOutput";
const _ESTN = "ExclusiveStartTableName";
const _ESx = "ExportSummary";
const _ESxe = "ExecuteStatement";
const _ESxp = "ExportSummaries";
const _ET = "EndTime";
const _ETI = "ExecuteTransactionInput";
const _ETO = "ExecuteTransactionOutput";
const _ETT = "ExportToTime";
const _ETTPIT = "ExportTableToPointInTime";
const _ETTPITI = "ExportTableToPointInTimeInput";
const _ETTPITO = "ExportTableToPointInTimeOutput";
const _ETx = "ExportTime";
const _ETxe = "ExecuteTransaction";
const _ETxp = "ExportType";
const _EVT = "ExportViewType";
const _En = "Endpoints";
const _Ena = "Enabled";
const _End = "Endpoint";
const _Ex = "Expected";
const _Exi = "Exists";
const _FC = "FailureCode";
const _FCM = "FilterConditionMap";
const _FE = "FailureException";
const _FEi = "FilterExpression";
const _FM = "FailureMessage";
const _G = "Get";
const _GI = "GetItem";
const _GII = "GetItemInput";
const _GIO = "GetItemOutput";
const _GRP = "GetResourcePolicy";
const _GRPI = "GetResourcePolicyInput";
const _GRPO = "GetResourcePolicyOutput";
const _GSI = "GlobalSecondaryIndexes";
const _GSIASU = "GlobalSecondaryIndexAutoScalingUpdate";
const _GSIASUL = "GlobalSecondaryIndexAutoScalingUpdateList";
const _GSID = "GlobalSecondaryIndexDescription";
const _GSIDL = "GlobalSecondaryIndexDescriptionList";
const _GSII = "GlobalSecondaryIndexInfo";
const _GSIL = "GlobalSecondaryIndexList";
const _GSIO = "GlobalSecondaryIndexOverride";
const _GSIU = "GlobalSecondaryIndexUpdate";
const _GSIUL = "GlobalSecondaryIndexUpdateList";
const _GSIUl = "GlobalSecondaryIndexUpdates";
const _GSIWTD = "GlobalSecondaryIndexWarmThroughputDescription";
const _GSIl = "GlobalSecondaryIndex";
const _GT = "GlobalTable";
const _GTA = "GlobalTableArn";
const _GTAEE = "GlobalTableAlreadyExistsException";
const _GTBM = "GlobalTableBillingMode";
const _GTD = "GlobalTableDescription";
const _GTGSISU = "GlobalTableGlobalSecondaryIndexSettingsUpdate";
const _GTGSISUL = "GlobalTableGlobalSecondaryIndexSettingsUpdateList";
const _GTL = "GlobalTableList";
const _GTN = "GlobalTableName";
const _GTNFE = "GlobalTableNotFoundException";
const _GTPWCASSU = "GlobalTableProvisionedWriteCapacityAutoScalingSettingsUpdate";
const _GTPWCU = "GlobalTableProvisionedWriteCapacityUnits";
const _GTS = "GlobalTableStatus";
const _GTSA = "GlobalTableSourceArn";
const _GTSRM = "GlobalTableSettingsReplicationMode";
const _GTV = "GlobalTableVersion";
const _GTW = "GlobalTableWitnesses";
const _GTWD = "GlobalTableWitnessDescription";
const _GTWDL = "GlobalTableWitnessDescriptionList";
const _GTWGU = "GlobalTableWitnessGroupUpdate";
const _GTWGUL = "GlobalTableWitnessGroupUpdateList";
const _GTWU = "GlobalTableWitnessUpdates";
const _GTl = "GlobalTables";
const _HL = "HeaderList";
const _I = "Item";
const _IA = "ImportArn";
const _IAn = "IndexArn";
const _IC = "ItemCount";
const _ICE = "ImportConflictException";
const _ICK = "ItemCollectionKey";
const _ICKAM = "ItemCollectionKeyAttributeMap";
const _ICM = "ItemCollectionMetrics";
const _ICMM = "ItemCollectionMetricsMultiple";
const _ICMPT = "ItemCollectionMetricsPerTable";
const _ICSLEE = "ItemCollectionSizeLimitExceededException";
const _ICT = "InputCompressionType";
const _IEDT = "InaccessibleEncryptionDateTime";
const _IEE = "InvalidEndpointException";
const _IES = "IncrementalExportSpecification";
const _IETE = "InvalidExportTimeException";
const _IF = "InputFormat";
const _IFO = "InputFormatOptions";
const _IIC = "ImportedItemCount";
const _IL = "ItemList";
const _IN = "IndexName";
const _INFE = "ImportNotFoundException";
const _INFEn = "IndexNotFoundException";
const _IPME = "IdempotentParameterMismatchException";
const _IR = "ItemResponse";
const _IRL = "ItemResponseList";
const _IRTE = "InvalidRestoreTimeException";
const _IS = "IndexStatus";
const _ISB = "IndexSizeBytes";
const _ISE = "InternalServerError";
const _ISL = "ImportSummaryList";
const _ISm = "ImportSummary";
const _ISmp = "ImportStatus";
const _IT = "ImportTable";
const _ITD = "ImportTableDescription";
const _ITI = "ImportTableInput";
const _ITO = "ImportTableOutput";
const _It = "Items";
const _K = "Key";
const _KAA = "KeysAndAttributes";
const _KC = "KeyConditions";
const _KCE = "KeyConditionExpression";
const _KDSD = "KinesisDataStreamDestinations";
const _KDSDi = "KinesisDataStreamDestination";
const _KL = "KeyList";
const _KMSMKA = "KMSMasterKeyArn";
const _KMSMKI = "KMSMasterKeyId";
const _KS = "KeySchema";
const _KSDI = "KinesisStreamingDestinationInput";
const _KSDO = "KinesisStreamingDestinationOutput";
const _KSE = "KeySchemaElement";
const _KT = "KeyType";
const _Ke = "Keys";
const _L = "Limit";
const _LAV = "ListAttributeValue";
const _LB = "ListBackups";
const _LBI = "ListBackupsInput";
const _LBO = "ListBackupsOutput";
const _LCI = "ListContributorInsights";
const _LCII = "ListContributorInsightsInput";
const _LCIO = "ListContributorInsightsOutput";
const _LDDT = "LastDecreaseDateTime";
const _LE = "ListExports";
const _LEBA = "LastEvaluatedBackupArn";
const _LEE = "LimitExceededException";
const _LEGTN = "LastEvaluatedGlobalTableName";
const _LEI = "ListExportsInput";
const _LEK = "LastEvaluatedKey";
const _LEO = "ListExportsOutput";
const _LETN = "LastEvaluatedTableName";
const _LGT = "ListGlobalTables";
const _LGTI = "ListGlobalTablesInput";
const _LGTO = "ListGlobalTablesOutput";
const _LI = "ListImports";
const _LIDT = "LastIncreaseDateTime";
const _LII = "ListImportsInput";
const _LIO = "ListImportsOutput";
const _LRDT = "LatestRestorableDateTime";
const _LSA = "LatestStreamArn";
const _LSI = "LocalSecondaryIndexes";
const _LSID = "LocalSecondaryIndexDescription";
const _LSIDL = "LocalSecondaryIndexDescriptionList";
const _LSII = "LocalSecondaryIndexInfo";
const _LSIL = "LocalSecondaryIndexList";
const _LSIO = "LocalSecondaryIndexOverride";
const _LSIo = "LocalSecondaryIndex";
const _LSL = "LatestStreamLabel";
const _LT = "ListTables";
const _LTI = "ListTablesInput";
const _LTO = "ListTablesOutput";
const _LTOR = "ListTagsOfResource";
const _LTORI = "ListTagsOfResourceInput";
const _LTORO = "ListTagsOfResourceOutput";
const _LUDT = "LastUpdateDateTime";
const _LUTPPRDT = "LastUpdateToPayPerRequestDateTime";
const _L_ = "L";
const _M = "Message";
const _MAV = "MapAttributeValue";
const _MR = "MaxResults";
const _MRC = "MultiRegionConsistency";
const _MRRU = "MaxReadRequestUnits";
const _MU = "MinimumUnits";
const _MUa = "MaximumUnits";
const _MWRU = "MaxWriteRequestUnits";
const _M_ = "M";
const _N = "N";
const _NKA = "NonKeyAttributes";
const _NODT = "NumberOfDecreasesToday";
const _NS = "NS";
const _NT = "NextToken";
const _NULL = "NULL";
const _ODT = "OnDemandThroughput";
const _ODTO = "OnDemandThroughputOverride";
const _P = "Parameters";
const _PE = "ProjectionExpression";
const _PI = "PutItem";
const _PIC = "ProcessedItemCount";
const _PII = "PutItemInput";
const _PIIAM = "PutItemInputAttributeMap";
const _PIO = "PutItemOutput";
const _PITRD = "PointInTimeRecoveryDescription";
const _PITRE = "PointInTimeRecoveryEnabled";
const _PITRS = "PointInTimeRecoveryStatus";
const _PITRSo = "PointInTimeRecoverySpecification";
const _PITRUE = "PointInTimeRecoveryUnavailableException";
const _PN = "PolicyName";
const _PNFE = "PolicyNotFoundException";
const _PQLBR = "PartiQLBatchRequest";
const _PQLBRa = "PartiQLBatchResponse";
const _PR = "PutRequest";
const _PRCASS = "ProvisionedReadCapacityAutoScalingSettings";
const _PRCASSU = "ProvisionedReadCapacityAutoScalingSettingsUpdate";
const _PRCASU = "ProvisionedReadCapacityAutoScalingUpdate";
const _PRCU = "ProvisionedReadCapacityUnits";
const _PRP = "PutResourcePolicy";
const _PRPI = "PutResourcePolicyInput";
const _PRPO = "PutResourcePolicyOutput";
const _PS = "PageSize";
const _PSB = "ProcessedSizeBytes";
const _PSP = "PreparedStatementParameters";
const _PSa = "ParameterizedStatement";
const _PSar = "ParameterizedStatements";
const _PT = "ProvisionedThroughput";
const _PTD = "ProvisionedThroughputDescription";
const _PTEE = "ProvisionedThroughputExceededException";
const _PTO = "ProvisionedThroughputOverride";
const _PTr = "ProjectionType";
const _PWCASS = "ProvisionedWriteCapacityAutoScalingSettings";
const _PWCASSU = "ProvisionedWriteCapacityAutoScalingSettingsUpdate";
const _PWCASU = "ProvisionedWriteCapacityAutoScalingUpdate";
const _PWCU = "ProvisionedWriteCapacityUnits";
const _Po = "Policy";
const _Pr = "Projection";
const _Pu = "Put";
const _Q = "Query";
const _QF = "QueryFilter";
const _QI = "QueryInput";
const _QO = "QueryOutput";
const _R = "Responses";
const _RA = "ResourceArn";
const _RAEE = "ReplicaAlreadyExistsException";
const _RASD = "ReplicaAutoScalingDescription";
const _RASDL = "ReplicaAutoScalingDescriptionList";
const _RASU = "ReplicaAutoScalingUpdate";
const _RASUL = "ReplicaAutoScalingUpdateList";
const _RAe = "ReplicaArn";
const _RBMS = "ReplicaBillingModeSummary";
const _RCC = "ReturnConsumedCapacity";
const _RCU = "ReadCapacityUnits";
const _RD = "ReplicaDescription";
const _RDL = "ReplicaDescriptionList";
const _RDT = "RestoreDateTime";
const _RG = "ReplicationGroup";
const _RGSI = "ReplicaGlobalSecondaryIndex";
const _RGSIASD = "ReplicaGlobalSecondaryIndexAutoScalingDescription";
const _RGSIASDL = "ReplicaGlobalSecondaryIndexAutoScalingDescriptionList";
const _RGSIASU = "ReplicaGlobalSecondaryIndexAutoScalingUpdate";
const _RGSIASUL = "ReplicaGlobalSecondaryIndexAutoScalingUpdateList";
const _RGSID = "ReplicaGlobalSecondaryIndexDescription";
const _RGSIDL = "ReplicaGlobalSecondaryIndexDescriptionList";
const _RGSIL = "ReplicaGlobalSecondaryIndexList";
const _RGSIS = "ReplicaGlobalSecondaryIndexSettings";
const _RGSISD = "ReplicaGlobalSecondaryIndexSettingsDescription";
const _RGSISDL = "ReplicaGlobalSecondaryIndexSettingsDescriptionList";
const _RGSISU = "ReplicaGlobalSecondaryIndexSettingsUpdate";
const _RGSISUL = "ReplicaGlobalSecondaryIndexSettingsUpdateList";
const _RGSIU = "ReplicaGlobalSecondaryIndexUpdates";
const _RGU = "ReplicationGroupUpdate";
const _RGUL = "ReplicationGroupUpdateList";
const _RI = "RequestItems";
const _RICM = "ReturnItemCollectionMetrics";
const _RIDT = "ReplicaInaccessibleDateTime";
const _RIP = "RestoreInProgress";
const _RIUE = "ResourceInUseException";
const _RIe = "RevisionId";
const _RL = "ReplicaList";
const _RLE = "RequestLimitExceeded";
const _RN = "RegionName";
const _RNFE = "ReplicaNotFoundException";
const _RNFEe = "ResourceNotFoundException";
const _RP = "ResourcePolicy";
const _RPID = "RecoveryPeriodInDays";
const _RPRCASS = "ReplicaProvisionedReadCapacityAutoScalingSettings";
const _RPRCASSU = "ReplicaProvisionedReadCapacityAutoScalingSettingsUpdate";
const _RPRCASU = "ReplicaProvisionedReadCapacityAutoScalingUpdate";
const _RPRCU = "ReplicaProvisionedReadCapacityUnits";
const _RPWCASS = "ReplicaProvisionedWriteCapacityAutoScalingSettings";
const _RPWCU = "ReplicaProvisionedWriteCapacityUnits";
const _RS = "ReplicaSettings";
const _RSD = "ReplicaStatusDescription";
const _RSDL = "ReplicaSettingsDescriptionList";
const _RSDe = "ReplicaSettingsDescription";
const _RSPP = "ReplicaStatusPercentProgress";
const _RSU = "ReplicaSettingsUpdate";
const _RSUL = "ReplicaSettingsUpdateList";
const _RSe = "ReplicaStatus";
const _RSes = "RestoreSummary";
const _RTC = "ReplicaTableClass";
const _RTCS = "ReplicaTableClassSummary";
const _RTFB = "RestoreTableFromBackup";
const _RTFBI = "RestoreTableFromBackupInput";
const _RTFBO = "RestoreTableFromBackupOutput";
const _RTTPIT = "RestoreTableToPointInTime";
const _RTTPITI = "RestoreTableToPointInTimeInput";
const _RTTPITO = "RestoreTableToPointInTimeOutput";
const _RU = "ReplicaUpdate";
const _RUL = "ReplicaUpdateList";
const _RUPS = "ReadUnitsPerSecond";
const _RUe = "ReplicaUpdates";
const _RV = "ReturnValues";
const _RVOCCF = "ReturnValuesOnConditionCheckFailure";
const _RWCE = "ReplicatedWriteConflictException";
const _Re = "Replica";
const _Rep = "Replicas";
const _S = "Statements";
const _SA = "StreamArn";
const _SB = "S3Bucket";
const _SBA = "SourceBackupArn";
const _SBO = "S3BucketOwner";
const _SBS = "S3BucketSource";
const _SC = "ScannedCount";
const _SCE = "SearchConditionExpression";
const _SD = "StreamDescription";
const _SE = "StreamEnabled";
const _SERGB = "SizeEstimateRangeGB";
const _SF = "ScanFilter";
const _SI = "ScanInput";
const _SIC = "ScaleInCooldown";
const _SICM = "SecondaryIndexesCapacityMap";
const _SIF = "ScanIndexForward";
const _SKP = "S3KeyPrefix";
const _SO = "ScanOutput";
const _SOC = "ScaleOutCooldown";
const _SP = "ScalingPolicies";
const _SPU = "ScalingPolicyUpdate";
const _SPr = "S3Prefix";
const _SR = "SearchResults";
const _SRI = "SearchResultItem";
const _SRL = "SearchResultList";
const _SS = "StreamSpecification";
const _SSA = "S3SseAlgorithm";
const _SSE = "SearchSchemaElement";
const _SSED = "SSEDescription";
const _SSES = "SSESpecification";
const _SSESO = "SSESpecificationOverride";
const _SSET = "SearchSchemaElementType";
const _SSETy = "SSEType";
const _SSKKI = "S3SseKmsKeyId";
const _SS_ = "SS";
const _SSe = "SearchSchema";
const _ST = "StartTime";
const _STA = "SourceTableArn";
const _STD = "SourceTableDetails";
const _STFD = "SourceTableFeatureDetails";
const _STN = "SourceTableName";
const _SV = "SearchVector";
const _SVI = "SearchVectorsInput";
const _SVL = "SearchVectorList";
const _SVO = "SearchVectorsOutput";
const _SVT = "StreamViewType";
const _SVe = "SearchVectors";
const _S_ = "S";
const _Sc = "Score";
const _Sca = "Scan";
const _Se = "Select";
const _Seg = "Segment";
const _St = "Statement";
const _Sta = "Status";
const _T = "Table";
const _TA = "TableArn";
const _TAEE = "TableAlreadyExistsException";
const _TASD = "TableAutoScalingDescription";
const _TC = "TableClass";
const _TCDT = "TableCreationDateTime";
const _TCE = "TransactionCanceledException";
const _TCEr = "TransactionConflictException";
const _TCO = "TableClassOverride";
const _TCP = "TableCreationParameters";
const _TCS = "TableClassSummary";
const _TD = "TableDescription";
const _TE = "ThrottlingException";
const _TGI = "TransactGetItem";
const _TGII = "TransactGetItemsInput";
const _TGIL = "TransactGetItemList";
const _TGIO = "TransactGetItemsOutput";
const _TGIr = "TransactGetItems";
const _TI = "TableId";
const _TIPE = "TransactionInProgressException";
const _TIUE = "TableInUseException";
const _TIr = "TransactItems";
const _TK = "TopK";
const _TKa = "TagKeys";
const _TL = "TagList";
const _TMRCU = "TableMaxReadCapacityUnits";
const _TMWCU = "TableMaxWriteCapacityUnits";
const _TN = "TableName";
const _TNFE = "TableNotFoundException";
const _TNa = "TableNames";
const _TR = "ThrottlingReasons";
const _TRI = "TagResourceInput";
const _TRL = "ThrottlingReasonList";
const _TRLB = "TimeRangeLowerBound";
const _TRUB = "TimeRangeUpperBound";
const _TRa = "TagResource";
const _TRh = "ThrottlingReason";
const _TS = "TransactStatements";
const _TSB = "TableSizeBytes";
const _TSa = "TableStatus";
const _TSo = "TotalSegments";
const _TTLD = "TimeToLiveDescription";
const _TTLS = "TimeToLiveStatus";
const _TTLSi = "TimeToLiveSpecification";
const _TTN = "TargetTableName";
const _TTSPC = "TargetTrackingScalingPolicyConfiguration";
const _TV = "TargetValue";
const _TWI = "TransactWriteItem";
const _TWII = "TransactWriteItemsInput";
const _TWIL = "TransactWriteItemList";
const _TWIO = "TransactWriteItemsOutput";
const _TWIr = "TransactWriteItems";
const _TWTD = "TableWarmThroughputDescription";
const _Ta = "Tags";
const _Tag = "Tag";
const _U = "Update";
const _UCB = "UpdateContinuousBackups";
const _UCBI = "UpdateContinuousBackupsInput";
const _UCBO = "UpdateContinuousBackupsOutput";
const _UCI = "UpdateContributorInsights";
const _UCII = "UpdateContributorInsightsInput";
const _UCIO = "UpdateContributorInsightsOutput";
const _UE = "UpdateExpression";
const _UGSIA = "UpdateGlobalSecondaryIndexAction";
const _UGT = "UpdateGlobalTable";
const _UGTI = "UpdateGlobalTableInput";
const _UGTO = "UpdateGlobalTableOutput";
const _UGTS = "UpdateGlobalTableSettings";
const _UGTSI = "UpdateGlobalTableSettingsInput";
const _UGTSO = "UpdateGlobalTableSettingsOutput";
const _UI = "UnprocessedItems";
const _UII = "UpdateItemInput";
const _UIO = "UpdateItemOutput";
const _UIp = "UpdateItem";
const _UK = "UnprocessedKeys";
const _UKSC = "UpdateKinesisStreamingConfiguration";
const _UKSD = "UpdateKinesisStreamingDestination";
const _UKSDI = "UpdateKinesisStreamingDestinationInput";
const _UKSDO = "UpdateKinesisStreamingDestinationOutput";
const _ULRT = "UseLatestRestorableTime";
const _UR = "UntagResource";
const _URGMA = "UpdateReplicationGroupMemberAction";
const _URI = "UntagResourceInput";
const _UT = "UpdateTable";
const _UTI = "UpdateTableInput";
const _UTO = "UpdateTableOutput";
const _UTRAS = "UpdateTableReplicaAutoScaling";
const _UTRASI = "UpdateTableReplicaAutoScalingInput";
const _UTRASO = "UpdateTableReplicaAutoScalingOutput";
const _UTTL = "UpdateTimeToLive";
const _UTTLI = "UpdateTimeToLiveInput";
const _UTTLO = "UpdateTimeToLiveOutput";
const _V = "Value";
const _VA = "VectorAttribute";
const _VAD = "VectorAttributeDefinition";
const _VC = "VectorCapacity";
const _VI = "VectorIndexes";
const _VICM = "VectorIndexesCapacityMap";
const _VID = "VectorIndexDescription";
const _VIDL = "VectorIndexDescriptionList";
const _VII = "VectorIndexInfo";
const _VIL = "VectorIndexList";
const _VIO = "VectorIndexOverride";
const _VIU = "VectorIndexUpdates";
const _VIUL = "VectorIndexUpdateList";
const _VIUe = "VectorIndexUpdate";
const _VIe = "VectorIndex";
const _VSRB = "VectorSearchRequestBytes";
const _VWRB = "VectorWriteRequestBytes";
const _WCU = "WriteCapacityUnits";
const _WR = "WriteRequest";
const _WRr = "WriteRequests";
const _WS = "WitnessStatus";
const _WT = "WarmThroughput";
const _WUPS = "WriteUnitsPerSecond";
const _aQE = "awsQueryError";
const _c = "client";
const _e = "error";
const _hE = "httpError";
const _hH = "httpHeader";
const _m = "message";
const _r = "reason";
const _re = "resource";
const _s = "smithy.ts.sdk.synthetic.com.amazonaws.dynamodb";
const _se = "server";
const _tR = "throttlingReasons";
const _xacrsra = "x-amz-confirm-remove-self-resource-access";
const n0 = "com.amazonaws.dynamodb";
const _s_registry = TypeRegistry.for(_s);
var DynamoDBServiceException$ = [-3, _s, "DynamoDBServiceException", 0, [], []];
_s_registry.registerError(DynamoDBServiceException$, DynamoDBServiceException);
const n0_registry = TypeRegistry.for(n0);
var BackupInUseException$ = [-3, n0, _BIUE,
    { [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(BackupInUseException$, BackupInUseException);
var BackupNotFoundException$ = [-3, n0, _BNFE,
    { [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(BackupNotFoundException$, BackupNotFoundException);
var ConditionalCheckFailedException$ = [-3, n0, _CCFE,
    { [_e]: _c },
    [_m, _I],
    [0, () => AttributeMap]
];
n0_registry.registerError(ConditionalCheckFailedException$, ConditionalCheckFailedException);
var ContinuousBackupsUnavailableException$ = [-3, n0, _CBUE,
    { [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(ContinuousBackupsUnavailableException$, ContinuousBackupsUnavailableException);
var DuplicateItemException$ = [-3, n0, _DIE,
    { [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(DuplicateItemException$, DuplicateItemException);
var ExportConflictException$ = [-3, n0, _ECE,
    { [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(ExportConflictException$, ExportConflictException);
var ExportNotFoundException$ = [-3, n0, _ENFE,
    { [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(ExportNotFoundException$, ExportNotFoundException);
var GlobalTableAlreadyExistsException$ = [-3, n0, _GTAEE,
    { [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(GlobalTableAlreadyExistsException$, GlobalTableAlreadyExistsException);
var GlobalTableNotFoundException$ = [-3, n0, _GTNFE,
    { [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(GlobalTableNotFoundException$, GlobalTableNotFoundException);
var IdempotentParameterMismatchException$ = [-3, n0, _IPME,
    { [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(IdempotentParameterMismatchException$, IdempotentParameterMismatchException);
var ImportConflictException$ = [-3, n0, _ICE,
    { [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(ImportConflictException$, ImportConflictException);
var ImportNotFoundException$ = [-3, n0, _INFE,
    { [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(ImportNotFoundException$, ImportNotFoundException);
var IndexNotFoundException$ = [-3, n0, _INFEn,
    { [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(IndexNotFoundException$, IndexNotFoundException);
var InternalServerError$ = [-3, n0, _ISE,
    { [_e]: _se },
    [_m],
    [0]
];
n0_registry.registerError(InternalServerError$, InternalServerError);
var InvalidEndpointException$ = [-3, n0, _IEE,
    { [_e]: _c, [_hE]: 421 },
    [_M],
    [0]
];
n0_registry.registerError(InvalidEndpointException$, InvalidEndpointException);
var InvalidExportTimeException$ = [-3, n0, _IETE,
    { [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(InvalidExportTimeException$, InvalidExportTimeException);
var InvalidRestoreTimeException$ = [-3, n0, _IRTE,
    { [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(InvalidRestoreTimeException$, InvalidRestoreTimeException);
var ItemCollectionSizeLimitExceededException$ = [-3, n0, _ICSLEE,
    { [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(ItemCollectionSizeLimitExceededException$, ItemCollectionSizeLimitExceededException);
var LimitExceededException$ = [-3, n0, _LEE,
    { [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(LimitExceededException$, LimitExceededException);
var PointInTimeRecoveryUnavailableException$ = [-3, n0, _PITRUE,
    { [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(PointInTimeRecoveryUnavailableException$, PointInTimeRecoveryUnavailableException);
var PolicyNotFoundException$ = [-3, n0, _PNFE,
    { [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(PolicyNotFoundException$, PolicyNotFoundException);
var ProvisionedThroughputExceededException$ = [-3, n0, _PTEE,
    { [_e]: _c },
    [_m, _TR],
    [0, () => ThrottlingReasonList]
];
n0_registry.registerError(ProvisionedThroughputExceededException$, ProvisionedThroughputExceededException);
var ReplicaAlreadyExistsException$ = [-3, n0, _RAEE,
    { [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(ReplicaAlreadyExistsException$, ReplicaAlreadyExistsException);
var ReplicaNotFoundException$ = [-3, n0, _RNFE,
    { [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(ReplicaNotFoundException$, ReplicaNotFoundException);
var ReplicatedWriteConflictException$ = [-3, n0, _RWCE,
    { [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(ReplicatedWriteConflictException$, ReplicatedWriteConflictException);
var RequestLimitExceeded$ = [-3, n0, _RLE,
    { [_e]: _c },
    [_m, _TR],
    [0, () => ThrottlingReasonList]
];
n0_registry.registerError(RequestLimitExceeded$, RequestLimitExceeded);
var ResourceInUseException$ = [-3, n0, _RIUE,
    { [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(ResourceInUseException$, ResourceInUseException);
var ResourceNotFoundException$ = [-3, n0, _RNFEe,
    { [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(ResourceNotFoundException$, ResourceNotFoundException);
var TableAlreadyExistsException$ = [-3, n0, _TAEE,
    { [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(TableAlreadyExistsException$, TableAlreadyExistsException);
var TableInUseException$ = [-3, n0, _TIUE,
    { [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(TableInUseException$, TableInUseException);
var TableNotFoundException$ = [-3, n0, _TNFE,
    { [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(TableNotFoundException$, TableNotFoundException);
var ThrottlingException$ = [-3, n0, _TE,
    { [_aQE]: [`Throttling`, 400], [_e]: _c, [_hE]: 400 },
    [_m, _tR],
    [0, () => ThrottlingReasonList]
];
n0_registry.registerError(ThrottlingException$, ThrottlingException);
var TransactionCanceledException$ = [-3, n0, _TCE,
    { [_e]: _c },
    [_M, _CR],
    [0, () => CancellationReasonList]
];
n0_registry.registerError(TransactionCanceledException$, TransactionCanceledException);
var TransactionConflictException$ = [-3, n0, _TCEr,
    { [_e]: _c },
    [_m],
    [0]
];
n0_registry.registerError(TransactionConflictException$, TransactionConflictException);
var TransactionInProgressException$ = [-3, n0, _TIPE,
    { [_e]: _c },
    [_M],
    [0]
];
n0_registry.registerError(TransactionInProgressException$, TransactionInProgressException);
const errorTypeRegistries = [
    _s_registry,
    n0_registry,
];
var ArchivalSummary$ = [3, n0, _AS,
    0,
    [_ADT, _AR, _ABA],
    [4, 0, 0]
];
var AttributeDefinition$ = [3, n0, _AD,
    0,
    [_AN, _AT],
    [0, 0], 2
];
var AttributeValueUpdate$ = [3, n0, _AVU,
    0,
    [_V, _A],
    [() => AttributeValue$, 0]
];
var AutoScalingPolicyDescription$ = [3, n0, _ASPD,
    0,
    [_PN, _TTSPC],
    [0, () => AutoScalingTargetTrackingScalingPolicyConfigurationDescription$]
];
var AutoScalingPolicyUpdate$ = [3, n0, _ASPU,
    0,
    [_TTSPC, _PN],
    [() => AutoScalingTargetTrackingScalingPolicyConfigurationUpdate$, 0], 1
];
var AutoScalingSettingsDescription$ = [3, n0, _ASSD,
    0,
    [_MU, _MUa, _ASD, _ASRA, _SP],
    [1, 1, 2, 0, () => AutoScalingPolicyDescriptionList]
];
var AutoScalingSettingsUpdate$ = [3, n0, _ASSU,
    0,
    [_MU, _MUa, _ASD, _ASRA, _SPU],
    [1, 1, 2, 0, () => AutoScalingPolicyUpdate$]
];
var AutoScalingTargetTrackingScalingPolicyConfigurationDescription$ = [3, n0, _ASTTSPCD,
    0,
    [_TV, _DSI, _SIC, _SOC],
    [1, 2, 1, 1], 1
];
var AutoScalingTargetTrackingScalingPolicyConfigurationUpdate$ = [3, n0, _ASTTSPCU,
    0,
    [_TV, _DSI, _SIC, _SOC],
    [1, 2, 1, 1], 1
];
var BackupDescription$ = [3, n0, _BD,
    0,
    [_BDa, _STD, _STFD],
    [() => BackupDetails$, () => SourceTableDetails$, () => SourceTableFeatureDetails$]
];
var BackupDetails$ = [3, n0, _BDa,
    0,
    [_BA, _BN, _BS, _BT, _BCDT, _BSB, _BEDT],
    [0, 0, 0, 0, 4, 1, 4], 5
];
var BackupSummary$ = [3, n0, _BSa,
    0,
    [_TN, _TI, _TA, _BA, _BN, _BCDT, _BEDT, _BS, _BT, _BSB],
    [0, 0, 0, 0, 0, 4, 4, 0, 0, 1]
];
var BatchExecuteStatementInput$ = [3, n0, _BESI,
    0,
    [_S, _RCC],
    [() => PartiQLBatchRequest, 0], 1
];
var BatchExecuteStatementOutput$ = [3, n0, _BESO,
    0,
    [_R, _CC],
    [() => PartiQLBatchResponse, () => ConsumedCapacityMultiple]
];
var BatchGetItemInput$ = [3, n0, _BGII,
    0,
    [_RI, _RCC],
    [() => BatchGetRequestMap, 0], 1
];
var BatchGetItemOutput$ = [3, n0, _BGIO,
    0,
    [_R, _UK, _CC],
    [() => BatchGetResponseMap, () => BatchGetRequestMap, () => ConsumedCapacityMultiple]
];
var BatchStatementError$ = [3, n0, _BSE,
    0,
    [_C, _M, _I],
    [0, 0, () => AttributeMap]
];
var BatchStatementRequest$ = [3, n0, _BSR,
    0,
    [_St, _P, _CRo, _RVOCCF],
    [0, () => PreparedStatementParameters, 2, 0], 1
];
var BatchStatementResponse$ = [3, n0, _BSRa,
    0,
    [_E, _TN, _I],
    [() => BatchStatementError$, 0, () => AttributeMap]
];
var BatchWriteItemInput$ = [3, n0, _BWII,
    0,
    [_RI, _RCC, _RICM],
    [() => BatchWriteItemRequestMap, 0, 0], 1
];
var BatchWriteItemOutput$ = [3, n0, _BWIO,
    0,
    [_UI, _ICM, _CC],
    [() => BatchWriteItemRequestMap, () => ItemCollectionMetricsPerTable, () => ConsumedCapacityMultiple]
];
var BillingModeSummary$ = [3, n0, _BMS,
    0,
    [_BM, _LUTPPRDT],
    [0, 4]
];
var CancellationReason$ = [3, n0, _CRa,
    0,
    [_I, _C, _M],
    [() => AttributeMap, 0, 0]
];
var Capacity$ = [3, n0, _Ca,
    0,
    [_RCU, _WCU, _CU],
    [1, 1, 1]
];
var Condition$ = [3, n0, _Co,
    0,
    [_CO, _AVL],
    [0, () => AttributeValueList], 1
];
var ConditionCheck$ = [3, n0, _CCo,
    0,
    [_K, _TN, _CE, _EAN, _EAV, _RVOCCF],
    [() => Key, 0, 0, 128 | 0, () => ExpressionAttributeValueMap, 0], 3
];
var ConsumedCapacity$ = [3, n0, _CC,
    0,
    [_TN, _CU, _RCU, _WCU, _T, _LSI, _GSI, _VI],
    [0, 1, 1, 1, () => Capacity$, () => SecondaryIndexesCapacityMap, () => SecondaryIndexesCapacityMap, () => VectorIndexesCapacityMap]
];
var ContinuousBackupsDescription$ = [3, n0, _CBD,
    0,
    [_CBS, _PITRD],
    [0, () => PointInTimeRecoveryDescription$], 1
];
var ContributorInsightsSummary$ = [3, n0, _CIS,
    0,
    [_TN, _IN, _CISo, _CIM],
    [0, 0, 0, 0]
];
var CreateBackupInput$ = [3, n0, _CBI,
    0,
    [_TN, _BN],
    [0, 0], 2
];
var CreateBackupOutput$ = [3, n0, _CBO,
    0,
    [_BDa],
    [() => BackupDetails$]
];
var CreateGlobalSecondaryIndexAction$ = [3, n0, _CGSIA,
    0,
    [_IN, _KS, _Pr, _PT, _ODT, _WT],
    [0, () => KeySchema, () => Projection$, () => ProvisionedThroughput$, () => OnDemandThroughput$, () => WarmThroughput$], 3
];
var CreateGlobalTableInput$ = [3, n0, _CGTI,
    0,
    [_GTN, _RG],
    [0, () => ReplicaList], 2
];
var CreateGlobalTableOutput$ = [3, n0, _CGTO,
    0,
    [_GTD],
    [() => GlobalTableDescription$]
];
var CreateGlobalTableWitnessGroupMemberAction$ = [3, n0, _CGTWGMA,
    0,
    [_RN],
    [0], 1
];
var CreateReplicaAction$ = [3, n0, _CRA,
    0,
    [_RN],
    [0], 1
];
var CreateReplicationGroupMemberAction$ = [3, n0, _CRGMA,
    0,
    [_RN, _KMSMKI, _PTO, _ODTO, _GSI, _TCO],
    [0, 0, () => ProvisionedThroughputOverride$, () => OnDemandThroughputOverride$, () => ReplicaGlobalSecondaryIndexList, 0], 1
];
var CreateTableInput$ = [3, n0, _CTI,
    0,
    [_TN, _ADt, _KS, _LSI, _GSI, _BM, _PT, _SS, _SSES, _Ta, _TC, _DPE, _WT, _RP, _ODT, _GTSA, _GTSRM, _VI],
    [0, () => AttributeDefinitions, () => KeySchema, () => LocalSecondaryIndexList, () => GlobalSecondaryIndexList, 0, () => ProvisionedThroughput$, () => StreamSpecification$, () => SSESpecification$, () => TagList, 0, 2, () => WarmThroughput$, 0, () => OnDemandThroughput$, 0, 0, () => VectorIndexList], 1
];
var CreateTableOutput$ = [3, n0, _CTO,
    0,
    [_TD],
    [() => TableDescription$]
];
var CreateVectorIndexAction$ = [3, n0, _CVIA,
    0,
    [_IN, _VA, _Pr, _D, _DF, _SSe],
    [0, () => VectorAttributeDefinition$, () => Projection$, 1, 0, () => SearchSchema], 5
];
var CsvOptions$ = [3, n0, _COs,
    0,
    [_De, _HL],
    [0, 64 | 0]
];
var Delete$ = [3, n0, _Del,
    0,
    [_K, _TN, _CE, _EAN, _EAV, _RVOCCF],
    [() => Key, 0, 0, 128 | 0, () => ExpressionAttributeValueMap, 0], 2
];
var DeleteBackupInput$ = [3, n0, _DBI,
    0,
    [_BA],
    [0], 1
];
var DeleteBackupOutput$ = [3, n0, _DBO,
    0,
    [_BD],
    [() => BackupDescription$]
];
var DeleteGlobalSecondaryIndexAction$ = [3, n0, _DGSIA,
    0,
    [_IN],
    [0], 1
];
var DeleteGlobalTableWitnessGroupMemberAction$ = [3, n0, _DGTWGMA,
    0,
    [_RN],
    [0], 1
];
var DeleteItemInput$ = [3, n0, _DII,
    0,
    [_TN, _K, _Ex, _COo, _RV, _RCC, _RICM, _CE, _EAN, _EAV, _RVOCCF],
    [0, () => Key, () => ExpectedAttributeMap, 0, 0, 0, 0, 0, 128 | 0, () => ExpressionAttributeValueMap, 0], 2
];
var DeleteItemOutput$ = [3, n0, _DIO,
    0,
    [_At, _CC, _ICM],
    [() => AttributeMap, () => ConsumedCapacity$, () => ItemCollectionMetrics$]
];
var DeleteReplicaAction$ = [3, n0, _DRA,
    0,
    [_RN],
    [0], 1
];
var DeleteReplicationGroupMemberAction$ = [3, n0, _DRGMA,
    0,
    [_RN],
    [0], 1
];
var DeleteRequest$ = [3, n0, _DR,
    0,
    [_K],
    [() => Key], 1
];
var DeleteResourcePolicyInput$ = [3, n0, _DRPI,
    0,
    [_RA, _ERI],
    [0, 0], 1
];
var DeleteResourcePolicyOutput$ = [3, n0, _DRPO,
    0,
    [_RIe],
    [0]
];
var DeleteTableInput$ = [3, n0, _DTI,
    0,
    [_TN],
    [0], 1
];
var DeleteTableOutput$ = [3, n0, _DTO,
    0,
    [_TD],
    [() => TableDescription$]
];
var DeleteVectorIndexAction$ = [3, n0, _DVIA,
    0,
    [_IN],
    [0], 1
];
var DescribeBackupInput$ = [3, n0, _DBIe,
    0,
    [_BA],
    [0], 1
];
var DescribeBackupOutput$ = [3, n0, _DBOe,
    0,
    [_BD],
    [() => BackupDescription$]
];
var DescribeContinuousBackupsInput$ = [3, n0, _DCBI,
    0,
    [_TN],
    [0], 1
];
var DescribeContinuousBackupsOutput$ = [3, n0, _DCBO,
    0,
    [_CBD],
    [() => ContinuousBackupsDescription$]
];
var DescribeContributorInsightsInput$ = [3, n0, _DCII,
    0,
    [_TN, _IN],
    [0, 0], 1
];
var DescribeContributorInsightsOutput$ = [3, n0, _DCIO,
    0,
    [_TN, _IN, _CIRL, _CISo, _LUDT, _FE, _CIM],
    [0, 0, 64 | 0, 0, 4, () => FailureException$, 0]
];
var DescribeEndpointsRequest$ = [3, n0, _DER,
    0,
    [],
    []
];
var DescribeEndpointsResponse$ = [3, n0, _DERe,
    0,
    [_En],
    [() => Endpoints], 1
];
var DescribeExportInput$ = [3, n0, _DEI,
    0,
    [_EA],
    [0], 1
];
var DescribeExportOutput$ = [3, n0, _DEO,
    0,
    [_ED],
    [() => ExportDescription$]
];
var DescribeGlobalTableInput$ = [3, n0, _DGTI,
    0,
    [_GTN],
    [0], 1
];
var DescribeGlobalTableOutput$ = [3, n0, _DGTO,
    0,
    [_GTD],
    [() => GlobalTableDescription$]
];
var DescribeGlobalTableSettingsInput$ = [3, n0, _DGTSI,
    0,
    [_GTN],
    [0], 1
];
var DescribeGlobalTableSettingsOutput$ = [3, n0, _DGTSO,
    0,
    [_GTN, _RS],
    [0, () => ReplicaSettingsDescriptionList]
];
var DescribeImportInput$ = [3, n0, _DIIe,
    0,
    [_IA],
    [0], 1
];
var DescribeImportOutput$ = [3, n0, _DIOe,
    0,
    [_ITD],
    [() => ImportTableDescription$], 1
];
var DescribeKinesisStreamingDestinationInput$ = [3, n0, _DKSDI,
    0,
    [_TN],
    [0], 1
];
var DescribeKinesisStreamingDestinationOutput$ = [3, n0, _DKSDO,
    0,
    [_TN, _KDSD],
    [0, () => KinesisDataStreamDestinations]
];
var DescribeLimitsInput$ = [3, n0, _DLI,
    0,
    [],
    []
];
var DescribeLimitsOutput$ = [3, n0, _DLO,
    0,
    [_AMRCU, _AMWCU, _TMRCU, _TMWCU],
    [1, 1, 1, 1]
];
var DescribeTableInput$ = [3, n0, _DTIe,
    0,
    [_TN],
    [0], 1
];
var DescribeTableOutput$ = [3, n0, _DTOe,
    0,
    [_T],
    [() => TableDescription$]
];
var DescribeTableReplicaAutoScalingInput$ = [3, n0, _DTRASI,
    0,
    [_TN],
    [0], 1
];
var DescribeTableReplicaAutoScalingOutput$ = [3, n0, _DTRASO,
    0,
    [_TASD],
    [() => TableAutoScalingDescription$]
];
var DescribeTimeToLiveInput$ = [3, n0, _DTTLI,
    0,
    [_TN],
    [0], 1
];
var DescribeTimeToLiveOutput$ = [3, n0, _DTTLO,
    0,
    [_TTLD],
    [() => TimeToLiveDescription$]
];
var EnableKinesisStreamingConfiguration$ = [3, n0, _EKSC,
    0,
    [_ACDTP],
    [0]
];
var Endpoint$ = [3, n0, _End,
    0,
    [_Ad, _CPIM],
    [0, 1], 2
];
var ExecuteStatementInput$ = [3, n0, _ESI,
    0,
    [_St, _P, _CRo, _NT, _RCC, _L, _RVOCCF],
    [0, () => PreparedStatementParameters, 2, 0, 0, 1, 0], 1
];
var ExecuteStatementOutput$ = [3, n0, _ESO,
    0,
    [_It, _NT, _CC, _LEK],
    [() => ItemList, 0, () => ConsumedCapacity$, () => Key]
];
var ExecuteTransactionInput$ = [3, n0, _ETI,
    0,
    [_TS, _CRT, _RCC],
    [() => ParameterizedStatements, [0, 4], 0], 1
];
var ExecuteTransactionOutput$ = [3, n0, _ETO,
    0,
    [_R, _CC],
    [() => ItemResponseList, () => ConsumedCapacityMultiple]
];
var ExpectedAttributeValue$ = [3, n0, _EAVx,
    0,
    [_V, _Exi, _CO, _AVL],
    [() => AttributeValue$, 2, 0, () => AttributeValueList]
];
var ExportDescription$ = [3, n0, _ED,
    0,
    [_EA, _ES, _ST, _ET, _EM, _TA, _TI, _ETx, _CT, _SB, _SBO, _SPr, _SSA, _SSKKI, _FC, _FM, _EF, _BSBi, _IC, _ETxp, _IES],
    [0, 0, 4, 4, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, () => IncrementalExportSpecification$]
];
var ExportSummary$ = [3, n0, _ESx,
    0,
    [_EA, _ES, _ETxp],
    [0, 0, 0]
];
var ExportTableToPointInTimeInput$ = [3, n0, _ETTPITI,
    0,
    [_TA, _SB, _ETx, _CT, _SBO, _SPr, _SSA, _SSKKI, _EF, _ETxp, _IES],
    [0, 0, 4, [0, 4], 0, 0, 0, 0, 0, 0, () => IncrementalExportSpecification$], 2
];
var ExportTableToPointInTimeOutput$ = [3, n0, _ETTPITO,
    0,
    [_ED],
    [() => ExportDescription$]
];
var FailureException$ = [3, n0, _FE,
    0,
    [_EN, _EDx],
    [0, 0]
];
var Get$ = [3, n0, _G,
    0,
    [_K, _TN, _PE, _EAN],
    [() => Key, 0, 0, 128 | 0], 2
];
var GetItemInput$ = [3, n0, _GII,
    0,
    [_TN, _K, _ATG, _CRo, _RCC, _PE, _EAN],
    [0, () => Key, 64 | 0, 2, 0, 0, 128 | 0], 2
];
var GetItemOutput$ = [3, n0, _GIO,
    0,
    [_I, _CC],
    [() => AttributeMap, () => ConsumedCapacity$]
];
var GetResourcePolicyInput$ = [3, n0, _GRPI,
    0,
    [_RA],
    [0], 1
];
var GetResourcePolicyOutput$ = [3, n0, _GRPO,
    0,
    [_Po, _RIe],
    [0, 0]
];
var GlobalSecondaryIndex$ = [3, n0, _GSIl,
    0,
    [_IN, _KS, _Pr, _PT, _ODT, _WT],
    [0, () => KeySchema, () => Projection$, () => ProvisionedThroughput$, () => OnDemandThroughput$, () => WarmThroughput$], 3
];
var GlobalSecondaryIndexAutoScalingUpdate$ = [3, n0, _GSIASU,
    0,
    [_IN, _PWCASU],
    [0, () => AutoScalingSettingsUpdate$]
];
var GlobalSecondaryIndexDescription$ = [3, n0, _GSID,
    0,
    [_IN, _KS, _Pr, _IS, _B, _PT, _ISB, _IC, _IAn, _ODT, _WT],
    [0, () => KeySchema, () => Projection$, 0, 2, () => ProvisionedThroughputDescription$, 1, 1, 0, () => OnDemandThroughput$, () => GlobalSecondaryIndexWarmThroughputDescription$]
];
var GlobalSecondaryIndexInfo$ = [3, n0, _GSII,
    0,
    [_IN, _KS, _Pr, _PT, _ODT],
    [0, () => KeySchema, () => Projection$, () => ProvisionedThroughput$, () => OnDemandThroughput$]
];
var GlobalSecondaryIndexUpdate$ = [3, n0, _GSIU,
    0,
    [_U, _Cr, _Del],
    [() => UpdateGlobalSecondaryIndexAction$, () => CreateGlobalSecondaryIndexAction$, () => DeleteGlobalSecondaryIndexAction$]
];
var GlobalSecondaryIndexWarmThroughputDescription$ = [3, n0, _GSIWTD,
    0,
    [_RUPS, _WUPS, _Sta],
    [1, 1, 0]
];
var GlobalTable$ = [3, n0, _GT,
    0,
    [_GTN, _RG],
    [0, () => ReplicaList]
];
var GlobalTableDescription$ = [3, n0, _GTD,
    0,
    [_RG, _GTA, _CDT, _GTS, _GTN],
    [() => ReplicaDescriptionList, 0, 4, 0, 0]
];
var GlobalTableGlobalSecondaryIndexSettingsUpdate$ = [3, n0, _GTGSISU,
    0,
    [_IN, _PWCU, _PWCASSU],
    [0, 1, () => AutoScalingSettingsUpdate$], 1
];
var GlobalTableWitnessDescription$ = [3, n0, _GTWD,
    0,
    [_RN, _WS],
    [0, 0]
];
var GlobalTableWitnessGroupUpdate$ = [3, n0, _GTWGU,
    0,
    [_Cr, _Del],
    [() => CreateGlobalTableWitnessGroupMemberAction$, () => DeleteGlobalTableWitnessGroupMemberAction$]
];
var ImportSummary$ = [3, n0, _ISm,
    0,
    [_IA, _ISmp, _TA, _SBS, _CWLGA, _IF, _ST, _ET],
    [0, 0, 0, () => S3BucketSource$, 0, 0, 4, 4]
];
var ImportTableDescription$ = [3, n0, _ITD,
    0,
    [_IA, _ISmp, _TA, _TI, _CT, _SBS, _EC, _CWLGA, _IF, _IFO, _ICT, _TCP, _ST, _ET, _PSB, _PIC, _IIC, _FC, _FM],
    [0, 0, 0, 0, 0, () => S3BucketSource$, 1, 0, 0, () => InputFormatOptions$, 0, () => TableCreationParameters$, 4, 4, 1, 1, 1, 0, 0]
];
var ImportTableInput$ = [3, n0, _ITI,
    0,
    [_SBS, _IF, _TCP, _CT, _IFO, _ICT],
    [() => S3BucketSource$, 0, () => TableCreationParameters$, [0, 4], () => InputFormatOptions$, 0], 3
];
var ImportTableOutput$ = [3, n0, _ITO,
    0,
    [_ITD],
    [() => ImportTableDescription$], 1
];
var IncrementalExportSpecification$ = [3, n0, _IES,
    0,
    [_EFT, _ETT, _EVT],
    [4, 4, 0]
];
var InputFormatOptions$ = [3, n0, _IFO,
    0,
    [_Cs],
    [() => CsvOptions$]
];
var ItemCollectionMetrics$ = [3, n0, _ICM,
    0,
    [_ICK, _SERGB],
    [() => ItemCollectionKeyAttributeMap, 64 | 1]
];
var ItemResponse$ = [3, n0, _IR,
    0,
    [_I],
    [() => AttributeMap]
];
var KeysAndAttributes$ = [3, n0, _KAA,
    0,
    [_Ke, _ATG, _CRo, _PE, _EAN],
    [() => KeyList, 64 | 0, 2, 0, 128 | 0], 1
];
var KeySchemaElement$ = [3, n0, _KSE,
    0,
    [_AN, _KT],
    [0, 0], 2
];
var KinesisDataStreamDestination$ = [3, n0, _KDSDi,
    0,
    [_SA, _DS, _DSD, _ACDTP],
    [0, 0, 0, 0]
];
var KinesisStreamingDestinationInput$ = [3, n0, _KSDI,
    0,
    [_TN, _SA, _EKSC],
    [0, 0, () => EnableKinesisStreamingConfiguration$], 2
];
var KinesisStreamingDestinationOutput$ = [3, n0, _KSDO,
    0,
    [_TN, _SA, _DS, _EKSC],
    [0, 0, 0, () => EnableKinesisStreamingConfiguration$]
];
var ListBackupsInput$ = [3, n0, _LBI,
    0,
    [_TN, _L, _TRLB, _TRUB, _ESBA, _BT],
    [0, 1, 4, 4, 0, 0]
];
var ListBackupsOutput$ = [3, n0, _LBO,
    0,
    [_BSac, _LEBA],
    [() => BackupSummaries, 0]
];
var ListContributorInsightsInput$ = [3, n0, _LCII,
    0,
    [_TN, _NT, _MR],
    [0, 0, 1]
];
var ListContributorInsightsOutput$ = [3, n0, _LCIO,
    0,
    [_CISon, _NT],
    [() => ContributorInsightsSummaries, 0]
];
var ListExportsInput$ = [3, n0, _LEI,
    0,
    [_TA, _MR, _NT],
    [0, 1, 0]
];
var ListExportsOutput$ = [3, n0, _LEO,
    0,
    [_ESxp, _NT],
    [() => ExportSummaries, 0]
];
var ListGlobalTablesInput$ = [3, n0, _LGTI,
    0,
    [_ESGTN, _L, _RN],
    [0, 1, 0]
];
var ListGlobalTablesOutput$ = [3, n0, _LGTO,
    0,
    [_GTl, _LEGTN],
    [() => GlobalTableList, 0]
];
var ListImportsInput$ = [3, n0, _LII,
    0,
    [_TA, _PS, _NT],
    [0, 1, 0]
];
var ListImportsOutput$ = [3, n0, _LIO,
    0,
    [_ISL, _NT],
    [() => ImportSummaryList, 0]
];
var ListTablesInput$ = [3, n0, _LTI,
    0,
    [_ESTN, _L],
    [0, 1]
];
var ListTablesOutput$ = [3, n0, _LTO,
    0,
    [_TNa, _LETN],
    [64 | 0, 0]
];
var ListTagsOfResourceInput$ = [3, n0, _LTORI,
    0,
    [_RA, _NT],
    [0, 0], 1
];
var ListTagsOfResourceOutput$ = [3, n0, _LTORO,
    0,
    [_Ta, _NT],
    [() => TagList, 0]
];
var LocalSecondaryIndex$ = [3, n0, _LSIo,
    0,
    [_IN, _KS, _Pr],
    [0, () => KeySchema, () => Projection$], 3
];
var LocalSecondaryIndexDescription$ = [3, n0, _LSID,
    0,
    [_IN, _KS, _Pr, _ISB, _IC, _IAn],
    [0, () => KeySchema, () => Projection$, 1, 1, 0]
];
var LocalSecondaryIndexInfo$ = [3, n0, _LSII,
    0,
    [_IN, _KS, _Pr],
    [0, () => KeySchema, () => Projection$]
];
var OnDemandThroughput$ = [3, n0, _ODT,
    0,
    [_MRRU, _MWRU],
    [1, 1]
];
var OnDemandThroughputOverride$ = [3, n0, _ODTO,
    0,
    [_MRRU],
    [1]
];
var ParameterizedStatement$ = [3, n0, _PSa,
    0,
    [_St, _P, _RVOCCF],
    [0, () => PreparedStatementParameters, 0], 1
];
var PointInTimeRecoveryDescription$ = [3, n0, _PITRD,
    0,
    [_PITRS, _RPID, _ERDT, _LRDT],
    [0, 1, 4, 4]
];
var PointInTimeRecoverySpecification$ = [3, n0, _PITRSo,
    0,
    [_PITRE, _RPID],
    [2, 1], 1
];
var Projection$ = [3, n0, _Pr,
    0,
    [_PTr, _NKA],
    [0, 64 | 0]
];
var ProvisionedThroughput$ = [3, n0, _PT,
    0,
    [_RCU, _WCU],
    [1, 1], 2
];
var ProvisionedThroughputDescription$ = [3, n0, _PTD,
    0,
    [_LIDT, _LDDT, _NODT, _RCU, _WCU],
    [4, 4, 1, 1, 1]
];
var ProvisionedThroughputOverride$ = [3, n0, _PTO,
    0,
    [_RCU],
    [1]
];
var Put$ = [3, n0, _Pu,
    0,
    [_I, _TN, _CE, _EAN, _EAV, _RVOCCF],
    [() => PutItemInputAttributeMap, 0, 0, 128 | 0, () => ExpressionAttributeValueMap, 0], 2
];
var PutItemInput$ = [3, n0, _PII,
    0,
    [_TN, _I, _Ex, _RV, _RCC, _RICM, _COo, _CE, _EAN, _EAV, _RVOCCF],
    [0, () => PutItemInputAttributeMap, () => ExpectedAttributeMap, 0, 0, 0, 0, 0, 128 | 0, () => ExpressionAttributeValueMap, 0], 2
];
var PutItemOutput$ = [3, n0, _PIO,
    0,
    [_At, _CC, _ICM],
    [() => AttributeMap, () => ConsumedCapacity$, () => ItemCollectionMetrics$]
];
var PutRequest$ = [3, n0, _PR,
    0,
    [_I],
    [() => PutItemInputAttributeMap], 1
];
var PutResourcePolicyInput$ = [3, n0, _PRPI,
    0,
    [_RA, _Po, _ERI, _CRSRA],
    [0, 0, 0, [2, { [_hH]: _xacrsra }]], 2
];
var PutResourcePolicyOutput$ = [3, n0, _PRPO,
    0,
    [_RIe],
    [0]
];
var QueryInput$ = [3, n0, _QI,
    0,
    [_TN, _IN, _Se, _ATG, _L, _CRo, _KC, _QF, _COo, _SIF, _ESK, _RCC, _PE, _FEi, _KCE, _EAN, _EAV],
    [0, 0, 0, 64 | 0, 1, 2, () => KeyConditions, () => FilterConditionMap, 0, 2, () => Key, 0, 0, 0, 0, 128 | 0, () => ExpressionAttributeValueMap], 1
];
var QueryOutput$ = [3, n0, _QO,
    0,
    [_It, _Cou, _SC, _LEK, _CC],
    [() => ItemList, 1, 1, () => Key, () => ConsumedCapacity$]
];
var Replica$ = [3, n0, _Re,
    0,
    [_RN],
    [0]
];
var ReplicaAutoScalingDescription$ = [3, n0, _RASD,
    0,
    [_RN, _GSI, _RPRCASS, _RPWCASS, _RSe],
    [0, () => ReplicaGlobalSecondaryIndexAutoScalingDescriptionList, () => AutoScalingSettingsDescription$, () => AutoScalingSettingsDescription$, 0]
];
var ReplicaAutoScalingUpdate$ = [3, n0, _RASU,
    0,
    [_RN, _RGSIU, _RPRCASU],
    [0, () => ReplicaGlobalSecondaryIndexAutoScalingUpdateList, () => AutoScalingSettingsUpdate$], 1
];
var ReplicaDescription$ = [3, n0, _RD,
    0,
    [_RN, _RSe, _RAe, _RSD, _RSPP, _KMSMKI, _PTO, _ODTO, _WT, _GSI, _RIDT, _RTCS, _GTSRM],
    [0, 0, 0, 0, 0, 0, () => ProvisionedThroughputOverride$, () => OnDemandThroughputOverride$, () => TableWarmThroughputDescription$, () => ReplicaGlobalSecondaryIndexDescriptionList, 4, () => TableClassSummary$, 0]
];
var ReplicaGlobalSecondaryIndex$ = [3, n0, _RGSI,
    0,
    [_IN, _PTO, _ODTO],
    [0, () => ProvisionedThroughputOverride$, () => OnDemandThroughputOverride$], 1
];
var ReplicaGlobalSecondaryIndexAutoScalingDescription$ = [3, n0, _RGSIASD,
    0,
    [_IN, _IS, _PRCASS, _PWCASS],
    [0, 0, () => AutoScalingSettingsDescription$, () => AutoScalingSettingsDescription$]
];
var ReplicaGlobalSecondaryIndexAutoScalingUpdate$ = [3, n0, _RGSIASU,
    0,
    [_IN, _PRCASU],
    [0, () => AutoScalingSettingsUpdate$]
];
var ReplicaGlobalSecondaryIndexDescription$ = [3, n0, _RGSID,
    0,
    [_IN, _PTO, _ODTO, _WT],
    [0, () => ProvisionedThroughputOverride$, () => OnDemandThroughputOverride$, () => GlobalSecondaryIndexWarmThroughputDescription$]
];
var ReplicaGlobalSecondaryIndexSettingsDescription$ = [3, n0, _RGSISD,
    0,
    [_IN, _IS, _PRCU, _PRCASS, _PWCU, _PWCASS],
    [0, 0, 1, () => AutoScalingSettingsDescription$, 1, () => AutoScalingSettingsDescription$], 1
];
var ReplicaGlobalSecondaryIndexSettingsUpdate$ = [3, n0, _RGSISU,
    0,
    [_IN, _PRCU, _PRCASSU],
    [0, 1, () => AutoScalingSettingsUpdate$], 1
];
var ReplicaSettingsDescription$ = [3, n0, _RSDe,
    0,
    [_RN, _RSe, _RBMS, _RPRCU, _RPRCASS, _RPWCU, _RPWCASS, _RGSIS, _RTCS],
    [0, 0, () => BillingModeSummary$, 1, () => AutoScalingSettingsDescription$, 1, () => AutoScalingSettingsDescription$, () => ReplicaGlobalSecondaryIndexSettingsDescriptionList, () => TableClassSummary$], 1
];
var ReplicaSettingsUpdate$ = [3, n0, _RSU,
    0,
    [_RN, _RPRCU, _RPRCASSU, _RGSISU, _RTC],
    [0, 1, () => AutoScalingSettingsUpdate$, () => ReplicaGlobalSecondaryIndexSettingsUpdateList, 0], 1
];
var ReplicationGroupUpdate$ = [3, n0, _RGU,
    0,
    [_Cr, _U, _Del],
    [() => CreateReplicationGroupMemberAction$, () => UpdateReplicationGroupMemberAction$, () => DeleteReplicationGroupMemberAction$]
];
var ReplicaUpdate$ = [3, n0, _RU,
    0,
    [_Cr, _Del],
    [() => CreateReplicaAction$, () => DeleteReplicaAction$]
];
var RestoreSummary$ = [3, n0, _RSes,
    0,
    [_RDT, _RIP, _SBA, _STA],
    [4, 2, 0, 0], 2
];
var RestoreTableFromBackupInput$ = [3, n0, _RTFBI,
    0,
    [_TTN, _BA, _BMO, _GSIO, _LSIO, _PTO, _ODTO, _SSESO, _VIO],
    [0, 0, 0, () => GlobalSecondaryIndexList, () => LocalSecondaryIndexList, () => ProvisionedThroughput$, () => OnDemandThroughput$, () => SSESpecification$, () => VectorIndexList], 2
];
var RestoreTableFromBackupOutput$ = [3, n0, _RTFBO,
    0,
    [_TD],
    [() => TableDescription$]
];
var RestoreTableToPointInTimeInput$ = [3, n0, _RTTPITI,
    0,
    [_TTN, _STA, _STN, _ULRT, _RDT, _BMO, _GSIO, _LSIO, _PTO, _ODTO, _SSESO, _VIO],
    [0, 0, 0, 2, 4, 0, () => GlobalSecondaryIndexList, () => LocalSecondaryIndexList, () => ProvisionedThroughput$, () => OnDemandThroughput$, () => SSESpecification$, () => VectorIndexList], 1
];
var RestoreTableToPointInTimeOutput$ = [3, n0, _RTTPITO,
    0,
    [_TD],
    [() => TableDescription$]
];
var S3BucketSource$ = [3, n0, _SBS,
    0,
    [_SB, _SBO, _SKP],
    [0, 0, 0], 1
];
var ScanInput$ = [3, n0, _SI,
    0,
    [_TN, _IN, _ATG, _L, _Se, _SF, _COo, _ESK, _RCC, _TSo, _Seg, _PE, _FEi, _EAN, _EAV, _CRo],
    [0, 0, 64 | 0, 1, 0, () => FilterConditionMap, 0, () => Key, 0, 1, 1, 0, 0, 128 | 0, () => ExpressionAttributeValueMap, 2], 1
];
var ScanOutput$ = [3, n0, _SO,
    0,
    [_It, _Cou, _SC, _LEK, _CC],
    [() => ItemList, 1, 1, () => Key, () => ConsumedCapacity$]
];
var SearchResultItem$ = [3, n0, _SRI,
    0,
    [_I, _Sc],
    [() => AttributeMap, 1]
];
var SearchSchemaElement$ = [3, n0, _SSE,
    0,
    [_AN, _SSET],
    [0, 0], 2
];
var SearchVectorsInput$ = [3, n0, _SVI,
    0,
    [_TN, _IN, _SV, _TK, _RCC, _EAN, _EAV, _PE, _SCE],
    [0, 0, () => SearchVectorList, 1, 0, 128 | 0, () => ExpressionAttributeValueMap, 0, 0], 4
];
var SearchVectorsOutput$ = [3, n0, _SVO,
    0,
    [_CC, _SR],
    [() => VectorCapacity$, () => SearchResultList]
];
var SourceTableDetails$ = [3, n0, _STD,
    0,
    [_TN, _TI, _KS, _TCDT, _PT, _TA, _TSB, _ODT, _IC, _BM],
    [0, 0, () => KeySchema, 4, () => ProvisionedThroughput$, 0, 1, () => OnDemandThroughput$, 1, 0], 5
];
var SourceTableFeatureDetails$ = [3, n0, _STFD,
    0,
    [_LSI, _GSI, _SD, _TTLD, _SSED, _VI],
    [() => LocalSecondaryIndexes, () => GlobalSecondaryIndexes, () => StreamSpecification$, () => TimeToLiveDescription$, () => SSEDescription$, () => VectorIndexes]
];
var SSEDescription$ = [3, n0, _SSED,
    0,
    [_Sta, _SSETy, _KMSMKA, _IEDT],
    [0, 0, 0, 4]
];
var SSESpecification$ = [3, n0, _SSES,
    0,
    [_Ena, _SSETy, _KMSMKI],
    [2, 0, 0]
];
var StreamSpecification$ = [3, n0, _SS,
    0,
    [_SE, _SVT],
    [2, 0], 1
];
var TableAutoScalingDescription$ = [3, n0, _TASD,
    0,
    [_TN, _TSa, _Rep],
    [0, 0, () => ReplicaAutoScalingDescriptionList]
];
var TableClassSummary$ = [3, n0, _TCS,
    0,
    [_TC, _LUDT],
    [0, 4]
];
var TableCreationParameters$ = [3, n0, _TCP,
    0,
    [_TN, _ADt, _KS, _BM, _PT, _ODT, _SSES, _GSI, _VI],
    [0, () => AttributeDefinitions, () => KeySchema, 0, () => ProvisionedThroughput$, () => OnDemandThroughput$, () => SSESpecification$, () => GlobalSecondaryIndexList, () => VectorIndexList], 3
];
var TableDescription$ = [3, n0, _TD,
    0,
    [_ADt, _TN, _KS, _TSa, _CDT, _PT, _TSB, _IC, _TA, _TI, _BMS, _LSI, _GSI, _SS, _LSL, _LSA, _GTV, _Rep, _GTW, _GTSRM, _RSes, _SSED, _AS, _TCS, _DPE, _ODT, _WT, _MRC, _VI],
    [() => AttributeDefinitions, 0, () => KeySchema, 0, 4, () => ProvisionedThroughputDescription$, 1, 1, 0, 0, () => BillingModeSummary$, () => LocalSecondaryIndexDescriptionList, () => GlobalSecondaryIndexDescriptionList, () => StreamSpecification$, 0, 0, 0, () => ReplicaDescriptionList, () => GlobalTableWitnessDescriptionList, 0, () => RestoreSummary$, () => SSEDescription$, () => ArchivalSummary$, () => TableClassSummary$, 2, () => OnDemandThroughput$, () => TableWarmThroughputDescription$, 0, () => VectorIndexDescriptionList]
];
var TableWarmThroughputDescription$ = [3, n0, _TWTD,
    0,
    [_RUPS, _WUPS, _Sta],
    [1, 1, 0]
];
var Tag$ = [3, n0, _Tag,
    0,
    [_K, _V],
    [0, 0], 2
];
var TagResourceInput$ = [3, n0, _TRI,
    0,
    [_RA, _Ta],
    [0, () => TagList], 2
];
var ThrottlingReason$ = [3, n0, _TRh,
    0,
    [_r, _re],
    [0, 0]
];
var TimeToLiveDescription$ = [3, n0, _TTLD,
    0,
    [_TTLS, _AN],
    [0, 0]
];
var TimeToLiveSpecification$ = [3, n0, _TTLSi,
    0,
    [_Ena, _AN],
    [2, 0], 2
];
var TransactGetItem$ = [3, n0, _TGI,
    0,
    [_G],
    [() => Get$], 1
];
var TransactGetItemsInput$ = [3, n0, _TGII,
    0,
    [_TIr, _RCC],
    [() => TransactGetItemList, 0], 1
];
var TransactGetItemsOutput$ = [3, n0, _TGIO,
    0,
    [_CC, _R],
    [() => ConsumedCapacityMultiple, () => ItemResponseList]
];
var TransactWriteItem$ = [3, n0, _TWI,
    0,
    [_CCo, _Pu, _Del, _U],
    [() => ConditionCheck$, () => Put$, () => Delete$, () => Update$]
];
var TransactWriteItemsInput$ = [3, n0, _TWII,
    0,
    [_TIr, _RCC, _RICM, _CRT],
    [() => TransactWriteItemList, 0, 0, [0, 4]], 1
];
var TransactWriteItemsOutput$ = [3, n0, _TWIO,
    0,
    [_CC, _ICM],
    [() => ConsumedCapacityMultiple, () => ItemCollectionMetricsPerTable]
];
var UntagResourceInput$ = [3, n0, _URI,
    0,
    [_RA, _TKa],
    [0, 64 | 0], 2
];
var Update$ = [3, n0, _U,
    0,
    [_K, _UE, _TN, _CE, _EAN, _EAV, _RVOCCF],
    [() => Key, 0, 0, 0, 128 | 0, () => ExpressionAttributeValueMap, 0], 3
];
var UpdateContinuousBackupsInput$ = [3, n0, _UCBI,
    0,
    [_TN, _PITRSo],
    [0, () => PointInTimeRecoverySpecification$], 2
];
var UpdateContinuousBackupsOutput$ = [3, n0, _UCBO,
    0,
    [_CBD],
    [() => ContinuousBackupsDescription$]
];
var UpdateContributorInsightsInput$ = [3, n0, _UCII,
    0,
    [_TN, _CIA, _IN, _CIM],
    [0, 0, 0, 0], 2
];
var UpdateContributorInsightsOutput$ = [3, n0, _UCIO,
    0,
    [_TN, _IN, _CISo, _CIM],
    [0, 0, 0, 0]
];
var UpdateGlobalSecondaryIndexAction$ = [3, n0, _UGSIA,
    0,
    [_IN, _PT, _ODT, _WT],
    [0, () => ProvisionedThroughput$, () => OnDemandThroughput$, () => WarmThroughput$], 1
];
var UpdateGlobalTableInput$ = [3, n0, _UGTI,
    0,
    [_GTN, _RUe],
    [0, () => ReplicaUpdateList], 2
];
var UpdateGlobalTableOutput$ = [3, n0, _UGTO,
    0,
    [_GTD],
    [() => GlobalTableDescription$]
];
var UpdateGlobalTableSettingsInput$ = [3, n0, _UGTSI,
    0,
    [_GTN, _GTBM, _GTPWCU, _GTPWCASSU, _GTGSISU, _RSU],
    [0, 0, 1, () => AutoScalingSettingsUpdate$, () => GlobalTableGlobalSecondaryIndexSettingsUpdateList, () => ReplicaSettingsUpdateList], 1
];
var UpdateGlobalTableSettingsOutput$ = [3, n0, _UGTSO,
    0,
    [_GTN, _RS],
    [0, () => ReplicaSettingsDescriptionList]
];
var UpdateItemInput$ = [3, n0, _UII,
    0,
    [_TN, _K, _AU, _Ex, _COo, _RV, _RCC, _RICM, _UE, _CE, _EAN, _EAV, _RVOCCF],
    [0, () => Key, () => AttributeUpdates, () => ExpectedAttributeMap, 0, 0, 0, 0, 0, 0, 128 | 0, () => ExpressionAttributeValueMap, 0], 2
];
var UpdateItemOutput$ = [3, n0, _UIO,
    0,
    [_At, _CC, _ICM],
    [() => AttributeMap, () => ConsumedCapacity$, () => ItemCollectionMetrics$]
];
var UpdateKinesisStreamingConfiguration$ = [3, n0, _UKSC,
    0,
    [_ACDTP],
    [0]
];
var UpdateKinesisStreamingDestinationInput$ = [3, n0, _UKSDI,
    0,
    [_TN, _SA, _UKSC],
    [0, 0, () => UpdateKinesisStreamingConfiguration$], 2
];
var UpdateKinesisStreamingDestinationOutput$ = [3, n0, _UKSDO,
    0,
    [_TN, _SA, _DS, _UKSC],
    [0, 0, 0, () => UpdateKinesisStreamingConfiguration$]
];
var UpdateReplicationGroupMemberAction$ = [3, n0, _URGMA,
    0,
    [_RN, _KMSMKI, _PTO, _ODTO, _GSI, _TCO],
    [0, 0, () => ProvisionedThroughputOverride$, () => OnDemandThroughputOverride$, () => ReplicaGlobalSecondaryIndexList, 0], 1
];
var UpdateTableInput$ = [3, n0, _UTI,
    0,
    [_TN, _ADt, _BM, _PT, _GSIUl, _SS, _SSES, _RUe, _TC, _DPE, _MRC, _GTWU, _ODT, _WT, _GTSRM, _VIU],
    [0, () => AttributeDefinitions, 0, () => ProvisionedThroughput$, () => GlobalSecondaryIndexUpdateList, () => StreamSpecification$, () => SSESpecification$, () => ReplicationGroupUpdateList, 0, 2, 0, () => GlobalTableWitnessGroupUpdateList, () => OnDemandThroughput$, () => WarmThroughput$, 0, () => VectorIndexUpdateList], 1
];
var UpdateTableOutput$ = [3, n0, _UTO,
    0,
    [_TD],
    [() => TableDescription$]
];
var UpdateTableReplicaAutoScalingInput$ = [3, n0, _UTRASI,
    0,
    [_TN, _GSIUl, _PWCASU, _RUe],
    [0, () => GlobalSecondaryIndexAutoScalingUpdateList, () => AutoScalingSettingsUpdate$, () => ReplicaAutoScalingUpdateList], 1
];
var UpdateTableReplicaAutoScalingOutput$ = [3, n0, _UTRASO,
    0,
    [_TASD],
    [() => TableAutoScalingDescription$]
];
var UpdateTimeToLiveInput$ = [3, n0, _UTTLI,
    0,
    [_TN, _TTLSi],
    [0, () => TimeToLiveSpecification$], 2
];
var UpdateTimeToLiveOutput$ = [3, n0, _UTTLO,
    0,
    [_TTLSi],
    [() => TimeToLiveSpecification$]
];
var VectorAttributeDefinition$ = [3, n0, _VAD,
    0,
    [_AN],
    [0], 1
];
var VectorCapacity$ = [3, n0, _VC,
    0,
    [_VSRB, _VWRB],
    [1, 1]
];
var VectorIndex$ = [3, n0, _VIe,
    0,
    [_IN, _VA, _Pr, _D, _DF, _SSe],
    [0, () => VectorAttributeDefinition$, () => Projection$, 1, 0, () => SearchSchema], 5
];
var VectorIndexDescription$ = [3, n0, _VID,
    0,
    [_IN, _SSe, _Pr, _VA, _D, _DF, _IS, _B, _ISB, _IC, _IAn],
    [0, () => SearchSchema, () => Projection$, () => VectorAttributeDefinition$, 1, 0, 0, 2, 1, 1, 0]
];
var VectorIndexInfo$ = [3, n0, _VII,
    0,
    [_IN, _VA, _SSe, _Pr, _D, _DF],
    [0, () => VectorAttributeDefinition$, () => SearchSchema, () => Projection$, 1, 0]
];
var VectorIndexUpdate$ = [3, n0, _VIUe,
    0,
    [_Cr, _Del],
    [() => CreateVectorIndexAction$, () => DeleteVectorIndexAction$]
];
var WarmThroughput$ = [3, n0, _WT,
    0,
    [_RUPS, _WUPS],
    [1, 1]
];
var WriteRequest$ = [3, n0, _WR,
    0,
    [_PR, _DR],
    [() => PutRequest$, () => DeleteRequest$]
];
var __Unit = "unit";
var AttributeDefinitions = [1, n0, _ADt,
    0, () => AttributeDefinition$
];
var AttributeValueList = [1, n0, _AVL,
    0, () => AttributeValue$
];
var AutoScalingPolicyDescriptionList = [1, n0, _ASPDL,
    0, () => AutoScalingPolicyDescription$
];
var BackupSummaries = [1, n0, _BSac,
    0, () => BackupSummary$
];
var CancellationReasonList = [1, n0, _CRL,
    0, () => CancellationReason$
];
var ConsumedCapacityMultiple = [1, n0, _CCM,
    0, () => ConsumedCapacity$
];
var ContributorInsightsSummaries = [1, n0, _CISon,
    0, () => ContributorInsightsSummary$
];
var Endpoints = [1, n0, _En,
    0, () => Endpoint$
];
var ExportSummaries = [1, n0, _ESxp,
    0, () => ExportSummary$
];
var GlobalSecondaryIndexAutoScalingUpdateList = [1, n0, _GSIASUL,
    0, () => GlobalSecondaryIndexAutoScalingUpdate$
];
var GlobalSecondaryIndexDescriptionList = [1, n0, _GSIDL,
    0, () => GlobalSecondaryIndexDescription$
];
var GlobalSecondaryIndexes = [1, n0, _GSI,
    0, () => GlobalSecondaryIndexInfo$
];
var GlobalSecondaryIndexList = [1, n0, _GSIL,
    0, () => GlobalSecondaryIndex$
];
var GlobalSecondaryIndexUpdateList = [1, n0, _GSIUL,
    0, () => GlobalSecondaryIndexUpdate$
];
var GlobalTableGlobalSecondaryIndexSettingsUpdateList = [1, n0, _GTGSISUL,
    0, () => GlobalTableGlobalSecondaryIndexSettingsUpdate$
];
var GlobalTableList = [1, n0, _GTL,
    0, () => GlobalTable$
];
var GlobalTableWitnessDescriptionList = [1, n0, _GTWDL,
    0, () => GlobalTableWitnessDescription$
];
var GlobalTableWitnessGroupUpdateList = [1, n0, _GTWGUL,
    0, () => GlobalTableWitnessGroupUpdate$
];
var ImportSummaryList = [1, n0, _ISL,
    0, () => ImportSummary$
];
var ItemCollectionMetricsMultiple = [1, n0, _ICMM,
    0, () => ItemCollectionMetrics$
];
var ItemList = [1, n0, _IL,
    0, () => AttributeMap
];
var ItemResponseList = [1, n0, _IRL,
    0, () => ItemResponse$
];
var KeyList = [1, n0, _KL,
    0, () => Key
];
var KeySchema = [1, n0, _KS,
    0, () => KeySchemaElement$
];
var KinesisDataStreamDestinations = [1, n0, _KDSD,
    0, () => KinesisDataStreamDestination$
];
var ListAttributeValue = [1, n0, _LAV,
    0, () => AttributeValue$
];
var LocalSecondaryIndexDescriptionList = [1, n0, _LSIDL,
    0, () => LocalSecondaryIndexDescription$
];
var LocalSecondaryIndexes = [1, n0, _LSI,
    0, () => LocalSecondaryIndexInfo$
];
var LocalSecondaryIndexList = [1, n0, _LSIL,
    0, () => LocalSecondaryIndex$
];
var ParameterizedStatements = [1, n0, _PSar,
    0, () => ParameterizedStatement$
];
var PartiQLBatchRequest = [1, n0, _PQLBR,
    0, () => BatchStatementRequest$
];
var PartiQLBatchResponse = [1, n0, _PQLBRa,
    0, () => BatchStatementResponse$
];
var PreparedStatementParameters = [1, n0, _PSP,
    0, () => AttributeValue$
];
var ReplicaAutoScalingDescriptionList = [1, n0, _RASDL,
    0, () => ReplicaAutoScalingDescription$
];
var ReplicaAutoScalingUpdateList = [1, n0, _RASUL,
    0, () => ReplicaAutoScalingUpdate$
];
var ReplicaDescriptionList = [1, n0, _RDL,
    0, () => ReplicaDescription$
];
var ReplicaGlobalSecondaryIndexAutoScalingDescriptionList = [1, n0, _RGSIASDL,
    0, () => ReplicaGlobalSecondaryIndexAutoScalingDescription$
];
var ReplicaGlobalSecondaryIndexAutoScalingUpdateList = [1, n0, _RGSIASUL,
    0, () => ReplicaGlobalSecondaryIndexAutoScalingUpdate$
];
var ReplicaGlobalSecondaryIndexDescriptionList = [1, n0, _RGSIDL,
    0, () => ReplicaGlobalSecondaryIndexDescription$
];
var ReplicaGlobalSecondaryIndexList = [1, n0, _RGSIL,
    0, () => ReplicaGlobalSecondaryIndex$
];
var ReplicaGlobalSecondaryIndexSettingsDescriptionList = [1, n0, _RGSISDL,
    0, () => ReplicaGlobalSecondaryIndexSettingsDescription$
];
var ReplicaGlobalSecondaryIndexSettingsUpdateList = [1, n0, _RGSISUL,
    0, () => ReplicaGlobalSecondaryIndexSettingsUpdate$
];
var ReplicaList = [1, n0, _RL,
    0, () => Replica$
];
var ReplicaSettingsDescriptionList = [1, n0, _RSDL,
    0, () => ReplicaSettingsDescription$
];
var ReplicaSettingsUpdateList = [1, n0, _RSUL,
    0, () => ReplicaSettingsUpdate$
];
var ReplicationGroupUpdateList = [1, n0, _RGUL,
    0, () => ReplicationGroupUpdate$
];
var ReplicaUpdateList = [1, n0, _RUL,
    0, () => ReplicaUpdate$
];
var SearchResultList = [1, n0, _SRL,
    0, () => SearchResultItem$
];
var SearchSchema = [1, n0, _SSe,
    0, () => SearchSchemaElement$
];
var SearchVectorList = [1, n0, _SVL,
    0, () => AttributeValue$
];
var TagList = [1, n0, _TL,
    0, () => Tag$
];
var ThrottlingReasonList = [1, n0, _TRL,
    0, () => ThrottlingReason$
];
var TransactGetItemList = [1, n0, _TGIL,
    0, () => TransactGetItem$
];
var TransactWriteItemList = [1, n0, _TWIL,
    0, () => TransactWriteItem$
];
var VectorIndexDescriptionList = [1, n0, _VIDL,
    0, () => VectorIndexDescription$
];
var VectorIndexes = [1, n0, _VI,
    0, () => VectorIndexInfo$
];
var VectorIndexList = [1, n0, _VIL,
    0, () => VectorIndex$
];
var VectorIndexUpdateList = [1, n0, _VIUL,
    0, () => VectorIndexUpdate$
];
var WriteRequests = [1, n0, _WRr,
    0, () => WriteRequest$
];
var AttributeMap = [2, n0, _AM,
    0, 0, () => AttributeValue$
];
var AttributeUpdates = [2, n0, _AU,
    0, 0, () => AttributeValueUpdate$
];
var BatchGetRequestMap = [2, n0, _BGRMa,
    0, 0, () => KeysAndAttributes$
];
var BatchGetResponseMap = [2, n0, _BGRM,
    0, 0, () => ItemList
];
var BatchWriteItemRequestMap = [2, n0, _BWIRM,
    0, 0, () => WriteRequests
];
var ExpectedAttributeMap = [2, n0, _EAM,
    0, 0, () => ExpectedAttributeValue$
];
var ExpressionAttributeValueMap = [2, n0, _EAVM,
    0, 0, () => AttributeValue$
];
var FilterConditionMap = [2, n0, _FCM,
    0, 0, () => Condition$
];
var ItemCollectionKeyAttributeMap = [2, n0, _ICKAM,
    0, 0, () => AttributeValue$
];
var ItemCollectionMetricsPerTable = [2, n0, _ICMPT,
    0, 0, () => ItemCollectionMetricsMultiple
];
var Key = [2, n0, _K,
    0, 0, () => AttributeValue$
];
var KeyConditions = [2, n0, _KC,
    0, 0, () => Condition$
];
var MapAttributeValue = [2, n0, _MAV,
    0, 0, () => AttributeValue$
];
var PutItemInputAttributeMap = [2, n0, _PIIAM,
    0, 0, () => AttributeValue$
];
var SecondaryIndexesCapacityMap = [2, n0, _SICM,
    0, 0, () => Capacity$
];
var VectorIndexesCapacityMap = [2, n0, _VICM,
    0, 0, () => VectorCapacity$
];
var AttributeValue$ = [4, n0, _AV,
    0,
    [_S_, _N, _B_, _SS_, _NS, _BS_, _M_, _L_, _NULL, _BOOL],
    [0, 0, 21, 64 | 0, 64 | 0, 64 | 21, () => MapAttributeValue, () => ListAttributeValue, 2, 2]
];
var BatchExecuteStatement$ = [9, n0, _BES,
    0, () => BatchExecuteStatementInput$, () => BatchExecuteStatementOutput$
];
var BatchGetItem$ = [9, n0, _BGI,
    0, () => BatchGetItemInput$, () => BatchGetItemOutput$
];
var BatchWriteItem$ = [9, n0, _BWI,
    0, () => BatchWriteItemInput$, () => BatchWriteItemOutput$
];
var CreateBackup$ = [9, n0, _CB,
    0, () => CreateBackupInput$, () => CreateBackupOutput$
];
var CreateGlobalTable$ = [9, n0, _CGT,
    0, () => CreateGlobalTableInput$, () => CreateGlobalTableOutput$
];
var CreateTable$ = [9, n0, _CTr,
    0, () => CreateTableInput$, () => CreateTableOutput$
];
var DeleteBackup$ = [9, n0, _DB,
    0, () => DeleteBackupInput$, () => DeleteBackupOutput$
];
var DeleteItem$ = [9, n0, _DI,
    0, () => DeleteItemInput$, () => DeleteItemOutput$
];
var DeleteResourcePolicy$ = [9, n0, _DRP,
    0, () => DeleteResourcePolicyInput$, () => DeleteResourcePolicyOutput$
];
var DeleteTable$ = [9, n0, _DT,
    0, () => DeleteTableInput$, () => DeleteTableOutput$
];
var DescribeBackup$ = [9, n0, _DBe,
    0, () => DescribeBackupInput$, () => DescribeBackupOutput$
];
var DescribeContinuousBackups$ = [9, n0, _DCB,
    0, () => DescribeContinuousBackupsInput$, () => DescribeContinuousBackupsOutput$
];
var DescribeContributorInsights$ = [9, n0, _DCI,
    0, () => DescribeContributorInsightsInput$, () => DescribeContributorInsightsOutput$
];
var DescribeEndpoints$ = [9, n0, _DE,
    0, () => DescribeEndpointsRequest$, () => DescribeEndpointsResponse$
];
var DescribeExport$ = [9, n0, _DEe,
    0, () => DescribeExportInput$, () => DescribeExportOutput$
];
var DescribeGlobalTable$ = [9, n0, _DGT,
    0, () => DescribeGlobalTableInput$, () => DescribeGlobalTableOutput$
];
var DescribeGlobalTableSettings$ = [9, n0, _DGTS,
    0, () => DescribeGlobalTableSettingsInput$, () => DescribeGlobalTableSettingsOutput$
];
var DescribeImport$ = [9, n0, _DIe,
    0, () => DescribeImportInput$, () => DescribeImportOutput$
];
var DescribeKinesisStreamingDestination$ = [9, n0, _DKSD,
    0, () => DescribeKinesisStreamingDestinationInput$, () => DescribeKinesisStreamingDestinationOutput$
];
var DescribeLimits$ = [9, n0, _DL,
    0, () => DescribeLimitsInput$, () => DescribeLimitsOutput$
];
var DescribeTable$ = [9, n0, _DTe,
    0, () => DescribeTableInput$, () => DescribeTableOutput$
];
var DescribeTableReplicaAutoScaling$ = [9, n0, _DTRAS,
    0, () => DescribeTableReplicaAutoScalingInput$, () => DescribeTableReplicaAutoScalingOutput$
];
var DescribeTimeToLive$ = [9, n0, _DTTL,
    0, () => DescribeTimeToLiveInput$, () => DescribeTimeToLiveOutput$
];
var DisableKinesisStreamingDestination$ = [9, n0, _DKSDi,
    0, () => KinesisStreamingDestinationInput$, () => KinesisStreamingDestinationOutput$
];
var EnableKinesisStreamingDestination$ = [9, n0, _EKSD,
    0, () => KinesisStreamingDestinationInput$, () => KinesisStreamingDestinationOutput$
];
var ExecuteStatement$ = [9, n0, _ESxe,
    0, () => ExecuteStatementInput$, () => ExecuteStatementOutput$
];
var ExecuteTransaction$ = [9, n0, _ETxe,
    0, () => ExecuteTransactionInput$, () => ExecuteTransactionOutput$
];
var ExportTableToPointInTime$ = [9, n0, _ETTPIT,
    0, () => ExportTableToPointInTimeInput$, () => ExportTableToPointInTimeOutput$
];
var GetItem$ = [9, n0, _GI,
    0, () => GetItemInput$, () => GetItemOutput$
];
var GetResourcePolicy$ = [9, n0, _GRP,
    0, () => GetResourcePolicyInput$, () => GetResourcePolicyOutput$
];
var ImportTable$ = [9, n0, _IT,
    0, () => ImportTableInput$, () => ImportTableOutput$
];
var ListBackups$ = [9, n0, _LB,
    0, () => ListBackupsInput$, () => ListBackupsOutput$
];
var ListContributorInsights$ = [9, n0, _LCI,
    0, () => ListContributorInsightsInput$, () => ListContributorInsightsOutput$
];
var ListExports$ = [9, n0, _LE,
    0, () => ListExportsInput$, () => ListExportsOutput$
];
var ListGlobalTables$ = [9, n0, _LGT,
    0, () => ListGlobalTablesInput$, () => ListGlobalTablesOutput$
];
var ListImports$ = [9, n0, _LI,
    0, () => ListImportsInput$, () => ListImportsOutput$
];
var ListTables$ = [9, n0, _LT,
    0, () => ListTablesInput$, () => ListTablesOutput$
];
var ListTagsOfResource$ = [9, n0, _LTOR,
    0, () => ListTagsOfResourceInput$, () => ListTagsOfResourceOutput$
];
var PutItem$ = [9, n0, _PI,
    0, () => PutItemInput$, () => PutItemOutput$
];
var PutResourcePolicy$ = [9, n0, _PRP,
    0, () => PutResourcePolicyInput$, () => PutResourcePolicyOutput$
];
var Query$ = [9, n0, _Q,
    0, () => QueryInput$, () => QueryOutput$
];
var RestoreTableFromBackup$ = [9, n0, _RTFB,
    0, () => RestoreTableFromBackupInput$, () => RestoreTableFromBackupOutput$
];
var RestoreTableToPointInTime$ = [9, n0, _RTTPIT,
    0, () => RestoreTableToPointInTimeInput$, () => RestoreTableToPointInTimeOutput$
];
var Scan$ = [9, n0, _Sca,
    0, () => ScanInput$, () => ScanOutput$
];
var SearchVectors$ = [9, n0, _SVe,
    0, () => SearchVectorsInput$, () => SearchVectorsOutput$
];
var TagResource$ = [9, n0, _TRa,
    0, () => TagResourceInput$, () => __Unit
];
var TransactGetItems$ = [9, n0, _TGIr,
    0, () => TransactGetItemsInput$, () => TransactGetItemsOutput$
];
var TransactWriteItems$ = [9, n0, _TWIr,
    0, () => TransactWriteItemsInput$, () => TransactWriteItemsOutput$
];
var UntagResource$ = [9, n0, _UR,
    0, () => UntagResourceInput$, () => __Unit
];
var UpdateContinuousBackups$ = [9, n0, _UCB,
    0, () => UpdateContinuousBackupsInput$, () => UpdateContinuousBackupsOutput$
];
var UpdateContributorInsights$ = [9, n0, _UCI,
    0, () => UpdateContributorInsightsInput$, () => UpdateContributorInsightsOutput$
];
var UpdateGlobalTable$ = [9, n0, _UGT,
    0, () => UpdateGlobalTableInput$, () => UpdateGlobalTableOutput$
];
var UpdateGlobalTableSettings$ = [9, n0, _UGTS,
    0, () => UpdateGlobalTableSettingsInput$, () => UpdateGlobalTableSettingsOutput$
];
var UpdateItem$ = [9, n0, _UIp,
    0, () => UpdateItemInput$, () => UpdateItemOutput$
];
var UpdateKinesisStreamingDestination$ = [9, n0, _UKSD,
    0, () => UpdateKinesisStreamingDestinationInput$, () => UpdateKinesisStreamingDestinationOutput$
];
var UpdateTable$ = [9, n0, _UT,
    0, () => UpdateTableInput$, () => UpdateTableOutput$
];
var UpdateTableReplicaAutoScaling$ = [9, n0, _UTRAS,
    0, () => UpdateTableReplicaAutoScalingInput$, () => UpdateTableReplicaAutoScalingOutput$
];
var UpdateTimeToLive$ = [9, n0, _UTTL,
    0, () => UpdateTimeToLiveInput$, () => UpdateTimeToLiveOutput$
];

class DescribeEndpointsCommand extends command(_ep0, _mw0, "DescribeEndpoints", DescribeEndpoints$) {
}

var version = "3.1129.0";
var packageInfo = {
	version: version};

const L = "ref", M = "argv";
const a = -1, b = true, c = false, d = "isSet", e = "booleanEquals", f = "PartitionResult", g = "stringEquals", h = "getAttr", i = "parsedEndpoint", j = "aws.parseArn", k = (n) => "ParsedArn_ssa_" + n + "", l = "service", m = "dynamodb", n = "isValidHostLabel", o = "accountId", p = "FirstArn", q = (n) => "https://{ParsedArn_ssa_" + n + "#accountId}.search-ddb.{Region}.{PartitionResult#dualStackDnsSuffix}", s = (n) => "https://{ParsedArn_ssa_" + n + "#accountId}.ddb.{Region}.{PartitionResult#dualStackDnsSuffix}", t = (n) => "https://{ParsedArn_ssa_" + n + "#accountId}.search-ddb.{Region}.{PartitionResult#dnsSuffix}", u = (n) => "https://{ParsedArn_ssa_" + n + "#accountId}.ddb.{Region}.{PartitionResult#dnsSuffix}", v = { [L]: "Region" }, w = { [L]: f }, x = { "fn": h, [M]: [{ [L]: i }, "authority"] }, y = { [L]: "AccountIdEndpointMode" }, z = { "fn": h, [M]: [w, "name"] }, A = { "fn": h, [M]: [{ [L]: "ParsedArn_ssa_2" }, "region"] }, B = { [L]: "ParsedArn_ssa_2" }, C = { [L]: "ResourceArnList" }, D = { "fn": h, [M]: [{ [L]: "ParsedArn_ssa_1" }, "region"] }, E = { [L]: "ParsedArn_ssa_1" }, F = { [L]: "AccountId" }, G = {}, H = { "metricValues": ["O"] }, I = [v], J = [{ [L]: "Endpoint" }], K = [{ [L]: "ResourceArn" }];
const _data = {
    conditions: [
        [d, I],
        [d, J],
        [e, [{ [L]: "UseFIPS" }, b]],
        [e, [{ [L]: "UseDualStack" }, b]],
        ["aws.partition", I, f],
        [g, [v, "local"]],
        [e, [{ fn: h, [M]: [w, "supportsFIPS"] }, b]],
        ["parseURL", J, i],
        [g, ["dynamodb.{Region}.{PartitionResult#dualStackDnsSuffix}", x]],
        [e, [{ fn: h, [M]: [w, "supportsDualStack"] }, b]],
        [g, ["search-dynamodb.{Region}.{PartitionResult#dualStackDnsSuffix}", x]],
        [d, [y]],
        [g, [z, "aws"]],
        [g, [y, "disabled"]],
        [d, K],
        [j, K, k(2)],
        [g, [A, v]],
        [g, [{ fn: h, [M]: [B, l] }, m]],
        [n, [A, c]],
        [n, [{ fn: h, [M]: [B, o] }, c]],
        [d, [C]],
        [h, [C, "[0]"], p],
        [j, [{ [L]: p }], k(1)],
        [g, [D, v]],
        [g, [{ fn: h, [M]: [E, l] }, m]],
        [n, [{ fn: h, [M]: [E, o] }, c]],
        [n, [D, c]],
        [d, [F]],
        [g, [y, "required"]],
        [n, [F, c]],
        [g, [z, "aws-us-gov"]],
        [e, [{ fn: "coalesce", [M]: [{ [L]: "IsSearchOperation" }, c] }, b]]
    ],
    results: [
        [a],
        [a, "Invalid Configuration: FIPS and custom endpoint are not supported"],
        [a, "Invalid Configuration: Dualstack and custom endpoint are not supported"],
        [a, "Endpoint override is not supported for dual-stack endpoints. Please enable dual-stack functionality by enabling the configuration. For more details, see: https://docs.aws.amazon.com/sdkref/latest/guide/feature-endpoints.html"],
        ["{Endpoint}", G],
        [a, "Invalid Configuration: FIPS and local endpoint are not supported"],
        [a, "Invalid Configuration: Dualstack and local endpoint are not supported"],
        ["http://localhost:8000", { authSchemes: [{ signingRegion: "us-east-1", name: "sigv4", signingName: m }] }],
        [a, "Invalid Configuration: AccountIdEndpointMode is required and FIPS is enabled, but FIPS account endpoints are not supported"],
        ["https://search-dynamodb-fips.{Region}.{PartitionResult#dualStackDnsSuffix}", G],
        ["https://dynamodb-fips.{Region}.{PartitionResult#dualStackDnsSuffix}", G],
        [a, "FIPS and DualStack are enabled, but this partition does not support one or both"],
        ["https://search-dynamodb.{Region}.{PartitionResult#dnsSuffix}", G],
        ["https://dynamodb.{Region}.{PartitionResult#dnsSuffix}", G],
        ["https://search-dynamodb-fips.{Region}.{PartitionResult#dnsSuffix}", G],
        ["https://dynamodb-fips.{Region}.{PartitionResult#dnsSuffix}", G],
        [a, "FIPS is enabled but this partition does not support FIPS"],
        [q(2), H],
        [s(2), H],
        [q(1), H],
        [s(1), H],
        ["https://{AccountId}.search-ddb.{Region}.{PartitionResult#dualStackDnsSuffix}", H],
        ["https://{AccountId}.ddb.{Region}.{PartitionResult#dualStackDnsSuffix}", H],
        [a, "Credentials-sourced account ID parameter is invalid"],
        [a, "AccountIdEndpointMode is required but no AccountID was provided or able to be loaded"],
        [a, "Invalid Configuration: AccountIdEndpointMode is required but account endpoints are not supported in this partition"],
        ["https://search-dynamodb.{Region}.{PartitionResult#dualStackDnsSuffix}", G],
        ["https://dynamodb.{Region}.{PartitionResult#dualStackDnsSuffix}", G],
        [a, "DualStack is enabled but this partition does not support DualStack"],
        [t(2), H],
        [u(2), H],
        [t(1), H],
        [u(1), H],
        ["https://{AccountId}.search-ddb.{Region}.{PartitionResult#dnsSuffix}", H],
        ["https://{AccountId}.ddb.{Region}.{PartitionResult#dnsSuffix}", H],
        [a, "Invalid Configuration: Missing Region"]
    ]
};
const root = 2;
const r = 100_000_000;
const nodes = new Int32Array([
    -1, 1, -1,
    0, 6, 3,
    1, 4, r + 35,
    2, r + 1, 5,
    3, r + 2, r + 4,
    1, 77, 7,
    2, 61, 8,
    3, 34, 9,
    4, 10, r + 35,
    5, r + 7, 11,
    11, 12, 69,
    12, 14, 13,
    28, r + 25, 69,
    13, 33, 15,
    14, 16, 21,
    15, 17, 21,
    16, 18, 21,
    17, 19, 21,
    18, 20, 21,
    19, 32, 21,
    20, 22, 28,
    21, 23, 28,
    22, 24, 28,
    23, 25, 28,
    24, 26, 28,
    25, 27, 28,
    26, 31, 28,
    27, 29, 33,
    29, 30, r + 23,
    31, r + 33, r + 34,
    31, r + 31, r + 32,
    31, r + 29, r + 30,
    28, r + 24, 69,
    4, 35, r + 35,
    5, r + 6, 36,
    9, 37, r + 28,
    11, 38, 60,
    12, 40, 39,
    28, r + 25, 60,
    13, 59, 41,
    14, 42, 47,
    15, 43, 47,
    16, 44, 47,
    17, 45, 47,
    18, 46, 47,
    19, 58, 47,
    20, 48, 54,
    21, 49, 54,
    22, 50, 54,
    23, 51, 54,
    24, 52, 54,
    25, 53, 54,
    26, 57, 54,
    27, 55, 59,
    29, 56, r + 23,
    31, r + 21, r + 22,
    31, r + 19, r + 20,
    31, r + 17, r + 18,
    28, r + 24, 60,
    31, r + 26, r + 27,
    3, 70, 62,
    4, 63, r + 35,
    5, r + 5, 64,
    6, 65, r + 16,
    11, 66, 67,
    28, r + 8, 67,
    30, 69, 68,
    31, r + 14, r + 15,
    31, r + 12, r + 13,
    4, 71, r + 35,
    5, r + 5, 72,
    6, 73, r + 11,
    9, 74, r + 11,
    11, 75, 76,
    28, r + 8, 76,
    31, r + 9, r + 10,
    2, r + 1, 78,
    3, r + 2, 79,
    4, 80, r + 4,
    7, 81, r + 4,
    8, r + 3, 82,
    10, r + 3, r + 4,
]);
const bdd = BinaryDecisionDiagram.from(nodes, root, _data.conditions, _data.results);

const cache = new EndpointCache({
    size: 50,
    params: [
        "AccountId",
        "AccountIdEndpointMode",
        "Endpoint",
        "IsSearchOperation",
        "Region",
        "ResourceArn",
        "ResourceArnList",
        "UseDualStack",
        "UseFIPS",
    ],
});
const defaultEndpointResolver = (endpointParams, context = {}) => {
    return cache.get(endpointParams, () => decideEndpoint(bdd, {
        endpointParams: endpointParams,
        logger: context.logger,
    }));
};
customEndpointFunctions.aws = awsEndpointFunctions;

const getRuntimeConfig$1 = (config) => {
    return {
        apiVersion: "2012-08-10",
        base64Decoder: config?.base64Decoder ?? fromBase64,
        base64Encoder: config?.base64Encoder ?? toBase64,
        disableHostPrefix: config?.disableHostPrefix ?? false,
        endpointProvider: config?.endpointProvider ?? defaultEndpointResolver,
        extensions: config?.extensions ?? [],
        httpAuthSchemeProvider: config?.httpAuthSchemeProvider ?? defaultDynamoDBHttpAuthSchemeProvider,
        httpAuthSchemes: config?.httpAuthSchemes ?? [
            {
                schemeId: "aws.auth#sigv4",
                identityProvider: (ipc) => ipc.getIdentityProvider("aws.auth#sigv4"),
                signer: new AwsSdkSigV4Signer(),
            },
        ],
        logger: config?.logger ?? new NoOpLogger(),
        protocol: config?.protocol ?? AwsJson1_0Protocol,
        protocolSettings: config?.protocolSettings ?? {
            defaultNamespace: "com.amazonaws.dynamodb",
            errorTypeRegistries,
            xmlNamespace: "http://dynamodb.amazonaws.com/doc/2012-08-10/",
            version: "2012-08-10",
            serviceTarget: "DynamoDB_20120810",
            jsonCodec: new DynamoDBJsonCodec2(),
        },
        serviceId: config?.serviceId ?? "DynamoDB",
        sha256: config?.sha256 ?? Sha256,
        urlParser: config?.urlParser ?? parseUrl,
        utf8Decoder: config?.utf8Decoder ?? fromUtf8,
        utf8Encoder: config?.utf8Encoder ?? toUtf8,
    };
};

const getRuntimeConfig = (config) => {
    emitWarningIfUnsupportedVersion(process.version);
    const defaultsMode = resolveDefaultsModeConfig(config);
    const defaultConfigProvider = () => defaultsMode().then(loadConfigsForDefaultMode);
    const clientSharedValues = getRuntimeConfig$1(config);
    emitWarningIfUnsupportedVersion$1(process.version);
    const loaderConfig = {
        profile: config?.profile,
        logger: clientSharedValues.logger,
    };
    return {
        ...clientSharedValues,
        ...config,
        runtime: "node",
        defaultsMode,
        accountIdEndpointMode: config?.accountIdEndpointMode ?? loadConfig(NODE_ACCOUNT_ID_ENDPOINT_MODE_CONFIG_OPTIONS, loaderConfig),
        authSchemePreference: config?.authSchemePreference ?? loadConfig(NODE_AUTH_SCHEME_PREFERENCE_OPTIONS, loaderConfig),
        bodyLengthChecker: config?.bodyLengthChecker ?? calculateBodyLength,
        credentialDefaultProvider: config?.credentialDefaultProvider ?? defaultProvider,
        defaultUserAgentProvider: config?.defaultUserAgentProvider ?? createDefaultUserAgentProvider({ serviceId: clientSharedValues.serviceId, clientVersion: packageInfo.version }),
        endpointDiscoveryEnabledProvider: config?.endpointDiscoveryEnabledProvider ?? loadConfig(NODE_ENDPOINT_DISCOVERY_CONFIG_OPTIONS, loaderConfig),
        maxAttempts: config?.maxAttempts ?? loadConfig(Retry.v2026 ? { ...NODE_MAX_ATTEMPT_CONFIG_OPTIONS, default: 4 } : NODE_MAX_ATTEMPT_CONFIG_OPTIONS, config),
        region: config?.region ?? loadConfig(NODE_REGION_CONFIG_OPTIONS, { ...NODE_REGION_CONFIG_FILE_OPTIONS, ...loaderConfig }),
        requestHandler: NodeHttpHandler.create(config?.requestHandler ?? defaultConfigProvider),
        retryMode: config?.retryMode ??
            loadConfig({
                ...NODE_RETRY_MODE_CONFIG_OPTIONS,
                default: async () => (await defaultConfigProvider()).retryMode || DEFAULT_RETRY_MODE,
            }, config),
        streamCollector: config?.streamCollector ?? streamCollector,
        useDualstackEndpoint: config?.useDualstackEndpoint ?? loadConfig(NODE_USE_DUALSTACK_ENDPOINT_CONFIG_OPTIONS, loaderConfig),
        useFipsEndpoint: config?.useFipsEndpoint ?? loadConfig(NODE_USE_FIPS_ENDPOINT_CONFIG_OPTIONS, loaderConfig),
        userAgentAppId: config?.userAgentAppId ?? loadConfig(NODE_APP_ID_CONFIG_OPTIONS, loaderConfig),
    };
};

const getHttpAuthExtensionConfiguration = (runtimeConfig) => {
    const _httpAuthSchemes = runtimeConfig.httpAuthSchemes;
    let _httpAuthSchemeProvider = runtimeConfig.httpAuthSchemeProvider;
    let _credentials = runtimeConfig.credentials;
    return {
        setHttpAuthScheme(httpAuthScheme) {
            const index = _httpAuthSchemes.findIndex((scheme) => scheme.schemeId === httpAuthScheme.schemeId);
            if (index === -1) {
                _httpAuthSchemes.push(httpAuthScheme);
            }
            else {
                _httpAuthSchemes.splice(index, 1, httpAuthScheme);
            }
        },
        httpAuthSchemes() {
            return _httpAuthSchemes;
        },
        setHttpAuthSchemeProvider(httpAuthSchemeProvider) {
            _httpAuthSchemeProvider = httpAuthSchemeProvider;
        },
        httpAuthSchemeProvider() {
            return _httpAuthSchemeProvider;
        },
        setCredentials(credentials) {
            _credentials = credentials;
        },
        credentials() {
            return _credentials;
        },
    };
};
const resolveHttpAuthRuntimeConfig = (config) => {
    return {
        httpAuthSchemes: config.httpAuthSchemes(),
        httpAuthSchemeProvider: config.httpAuthSchemeProvider(),
        credentials: config.credentials(),
    };
};

const resolveRuntimeExtensions = (runtimeConfig, extensions) => {
    const extensionConfiguration = Object.assign(getAwsRegionExtensionConfiguration(runtimeConfig), getDefaultExtensionConfiguration(runtimeConfig), getHttpHandlerExtensionConfiguration(runtimeConfig), getHttpAuthExtensionConfiguration(runtimeConfig));
    extensions.forEach((extension) => extension.configure(extensionConfiguration));
    return Object.assign(runtimeConfig, resolveAwsRegionExtensionConfiguration(extensionConfiguration), resolveDefaultRuntimeConfig(extensionConfiguration), resolveHttpHandlerRuntimeConfig(extensionConfiguration), resolveHttpAuthRuntimeConfig(extensionConfiguration));
};

class DynamoDBClient extends Client {
    config;
    constructor(...[configuration]) {
        const _config_0 = getRuntimeConfig(configuration || {});
        super(_config_0);
        this.initConfig = _config_0;
        const _config_1 = resolveClientEndpointParameters(_config_0);
        const _config_2 = resolveAccountIdEndpointModeConfig(_config_1);
        const _config_3 = resolveUserAgentConfig(_config_2);
        const _config_4 = resolveRetryConfig(_config_3, { defaultBaseDelay: Retry.v2026 ? 25 : undefined, defaultMaxAttempts: Retry.v2026 ? 4 : undefined });
        const _config_5 = resolveRegionConfig(_config_4);
        const _config_6 = resolveHostHeaderConfig(_config_5);
        const _config_7 = resolveEndpointConfig(_config_6);
        const _config_8 = resolveHttpAuthSchemeConfig(_config_7);
        const _config_9 = resolveEndpointDiscoveryConfig(_config_8, { endpointDiscoveryCommandCtor: DescribeEndpointsCommand });
        const _config_10 = resolveRuntimeExtensions(_config_9, configuration?.extensions || []);
        this.config = _config_10;
        this.middlewareStack.use(getSchemaSerdePlugin(this.config));
        this.middlewareStack.use(getUserAgentPlugin(this.config));
        this.middlewareStack.use(getRetryPlugin(this.config));
        this.middlewareStack.use(getContentLengthPlugin(this.config));
        this.middlewareStack.use(getHostHeaderPlugin(this.config));
        this.middlewareStack.use(getLoggerPlugin(this.config));
        this.middlewareStack.use(getRecursionDetectionPlugin(this.config));
        this.middlewareStack.use(getHttpAuthSchemeEndpointRuleSetPlugin(this.config, {
            httpAuthSchemeParametersProvider: defaultDynamoDBHttpAuthSchemeParametersProvider,
            identityProviderConfigProvider: async (config) => new DefaultIdentityProviderConfig({
                "aws.auth#sigv4": config.credentials,
            }),
        }));
        this.middlewareStack.use(getHttpSigningPlugin(this.config));
    }
    destroy() {
        super.destroy();
    }
}

class BatchExecuteStatementCommand extends command(_ep0, _mw0, "BatchExecuteStatement", BatchExecuteStatement$) {
}

class BatchGetItemCommand extends command(_ep1, _mw0, "BatchGetItem", BatchGetItem$) {
}

class BatchWriteItemCommand extends command(_ep1, _mw0, "BatchWriteItem", BatchWriteItem$) {
}

class CreateBackupCommand extends command(_ep2, _mw0, "CreateBackup", CreateBackup$) {
}

class CreateGlobalTableCommand extends command(_ep3, _mw0, "CreateGlobalTable", CreateGlobalTable$) {
}

class CreateTableCommand extends command(_ep2, _mw0, "CreateTable", CreateTable$) {
}

class DeleteBackupCommand extends command(_ep4, _mw0, "DeleteBackup", DeleteBackup$) {
}

class DeleteItemCommand extends command(_ep2, _mw0, "DeleteItem", DeleteItem$) {
}

class DeleteResourcePolicyCommand extends command(_ep5, _mw0, "DeleteResourcePolicy", DeleteResourcePolicy$) {
}

class DeleteTableCommand extends command(_ep2, _mw0, "DeleteTable", DeleteTable$) {
}

class DescribeBackupCommand extends command(_ep4, _mw0, "DescribeBackup", DescribeBackup$) {
}

class DescribeContinuousBackupsCommand extends command(_ep2, _mw0, "DescribeContinuousBackups", DescribeContinuousBackups$) {
}

class DescribeContributorInsightsCommand extends command(_ep2, _mw0, "DescribeContributorInsights", DescribeContributorInsights$) {
}

class DescribeExportCommand extends command(_ep6, _mw0, "DescribeExport", DescribeExport$) {
}

class DescribeGlobalTableCommand extends command(_ep3, _mw0, "DescribeGlobalTable", DescribeGlobalTable$) {
}

class DescribeGlobalTableSettingsCommand extends command(_ep3, _mw0, "DescribeGlobalTableSettings", DescribeGlobalTableSettings$) {
}

class DescribeImportCommand extends command(_ep7, _mw0, "DescribeImport", DescribeImport$) {
}

class DescribeKinesisStreamingDestinationCommand extends command(_ep2, _mw0, "DescribeKinesisStreamingDestination", DescribeKinesisStreamingDestination$) {
}

class DescribeLimitsCommand extends command(_ep0, _mw0, "DescribeLimits", DescribeLimits$) {
}

class DescribeTableCommand extends command(_ep2, _mw0, "DescribeTable", DescribeTable$) {
}

class DescribeTableReplicaAutoScalingCommand extends command(_ep2, _mw0, "DescribeTableReplicaAutoScaling", DescribeTableReplicaAutoScaling$) {
}

class DescribeTimeToLiveCommand extends command(_ep2, _mw0, "DescribeTimeToLive", DescribeTimeToLive$) {
}

class DisableKinesisStreamingDestinationCommand extends command(_ep2, _mw0, "DisableKinesisStreamingDestination", DisableKinesisStreamingDestination$) {
}

class EnableKinesisStreamingDestinationCommand extends command(_ep2, _mw0, "EnableKinesisStreamingDestination", EnableKinesisStreamingDestination$) {
}

class ExecuteStatementCommand extends command(_ep0, _mw0, "ExecuteStatement", ExecuteStatement$) {
}

class ExecuteTransactionCommand extends command(_ep0, _mw0, "ExecuteTransaction", ExecuteTransaction$) {
}

class ExportTableToPointInTimeCommand extends command(_ep8, _mw0, "ExportTableToPointInTime", ExportTableToPointInTime$) {
}

class GetItemCommand extends command(_ep2, _mw0, "GetItem", GetItem$) {
}

class GetResourcePolicyCommand extends command(_ep5, _mw0, "GetResourcePolicy", GetResourcePolicy$) {
}

class ImportTableCommand extends command(_ep9, _mw0, "ImportTable", ImportTable$) {
}

class ListBackupsCommand extends command(_ep2, _mw0, "ListBackups", ListBackups$) {
}

class ListContributorInsightsCommand extends command(_ep2, _mw0, "ListContributorInsights", ListContributorInsights$) {
}

class ListExportsCommand extends command(_ep8, _mw0, "ListExports", ListExports$) {
}

class ListGlobalTablesCommand extends command(_ep0, _mw0, "ListGlobalTables", ListGlobalTables$) {
}

class ListImportsCommand extends command(_ep8, _mw0, "ListImports", ListImports$) {
}

class ListTablesCommand extends command(_ep0, _mw0, "ListTables", ListTables$) {
}

class ListTagsOfResourceCommand extends command(_ep5, _mw0, "ListTagsOfResource", ListTagsOfResource$) {
}

class PutItemCommand extends command(_ep2, _mw0, "PutItem", PutItem$) {
}

class PutResourcePolicyCommand extends command(_ep5, _mw0, "PutResourcePolicy", PutResourcePolicy$) {
}

class QueryCommand extends command(_ep2, _mw0, "Query", Query$) {
}

class RestoreTableFromBackupCommand extends command(_ep10, _mw0, "RestoreTableFromBackup", RestoreTableFromBackup$) {
}

class RestoreTableToPointInTimeCommand extends command(_ep10, _mw0, "RestoreTableToPointInTime", RestoreTableToPointInTime$) {
}

class ScanCommand extends command(_ep2, _mw0, "Scan", Scan$) {
}

class SearchVectorsCommand extends command(_ep11, _mw0, "SearchVectors", SearchVectors$) {
}

class TagResourceCommand extends command(_ep5, _mw0, "TagResource", TagResource$) {
}

class TransactGetItemsCommand extends command(_ep12, _mw0, "TransactGetItems", TransactGetItems$) {
}

class TransactWriteItemsCommand extends command(_ep13, _mw0, "TransactWriteItems", TransactWriteItems$) {
}

class UntagResourceCommand extends command(_ep5, _mw0, "UntagResource", UntagResource$) {
}

class UpdateContinuousBackupsCommand extends command(_ep2, _mw0, "UpdateContinuousBackups", UpdateContinuousBackups$) {
}

class UpdateContributorInsightsCommand extends command(_ep2, _mw0, "UpdateContributorInsights", UpdateContributorInsights$) {
}

class UpdateGlobalTableCommand extends command(_ep3, _mw0, "UpdateGlobalTable", UpdateGlobalTable$) {
}

class UpdateGlobalTableSettingsCommand extends command(_ep3, _mw0, "UpdateGlobalTableSettings", UpdateGlobalTableSettings$) {
}

class UpdateItemCommand extends command(_ep2, _mw0, "UpdateItem", UpdateItem$) {
}

class UpdateKinesisStreamingDestinationCommand extends command(_ep2, _mw0, "UpdateKinesisStreamingDestination", UpdateKinesisStreamingDestination$) {
}

class UpdateTableCommand extends command(_ep2, _mw0, "UpdateTable", UpdateTable$) {
}

class UpdateTableReplicaAutoScalingCommand extends command(_ep2, _mw0, "UpdateTableReplicaAutoScaling", UpdateTableReplicaAutoScaling$) {
}

class UpdateTimeToLiveCommand extends command(_ep2, _mw0, "UpdateTimeToLive", UpdateTimeToLive$) {
}

const paginateListContributorInsights = createPaginator(DynamoDBClient, ListContributorInsightsCommand, "NextToken", "NextToken", "MaxResults");

const paginateListExports = createPaginator(DynamoDBClient, ListExportsCommand, "NextToken", "NextToken", "MaxResults");

const paginateListImports = createPaginator(DynamoDBClient, ListImportsCommand, "NextToken", "NextToken", "PageSize");

const paginateListTables = createPaginator(DynamoDBClient, ListTablesCommand, "ExclusiveStartTableName", "LastEvaluatedTableName", "Limit");

const paginateQuery = createPaginator(DynamoDBClient, QueryCommand, "ExclusiveStartKey", "LastEvaluatedKey", "Limit");

const paginateScan = createPaginator(DynamoDBClient, ScanCommand, "ExclusiveStartKey", "LastEvaluatedKey", "Limit");

const checkState$5 = async (client, input) => {
    let reason;
    try {
        let result = await client.send(new DescribeContributorInsightsCommand(input));
        reason = result;
        try {
            const returnComparator = () => {
                return result.ContributorInsightsStatus;
            };
            if (returnComparator() === "ENABLED") {
                return { state: WaiterState.SUCCESS, reason };
            }
        }
        catch (e) { }
        try {
            const returnComparator = () => {
                return result.ContributorInsightsStatus;
            };
            if (returnComparator() === "FAILED") {
                return { state: WaiterState.FAILURE, reason };
            }
        }
        catch (e) { }
    }
    catch (exception) {
        reason = exception;
    }
    return { state: WaiterState.RETRY, reason };
};
const waitForContributorInsightsEnabled = async (params, input) => {
    const serviceDefaults = { minDelay: 20, maxDelay: 120 };
    return createWaiter({ ...serviceDefaults, ...params }, input, checkState$5);
};
const waitUntilContributorInsightsEnabled = async (params, input) => {
    const serviceDefaults = { minDelay: 20, maxDelay: 120 };
    const result = await createWaiter({ ...serviceDefaults, ...params }, input, checkState$5);
    return checkExceptions(result);
};

const checkState$4 = async (client, input) => {
    let reason;
    try {
        let result = await client.send(new DescribeExportCommand(input));
        reason = result;
        try {
            const returnComparator = () => {
                return result.ExportDescription.ExportStatus;
            };
            if (returnComparator() === "COMPLETED") {
                return { state: WaiterState.SUCCESS, reason };
            }
        }
        catch (e) { }
        try {
            const returnComparator = () => {
                return result.ExportDescription.ExportStatus;
            };
            if (returnComparator() === "FAILED") {
                return { state: WaiterState.FAILURE, reason };
            }
        }
        catch (e) { }
    }
    catch (exception) {
        reason = exception;
    }
    return { state: WaiterState.RETRY, reason };
};
const waitForExportCompleted = async (params, input) => {
    const serviceDefaults = { minDelay: 20, maxDelay: 120 };
    return createWaiter({ ...serviceDefaults, ...params }, input, checkState$4);
};
const waitUntilExportCompleted = async (params, input) => {
    const serviceDefaults = { minDelay: 20, maxDelay: 120 };
    const result = await createWaiter({ ...serviceDefaults, ...params }, input, checkState$4);
    return checkExceptions(result);
};

const checkState$3 = async (client, input) => {
    let reason;
    try {
        let result = await client.send(new DescribeImportCommand(input));
        reason = result;
        try {
            const returnComparator = () => {
                return result.ImportTableDescription.ImportStatus;
            };
            if (returnComparator() === "COMPLETED") {
                return { state: WaiterState.SUCCESS, reason };
            }
        }
        catch (e) { }
        try {
            const returnComparator = () => {
                return result.ImportTableDescription.ImportStatus;
            };
            if (returnComparator() === "FAILED") {
                return { state: WaiterState.FAILURE, reason };
            }
        }
        catch (e) { }
        try {
            const returnComparator = () => {
                return result.ImportTableDescription.ImportStatus;
            };
            if (returnComparator() === "CANCELLED") {
                return { state: WaiterState.FAILURE, reason };
            }
        }
        catch (e) { }
    }
    catch (exception) {
        reason = exception;
    }
    return { state: WaiterState.RETRY, reason };
};
const waitForImportCompleted = async (params, input) => {
    const serviceDefaults = { minDelay: 20, maxDelay: 120 };
    return createWaiter({ ...serviceDefaults, ...params }, input, checkState$3);
};
const waitUntilImportCompleted = async (params, input) => {
    const serviceDefaults = { minDelay: 20, maxDelay: 120 };
    const result = await createWaiter({ ...serviceDefaults, ...params }, input, checkState$3);
    return checkExceptions(result);
};

const checkState$2 = async (client, input) => {
    let reason;
    try {
        let result = await client.send(new DescribeKinesisStreamingDestinationCommand(input));
        reason = result;
        try {
            const returnComparator = () => {
                let flat_1 = [].concat(...result.KinesisDataStreamDestinations);
                let projection_3 = flat_1.map((element_2) => {
                    return element_2.DestinationStatus;
                });
                return projection_3;
            };
            for (let anyStringEq_4 of returnComparator()) {
                if (anyStringEq_4 == "ACTIVE") {
                    return { state: WaiterState.SUCCESS, reason };
                }
            }
        }
        catch (e) { }
        try {
            const returnComparator = () => {
                let filterRes_2 = result.KinesisDataStreamDestinations.filter((element_1) => {
                    return (((element_1.DestinationStatus == "DISABLED") || (element_1.DestinationStatus == "ENABLE_FAILED")) && ((element_1.DestinationStatus == "ENABLE_FAILED") || (element_1.DestinationStatus == "DISABLED")));
                });
                return ((result.KinesisDataStreamDestinations.length > 0) && (filterRes_2.length == result.KinesisDataStreamDestinations.length));
            };
            if (returnComparator() == true) {
                return { state: WaiterState.FAILURE, reason };
            }
        }
        catch (e) { }
    }
    catch (exception) {
        reason = exception;
    }
    return { state: WaiterState.RETRY, reason };
};
const waitForKinesisStreamingDestinationActive = async (params, input) => {
    const serviceDefaults = { minDelay: 20, maxDelay: 120 };
    return createWaiter({ ...serviceDefaults, ...params }, input, checkState$2);
};
const waitUntilKinesisStreamingDestinationActive = async (params, input) => {
    const serviceDefaults = { minDelay: 20, maxDelay: 120 };
    const result = await createWaiter({ ...serviceDefaults, ...params }, input, checkState$2);
    return checkExceptions(result);
};

const checkState$1 = async (client, input) => {
    let reason;
    try {
        let result = await client.send(new DescribeTableCommand(input));
        reason = result;
        try {
            const returnComparator = () => {
                return result.Table.TableStatus;
            };
            if (returnComparator() === "ACTIVE") {
                return { state: WaiterState.SUCCESS, reason };
            }
        }
        catch (e) { }
    }
    catch (exception) {
        reason = exception;
        if (exception.name === "ResourceNotFoundException") {
            return { state: WaiterState.RETRY, reason };
        }
    }
    return { state: WaiterState.RETRY, reason };
};
const waitForTableExists = async (params, input) => {
    const serviceDefaults = { minDelay: 20, maxDelay: 120 };
    return createWaiter({ ...serviceDefaults, ...params }, input, checkState$1);
};
const waitUntilTableExists = async (params, input) => {
    const serviceDefaults = { minDelay: 20, maxDelay: 120 };
    const result = await createWaiter({ ...serviceDefaults, ...params }, input, checkState$1);
    return checkExceptions(result);
};

const checkState = async (client, input) => {
    let reason;
    try {
        let result = await client.send(new DescribeTableCommand(input));
        reason = result;
    }
    catch (exception) {
        reason = exception;
        if (exception.name === "ResourceNotFoundException") {
            return { state: WaiterState.SUCCESS, reason };
        }
    }
    return { state: WaiterState.RETRY, reason };
};
const waitForTableNotExists = async (params, input) => {
    const serviceDefaults = { minDelay: 20, maxDelay: 120 };
    return createWaiter({ ...serviceDefaults, ...params }, input, checkState);
};
const waitUntilTableNotExists = async (params, input) => {
    const serviceDefaults = { minDelay: 20, maxDelay: 120 };
    const result = await createWaiter({ ...serviceDefaults, ...params }, input, checkState);
    return checkExceptions(result);
};

const commands = {
    BatchExecuteStatementCommand,
    BatchGetItemCommand,
    BatchWriteItemCommand,
    CreateBackupCommand,
    CreateGlobalTableCommand,
    CreateTableCommand,
    DeleteBackupCommand,
    DeleteItemCommand,
    DeleteResourcePolicyCommand,
    DeleteTableCommand,
    DescribeBackupCommand,
    DescribeContinuousBackupsCommand,
    DescribeContributorInsightsCommand,
    DescribeEndpointsCommand,
    DescribeExportCommand,
    DescribeGlobalTableCommand,
    DescribeGlobalTableSettingsCommand,
    DescribeImportCommand,
    DescribeKinesisStreamingDestinationCommand,
    DescribeLimitsCommand,
    DescribeTableCommand,
    DescribeTableReplicaAutoScalingCommand,
    DescribeTimeToLiveCommand,
    DisableKinesisStreamingDestinationCommand,
    EnableKinesisStreamingDestinationCommand,
    ExecuteStatementCommand,
    ExecuteTransactionCommand,
    ExportTableToPointInTimeCommand,
    GetItemCommand,
    GetResourcePolicyCommand,
    ImportTableCommand,
    ListBackupsCommand,
    ListContributorInsightsCommand,
    ListExportsCommand,
    ListGlobalTablesCommand,
    ListImportsCommand,
    ListTablesCommand,
    ListTagsOfResourceCommand,
    PutItemCommand,
    PutResourcePolicyCommand,
    QueryCommand,
    RestoreTableFromBackupCommand,
    RestoreTableToPointInTimeCommand,
    ScanCommand,
    SearchVectorsCommand,
    TagResourceCommand,
    TransactGetItemsCommand,
    TransactWriteItemsCommand,
    UntagResourceCommand,
    UpdateContinuousBackupsCommand,
    UpdateContributorInsightsCommand,
    UpdateGlobalTableCommand,
    UpdateGlobalTableSettingsCommand,
    UpdateItemCommand,
    UpdateKinesisStreamingDestinationCommand,
    UpdateTableCommand,
    UpdateTableReplicaAutoScalingCommand,
    UpdateTimeToLiveCommand,
};
const paginators = {
    paginateListContributorInsights,
    paginateListExports,
    paginateListImports,
    paginateListTables,
    paginateQuery,
    paginateScan,
};
const waiters = {
    waitUntilContributorInsightsEnabled,
    waitUntilExportCompleted,
    waitUntilImportCompleted,
    waitUntilKinesisStreamingDestinationActive,
    waitUntilTableExists,
    waitUntilTableNotExists,
};
class DynamoDB extends DynamoDBClient {
}
createAggregatedClient(commands, DynamoDB, { paginators, waiters });

const ApproximateCreationDateTimePrecision = {
    MICROSECOND: "MICROSECOND",
    MILLISECOND: "MILLISECOND",
};
const AttributeAction = {
    ADD: "ADD",
    DELETE: "DELETE",
    PUT: "PUT",
};
const ScalarAttributeType = {
    B: "B",
    N: "N",
    S: "S",
};
const BackupStatus = {
    AVAILABLE: "AVAILABLE",
    CREATING: "CREATING",
    DELETED: "DELETED",
};
const BackupType = {
    AWS_BACKUP: "AWS_BACKUP",
    SYSTEM: "SYSTEM",
    USER: "USER",
};
const BillingMode = {
    PAY_PER_REQUEST: "PAY_PER_REQUEST",
    PROVISIONED: "PROVISIONED",
};
const KeyType = {
    HASH: "HASH",
    RANGE: "RANGE",
};
const ProjectionType = {
    ALL: "ALL",
    INCLUDE: "INCLUDE",
    KEYS_ONLY: "KEYS_ONLY",
};
const SSEType = {
    AES256: "AES256",
    KMS: "KMS",
};
const SSEStatus = {
    DISABLED: "DISABLED",
    DISABLING: "DISABLING",
    ENABLED: "ENABLED",
    ENABLING: "ENABLING",
    UPDATING: "UPDATING",
};
const StreamViewType = {
    KEYS_ONLY: "KEYS_ONLY",
    NEW_AND_OLD_IMAGES: "NEW_AND_OLD_IMAGES",
    NEW_IMAGE: "NEW_IMAGE",
    OLD_IMAGE: "OLD_IMAGE",
};
const TimeToLiveStatus = {
    DISABLED: "DISABLED",
    DISABLING: "DISABLING",
    ENABLED: "ENABLED",
    ENABLING: "ENABLING",
};
const VectorDistanceFunction = {
    COSINE: "COSINE",
    DOT_PRODUCT: "DOT_PRODUCT",
    EUCLIDEAN: "EUCLIDEAN",
};
const SearchSchemaElementType = {
    HASH: "HASH",
    INLINE_FILTER: "INLINE_FILTER",
};
const BackupTypeFilter = {
    ALL: "ALL",
    AWS_BACKUP: "AWS_BACKUP",
    SYSTEM: "SYSTEM",
    USER: "USER",
};
const ReturnConsumedCapacity = {
    INDEXES: "INDEXES",
    NONE: "NONE",
    TOTAL: "TOTAL",
};
const ReturnValuesOnConditionCheckFailure = {
    ALL_OLD: "ALL_OLD",
    NONE: "NONE",
};
const BatchStatementErrorCodeEnum = {
    AccessDenied: "AccessDenied",
    ConditionalCheckFailed: "ConditionalCheckFailed",
    DuplicateItem: "DuplicateItem",
    InternalServerError: "InternalServerError",
    ItemCollectionSizeLimitExceeded: "ItemCollectionSizeLimitExceeded",
    ProvisionedThroughputExceeded: "ProvisionedThroughputExceeded",
    RequestLimitExceeded: "RequestLimitExceeded",
    ResourceNotFound: "ResourceNotFound",
    ThrottlingError: "ThrottlingError",
    TransactionConflict: "TransactionConflict",
    ValidationError: "ValidationError",
};
const ReturnItemCollectionMetrics = {
    NONE: "NONE",
    SIZE: "SIZE",
};
const ComparisonOperator = {
    BEGINS_WITH: "BEGINS_WITH",
    BETWEEN: "BETWEEN",
    CONTAINS: "CONTAINS",
    EQ: "EQ",
    GE: "GE",
    GT: "GT",
    IN: "IN",
    LE: "LE",
    LT: "LT",
    NE: "NE",
    NOT_CONTAINS: "NOT_CONTAINS",
    NOT_NULL: "NOT_NULL",
    NULL: "NULL",
};
const ConditionalOperator = {
    AND: "AND",
    OR: "OR",
};
const ContinuousBackupsStatus = {
    DISABLED: "DISABLED",
    ENABLED: "ENABLED",
};
const PointInTimeRecoveryStatus = {
    DISABLED: "DISABLED",
    ENABLED: "ENABLED",
};
const ContributorInsightsAction = {
    DISABLE: "DISABLE",
    ENABLE: "ENABLE",
};
const ContributorInsightsMode = {
    ACCESSED_AND_THROTTLED_KEYS: "ACCESSED_AND_THROTTLED_KEYS",
    THROTTLED_KEYS: "THROTTLED_KEYS",
};
const ContributorInsightsStatus = {
    DISABLED: "DISABLED",
    DISABLING: "DISABLING",
    ENABLED: "ENABLED",
    ENABLING: "ENABLING",
    FAILED: "FAILED",
};
const GlobalTableStatus = {
    ACTIVE: "ACTIVE",
    CREATING: "CREATING",
    DELETING: "DELETING",
    UPDATING: "UPDATING",
};
const IndexStatus = {
    ACTIVE: "ACTIVE",
    CREATING: "CREATING",
    DELETING: "DELETING",
    UPDATING: "UPDATING",
};
const GlobalTableSettingsReplicationMode = {
    DISABLED: "DISABLED",
    ENABLED: "ENABLED",
    ENABLED_WITH_OVERRIDES: "ENABLED_WITH_OVERRIDES",
};
const ReplicaStatus = {
    ACTIVE: "ACTIVE",
    ARCHIVED: "ARCHIVED",
    ARCHIVING: "ARCHIVING",
    CREATING: "CREATING",
    CREATION_FAILED: "CREATION_FAILED",
    DELETING: "DELETING",
    INACCESSIBLE_ENCRYPTION_CREDENTIALS: "INACCESSIBLE_ENCRYPTION_CREDENTIALS",
    REGION_DISABLED: "REGION_DISABLED",
    REPLICATION_NOT_AUTHORIZED: "REPLICATION_NOT_AUTHORIZED",
    UPDATING: "UPDATING",
};
const TableClass = {
    STANDARD: "STANDARD",
    STANDARD_INFREQUENT_ACCESS: "STANDARD_INFREQUENT_ACCESS",
};
const TableStatus = {
    ACTIVE: "ACTIVE",
    ARCHIVED: "ARCHIVED",
    ARCHIVING: "ARCHIVING",
    CREATING: "CREATING",
    DELETING: "DELETING",
    INACCESSIBLE_ENCRYPTION_CREDENTIALS: "INACCESSIBLE_ENCRYPTION_CREDENTIALS",
    REPLICATION_NOT_AUTHORIZED: "REPLICATION_NOT_AUTHORIZED",
    UPDATING: "UPDATING",
};
const WitnessStatus = {
    ACTIVE: "ACTIVE",
    CREATING: "CREATING",
    DELETING: "DELETING",
};
const MultiRegionConsistency = {
    EVENTUAL: "EVENTUAL",
    STRONG: "STRONG",
};
const ReturnValue = {
    ALL_NEW: "ALL_NEW",
    ALL_OLD: "ALL_OLD",
    NONE: "NONE",
    UPDATED_NEW: "UPDATED_NEW",
    UPDATED_OLD: "UPDATED_OLD",
};
const ExportFormat = {
    DYNAMODB_JSON: "DYNAMODB_JSON",
    ION: "ION",
};
const ExportStatus = {
    COMPLETED: "COMPLETED",
    FAILED: "FAILED",
    IN_PROGRESS: "IN_PROGRESS",
};
const ExportType = {
    FULL_EXPORT: "FULL_EXPORT",
    INCREMENTAL_EXPORT: "INCREMENTAL_EXPORT",
};
const ExportViewType = {
    NEW_AND_OLD_IMAGES: "NEW_AND_OLD_IMAGES",
    NEW_IMAGE: "NEW_IMAGE",
};
const S3SseAlgorithm = {
    AES256: "AES256",
    KMS: "KMS",
};
const ImportStatus = {
    CANCELLED: "CANCELLED",
    CANCELLING: "CANCELLING",
    COMPLETED: "COMPLETED",
    FAILED: "FAILED",
    IN_PROGRESS: "IN_PROGRESS",
};
const InputCompressionType = {
    GZIP: "GZIP",
    NONE: "NONE",
    ZSTD: "ZSTD",
};
const InputFormat = {
    CSV: "CSV",
    DYNAMODB_JSON: "DYNAMODB_JSON",
    ION: "ION",
};
const DestinationStatus = {
    ACTIVE: "ACTIVE",
    DISABLED: "DISABLED",
    DISABLING: "DISABLING",
    ENABLE_FAILED: "ENABLE_FAILED",
    ENABLING: "ENABLING",
    UPDATING: "UPDATING",
};
const Select = {
    ALL_ATTRIBUTES: "ALL_ATTRIBUTES",
    ALL_PROJECTED_ATTRIBUTES: "ALL_PROJECTED_ATTRIBUTES",
    COUNT: "COUNT",
    SPECIFIC_ATTRIBUTES: "SPECIFIC_ATTRIBUTES",
};

exports.ApproximateCreationDateTimePrecision = ApproximateCreationDateTimePrecision;
exports.ArchivalSummary$ = ArchivalSummary$;
exports.AttributeAction = AttributeAction;
exports.AttributeDefinition$ = AttributeDefinition$;
exports.AttributeValue$ = AttributeValue$;
exports.AttributeValueUpdate$ = AttributeValueUpdate$;
exports.AutoScalingPolicyDescription$ = AutoScalingPolicyDescription$;
exports.AutoScalingPolicyUpdate$ = AutoScalingPolicyUpdate$;
exports.AutoScalingSettingsDescription$ = AutoScalingSettingsDescription$;
exports.AutoScalingSettingsUpdate$ = AutoScalingSettingsUpdate$;
exports.AutoScalingTargetTrackingScalingPolicyConfigurationDescription$ = AutoScalingTargetTrackingScalingPolicyConfigurationDescription$;
exports.AutoScalingTargetTrackingScalingPolicyConfigurationUpdate$ = AutoScalingTargetTrackingScalingPolicyConfigurationUpdate$;
exports.BackupDescription$ = BackupDescription$;
exports.BackupDetails$ = BackupDetails$;
exports.BackupInUseException = BackupInUseException;
exports.BackupInUseException$ = BackupInUseException$;
exports.BackupNotFoundException = BackupNotFoundException;
exports.BackupNotFoundException$ = BackupNotFoundException$;
exports.BackupStatus = BackupStatus;
exports.BackupSummary$ = BackupSummary$;
exports.BackupType = BackupType;
exports.BackupTypeFilter = BackupTypeFilter;
exports.BatchExecuteStatement$ = BatchExecuteStatement$;
exports.BatchExecuteStatementCommand = BatchExecuteStatementCommand;
exports.BatchExecuteStatementInput$ = BatchExecuteStatementInput$;
exports.BatchExecuteStatementOutput$ = BatchExecuteStatementOutput$;
exports.BatchGetItem$ = BatchGetItem$;
exports.BatchGetItemCommand = BatchGetItemCommand;
exports.BatchGetItemInput$ = BatchGetItemInput$;
exports.BatchGetItemOutput$ = BatchGetItemOutput$;
exports.BatchStatementError$ = BatchStatementError$;
exports.BatchStatementErrorCodeEnum = BatchStatementErrorCodeEnum;
exports.BatchStatementRequest$ = BatchStatementRequest$;
exports.BatchStatementResponse$ = BatchStatementResponse$;
exports.BatchWriteItem$ = BatchWriteItem$;
exports.BatchWriteItemCommand = BatchWriteItemCommand;
exports.BatchWriteItemInput$ = BatchWriteItemInput$;
exports.BatchWriteItemOutput$ = BatchWriteItemOutput$;
exports.BillingMode = BillingMode;
exports.BillingModeSummary$ = BillingModeSummary$;
exports.CancellationReason$ = CancellationReason$;
exports.Capacity$ = Capacity$;
exports.ComparisonOperator = ComparisonOperator;
exports.Condition$ = Condition$;
exports.ConditionCheck$ = ConditionCheck$;
exports.ConditionalCheckFailedException = ConditionalCheckFailedException;
exports.ConditionalCheckFailedException$ = ConditionalCheckFailedException$;
exports.ConditionalOperator = ConditionalOperator;
exports.ConsumedCapacity$ = ConsumedCapacity$;
exports.ContinuousBackupsDescription$ = ContinuousBackupsDescription$;
exports.ContinuousBackupsStatus = ContinuousBackupsStatus;
exports.ContinuousBackupsUnavailableException = ContinuousBackupsUnavailableException;
exports.ContinuousBackupsUnavailableException$ = ContinuousBackupsUnavailableException$;
exports.ContributorInsightsAction = ContributorInsightsAction;
exports.ContributorInsightsMode = ContributorInsightsMode;
exports.ContributorInsightsStatus = ContributorInsightsStatus;
exports.ContributorInsightsSummary$ = ContributorInsightsSummary$;
exports.CreateBackup$ = CreateBackup$;
exports.CreateBackupCommand = CreateBackupCommand;
exports.CreateBackupInput$ = CreateBackupInput$;
exports.CreateBackupOutput$ = CreateBackupOutput$;
exports.CreateGlobalSecondaryIndexAction$ = CreateGlobalSecondaryIndexAction$;
exports.CreateGlobalTable$ = CreateGlobalTable$;
exports.CreateGlobalTableCommand = CreateGlobalTableCommand;
exports.CreateGlobalTableInput$ = CreateGlobalTableInput$;
exports.CreateGlobalTableOutput$ = CreateGlobalTableOutput$;
exports.CreateGlobalTableWitnessGroupMemberAction$ = CreateGlobalTableWitnessGroupMemberAction$;
exports.CreateReplicaAction$ = CreateReplicaAction$;
exports.CreateReplicationGroupMemberAction$ = CreateReplicationGroupMemberAction$;
exports.CreateTable$ = CreateTable$;
exports.CreateTableCommand = CreateTableCommand;
exports.CreateTableInput$ = CreateTableInput$;
exports.CreateTableOutput$ = CreateTableOutput$;
exports.CreateVectorIndexAction$ = CreateVectorIndexAction$;
exports.CsvOptions$ = CsvOptions$;
exports.Delete$ = Delete$;
exports.DeleteBackup$ = DeleteBackup$;
exports.DeleteBackupCommand = DeleteBackupCommand;
exports.DeleteBackupInput$ = DeleteBackupInput$;
exports.DeleteBackupOutput$ = DeleteBackupOutput$;
exports.DeleteGlobalSecondaryIndexAction$ = DeleteGlobalSecondaryIndexAction$;
exports.DeleteGlobalTableWitnessGroupMemberAction$ = DeleteGlobalTableWitnessGroupMemberAction$;
exports.DeleteItem$ = DeleteItem$;
exports.DeleteItemCommand = DeleteItemCommand;
exports.DeleteItemInput$ = DeleteItemInput$;
exports.DeleteItemOutput$ = DeleteItemOutput$;
exports.DeleteReplicaAction$ = DeleteReplicaAction$;
exports.DeleteReplicationGroupMemberAction$ = DeleteReplicationGroupMemberAction$;
exports.DeleteRequest$ = DeleteRequest$;
exports.DeleteResourcePolicy$ = DeleteResourcePolicy$;
exports.DeleteResourcePolicyCommand = DeleteResourcePolicyCommand;
exports.DeleteResourcePolicyInput$ = DeleteResourcePolicyInput$;
exports.DeleteResourcePolicyOutput$ = DeleteResourcePolicyOutput$;
exports.DeleteTable$ = DeleteTable$;
exports.DeleteTableCommand = DeleteTableCommand;
exports.DeleteTableInput$ = DeleteTableInput$;
exports.DeleteTableOutput$ = DeleteTableOutput$;
exports.DeleteVectorIndexAction$ = DeleteVectorIndexAction$;
exports.DescribeBackup$ = DescribeBackup$;
exports.DescribeBackupCommand = DescribeBackupCommand;
exports.DescribeBackupInput$ = DescribeBackupInput$;
exports.DescribeBackupOutput$ = DescribeBackupOutput$;
exports.DescribeContinuousBackups$ = DescribeContinuousBackups$;
exports.DescribeContinuousBackupsCommand = DescribeContinuousBackupsCommand;
exports.DescribeContinuousBackupsInput$ = DescribeContinuousBackupsInput$;
exports.DescribeContinuousBackupsOutput$ = DescribeContinuousBackupsOutput$;
exports.DescribeContributorInsights$ = DescribeContributorInsights$;
exports.DescribeContributorInsightsCommand = DescribeContributorInsightsCommand;
exports.DescribeContributorInsightsInput$ = DescribeContributorInsightsInput$;
exports.DescribeContributorInsightsOutput$ = DescribeContributorInsightsOutput$;
exports.DescribeEndpoints$ = DescribeEndpoints$;
exports.DescribeEndpointsCommand = DescribeEndpointsCommand;
exports.DescribeEndpointsRequest$ = DescribeEndpointsRequest$;
exports.DescribeEndpointsResponse$ = DescribeEndpointsResponse$;
exports.DescribeExport$ = DescribeExport$;
exports.DescribeExportCommand = DescribeExportCommand;
exports.DescribeExportInput$ = DescribeExportInput$;
exports.DescribeExportOutput$ = DescribeExportOutput$;
exports.DescribeGlobalTable$ = DescribeGlobalTable$;
exports.DescribeGlobalTableCommand = DescribeGlobalTableCommand;
exports.DescribeGlobalTableInput$ = DescribeGlobalTableInput$;
exports.DescribeGlobalTableOutput$ = DescribeGlobalTableOutput$;
exports.DescribeGlobalTableSettings$ = DescribeGlobalTableSettings$;
exports.DescribeGlobalTableSettingsCommand = DescribeGlobalTableSettingsCommand;
exports.DescribeGlobalTableSettingsInput$ = DescribeGlobalTableSettingsInput$;
exports.DescribeGlobalTableSettingsOutput$ = DescribeGlobalTableSettingsOutput$;
exports.DescribeImport$ = DescribeImport$;
exports.DescribeImportCommand = DescribeImportCommand;
exports.DescribeImportInput$ = DescribeImportInput$;
exports.DescribeImportOutput$ = DescribeImportOutput$;
exports.DescribeKinesisStreamingDestination$ = DescribeKinesisStreamingDestination$;
exports.DescribeKinesisStreamingDestinationCommand = DescribeKinesisStreamingDestinationCommand;
exports.DescribeKinesisStreamingDestinationInput$ = DescribeKinesisStreamingDestinationInput$;
exports.DescribeKinesisStreamingDestinationOutput$ = DescribeKinesisStreamingDestinationOutput$;
exports.DescribeLimits$ = DescribeLimits$;
exports.DescribeLimitsCommand = DescribeLimitsCommand;
exports.DescribeLimitsInput$ = DescribeLimitsInput$;
exports.DescribeLimitsOutput$ = DescribeLimitsOutput$;
exports.DescribeTable$ = DescribeTable$;
exports.DescribeTableCommand = DescribeTableCommand;
exports.DescribeTableInput$ = DescribeTableInput$;
exports.DescribeTableOutput$ = DescribeTableOutput$;
exports.DescribeTableReplicaAutoScaling$ = DescribeTableReplicaAutoScaling$;
exports.DescribeTableReplicaAutoScalingCommand = DescribeTableReplicaAutoScalingCommand;
exports.DescribeTableReplicaAutoScalingInput$ = DescribeTableReplicaAutoScalingInput$;
exports.DescribeTableReplicaAutoScalingOutput$ = DescribeTableReplicaAutoScalingOutput$;
exports.DescribeTimeToLive$ = DescribeTimeToLive$;
exports.DescribeTimeToLiveCommand = DescribeTimeToLiveCommand;
exports.DescribeTimeToLiveInput$ = DescribeTimeToLiveInput$;
exports.DescribeTimeToLiveOutput$ = DescribeTimeToLiveOutput$;
exports.DestinationStatus = DestinationStatus;
exports.DisableKinesisStreamingDestination$ = DisableKinesisStreamingDestination$;
exports.DisableKinesisStreamingDestinationCommand = DisableKinesisStreamingDestinationCommand;
exports.DuplicateItemException = DuplicateItemException;
exports.DuplicateItemException$ = DuplicateItemException$;
exports.DynamoDB = DynamoDB;
exports.DynamoDBClient = DynamoDBClient;
exports.DynamoDBServiceException = DynamoDBServiceException;
exports.DynamoDBServiceException$ = DynamoDBServiceException$;
exports.EnableKinesisStreamingConfiguration$ = EnableKinesisStreamingConfiguration$;
exports.EnableKinesisStreamingDestination$ = EnableKinesisStreamingDestination$;
exports.EnableKinesisStreamingDestinationCommand = EnableKinesisStreamingDestinationCommand;
exports.Endpoint$ = Endpoint$;
exports.ExecuteStatement$ = ExecuteStatement$;
exports.ExecuteStatementCommand = ExecuteStatementCommand;
exports.ExecuteStatementInput$ = ExecuteStatementInput$;
exports.ExecuteStatementOutput$ = ExecuteStatementOutput$;
exports.ExecuteTransaction$ = ExecuteTransaction$;
exports.ExecuteTransactionCommand = ExecuteTransactionCommand;
exports.ExecuteTransactionInput$ = ExecuteTransactionInput$;
exports.ExecuteTransactionOutput$ = ExecuteTransactionOutput$;
exports.ExpectedAttributeValue$ = ExpectedAttributeValue$;
exports.ExportConflictException = ExportConflictException;
exports.ExportConflictException$ = ExportConflictException$;
exports.ExportDescription$ = ExportDescription$;
exports.ExportFormat = ExportFormat;
exports.ExportNotFoundException = ExportNotFoundException;
exports.ExportNotFoundException$ = ExportNotFoundException$;
exports.ExportStatus = ExportStatus;
exports.ExportSummary$ = ExportSummary$;
exports.ExportTableToPointInTime$ = ExportTableToPointInTime$;
exports.ExportTableToPointInTimeCommand = ExportTableToPointInTimeCommand;
exports.ExportTableToPointInTimeInput$ = ExportTableToPointInTimeInput$;
exports.ExportTableToPointInTimeOutput$ = ExportTableToPointInTimeOutput$;
exports.ExportType = ExportType;
exports.ExportViewType = ExportViewType;
exports.FailureException$ = FailureException$;
exports.Get$ = Get$;
exports.GetItem$ = GetItem$;
exports.GetItemCommand = GetItemCommand;
exports.GetItemInput$ = GetItemInput$;
exports.GetItemOutput$ = GetItemOutput$;
exports.GetResourcePolicy$ = GetResourcePolicy$;
exports.GetResourcePolicyCommand = GetResourcePolicyCommand;
exports.GetResourcePolicyInput$ = GetResourcePolicyInput$;
exports.GetResourcePolicyOutput$ = GetResourcePolicyOutput$;
exports.GlobalSecondaryIndex$ = GlobalSecondaryIndex$;
exports.GlobalSecondaryIndexAutoScalingUpdate$ = GlobalSecondaryIndexAutoScalingUpdate$;
exports.GlobalSecondaryIndexDescription$ = GlobalSecondaryIndexDescription$;
exports.GlobalSecondaryIndexInfo$ = GlobalSecondaryIndexInfo$;
exports.GlobalSecondaryIndexUpdate$ = GlobalSecondaryIndexUpdate$;
exports.GlobalSecondaryIndexWarmThroughputDescription$ = GlobalSecondaryIndexWarmThroughputDescription$;
exports.GlobalTable$ = GlobalTable$;
exports.GlobalTableAlreadyExistsException = GlobalTableAlreadyExistsException;
exports.GlobalTableAlreadyExistsException$ = GlobalTableAlreadyExistsException$;
exports.GlobalTableDescription$ = GlobalTableDescription$;
exports.GlobalTableGlobalSecondaryIndexSettingsUpdate$ = GlobalTableGlobalSecondaryIndexSettingsUpdate$;
exports.GlobalTableNotFoundException = GlobalTableNotFoundException;
exports.GlobalTableNotFoundException$ = GlobalTableNotFoundException$;
exports.GlobalTableSettingsReplicationMode = GlobalTableSettingsReplicationMode;
exports.GlobalTableStatus = GlobalTableStatus;
exports.GlobalTableWitnessDescription$ = GlobalTableWitnessDescription$;
exports.GlobalTableWitnessGroupUpdate$ = GlobalTableWitnessGroupUpdate$;
exports.IdempotentParameterMismatchException = IdempotentParameterMismatchException;
exports.IdempotentParameterMismatchException$ = IdempotentParameterMismatchException$;
exports.ImportConflictException = ImportConflictException;
exports.ImportConflictException$ = ImportConflictException$;
exports.ImportNotFoundException = ImportNotFoundException;
exports.ImportNotFoundException$ = ImportNotFoundException$;
exports.ImportStatus = ImportStatus;
exports.ImportSummary$ = ImportSummary$;
exports.ImportTable$ = ImportTable$;
exports.ImportTableCommand = ImportTableCommand;
exports.ImportTableDescription$ = ImportTableDescription$;
exports.ImportTableInput$ = ImportTableInput$;
exports.ImportTableOutput$ = ImportTableOutput$;
exports.IncrementalExportSpecification$ = IncrementalExportSpecification$;
exports.IndexNotFoundException = IndexNotFoundException;
exports.IndexNotFoundException$ = IndexNotFoundException$;
exports.IndexStatus = IndexStatus;
exports.InputCompressionType = InputCompressionType;
exports.InputFormat = InputFormat;
exports.InputFormatOptions$ = InputFormatOptions$;
exports.InternalServerError = InternalServerError;
exports.InternalServerError$ = InternalServerError$;
exports.InvalidEndpointException = InvalidEndpointException;
exports.InvalidEndpointException$ = InvalidEndpointException$;
exports.InvalidExportTimeException = InvalidExportTimeException;
exports.InvalidExportTimeException$ = InvalidExportTimeException$;
exports.InvalidRestoreTimeException = InvalidRestoreTimeException;
exports.InvalidRestoreTimeException$ = InvalidRestoreTimeException$;
exports.ItemCollectionMetrics$ = ItemCollectionMetrics$;
exports.ItemCollectionSizeLimitExceededException = ItemCollectionSizeLimitExceededException;
exports.ItemCollectionSizeLimitExceededException$ = ItemCollectionSizeLimitExceededException$;
exports.ItemResponse$ = ItemResponse$;
exports.KeySchemaElement$ = KeySchemaElement$;
exports.KeyType = KeyType;
exports.KeysAndAttributes$ = KeysAndAttributes$;
exports.KinesisDataStreamDestination$ = KinesisDataStreamDestination$;
exports.KinesisStreamingDestinationInput$ = KinesisStreamingDestinationInput$;
exports.KinesisStreamingDestinationOutput$ = KinesisStreamingDestinationOutput$;
exports.LimitExceededException = LimitExceededException;
exports.LimitExceededException$ = LimitExceededException$;
exports.ListBackups$ = ListBackups$;
exports.ListBackupsCommand = ListBackupsCommand;
exports.ListBackupsInput$ = ListBackupsInput$;
exports.ListBackupsOutput$ = ListBackupsOutput$;
exports.ListContributorInsights$ = ListContributorInsights$;
exports.ListContributorInsightsCommand = ListContributorInsightsCommand;
exports.ListContributorInsightsInput$ = ListContributorInsightsInput$;
exports.ListContributorInsightsOutput$ = ListContributorInsightsOutput$;
exports.ListExports$ = ListExports$;
exports.ListExportsCommand = ListExportsCommand;
exports.ListExportsInput$ = ListExportsInput$;
exports.ListExportsOutput$ = ListExportsOutput$;
exports.ListGlobalTables$ = ListGlobalTables$;
exports.ListGlobalTablesCommand = ListGlobalTablesCommand;
exports.ListGlobalTablesInput$ = ListGlobalTablesInput$;
exports.ListGlobalTablesOutput$ = ListGlobalTablesOutput$;
exports.ListImports$ = ListImports$;
exports.ListImportsCommand = ListImportsCommand;
exports.ListImportsInput$ = ListImportsInput$;
exports.ListImportsOutput$ = ListImportsOutput$;
exports.ListTables$ = ListTables$;
exports.ListTablesCommand = ListTablesCommand;
exports.ListTablesInput$ = ListTablesInput$;
exports.ListTablesOutput$ = ListTablesOutput$;
exports.ListTagsOfResource$ = ListTagsOfResource$;
exports.ListTagsOfResourceCommand = ListTagsOfResourceCommand;
exports.ListTagsOfResourceInput$ = ListTagsOfResourceInput$;
exports.ListTagsOfResourceOutput$ = ListTagsOfResourceOutput$;
exports.LocalSecondaryIndex$ = LocalSecondaryIndex$;
exports.LocalSecondaryIndexDescription$ = LocalSecondaryIndexDescription$;
exports.LocalSecondaryIndexInfo$ = LocalSecondaryIndexInfo$;
exports.MultiRegionConsistency = MultiRegionConsistency;
exports.OnDemandThroughput$ = OnDemandThroughput$;
exports.OnDemandThroughputOverride$ = OnDemandThroughputOverride$;
exports.ParameterizedStatement$ = ParameterizedStatement$;
exports.PointInTimeRecoveryDescription$ = PointInTimeRecoveryDescription$;
exports.PointInTimeRecoverySpecification$ = PointInTimeRecoverySpecification$;
exports.PointInTimeRecoveryStatus = PointInTimeRecoveryStatus;
exports.PointInTimeRecoveryUnavailableException = PointInTimeRecoveryUnavailableException;
exports.PointInTimeRecoveryUnavailableException$ = PointInTimeRecoveryUnavailableException$;
exports.PolicyNotFoundException = PolicyNotFoundException;
exports.PolicyNotFoundException$ = PolicyNotFoundException$;
exports.Projection$ = Projection$;
exports.ProjectionType = ProjectionType;
exports.ProvisionedThroughput$ = ProvisionedThroughput$;
exports.ProvisionedThroughputDescription$ = ProvisionedThroughputDescription$;
exports.ProvisionedThroughputExceededException = ProvisionedThroughputExceededException;
exports.ProvisionedThroughputExceededException$ = ProvisionedThroughputExceededException$;
exports.ProvisionedThroughputOverride$ = ProvisionedThroughputOverride$;
exports.Put$ = Put$;
exports.PutItem$ = PutItem$;
exports.PutItemCommand = PutItemCommand;
exports.PutItemInput$ = PutItemInput$;
exports.PutItemOutput$ = PutItemOutput$;
exports.PutRequest$ = PutRequest$;
exports.PutResourcePolicy$ = PutResourcePolicy$;
exports.PutResourcePolicyCommand = PutResourcePolicyCommand;
exports.PutResourcePolicyInput$ = PutResourcePolicyInput$;
exports.PutResourcePolicyOutput$ = PutResourcePolicyOutput$;
exports.Query$ = Query$;
exports.QueryCommand = QueryCommand;
exports.QueryInput$ = QueryInput$;
exports.QueryOutput$ = QueryOutput$;
exports.Replica$ = Replica$;
exports.ReplicaAlreadyExistsException = ReplicaAlreadyExistsException;
exports.ReplicaAlreadyExistsException$ = ReplicaAlreadyExistsException$;
exports.ReplicaAutoScalingDescription$ = ReplicaAutoScalingDescription$;
exports.ReplicaAutoScalingUpdate$ = ReplicaAutoScalingUpdate$;
exports.ReplicaDescription$ = ReplicaDescription$;
exports.ReplicaGlobalSecondaryIndex$ = ReplicaGlobalSecondaryIndex$;
exports.ReplicaGlobalSecondaryIndexAutoScalingDescription$ = ReplicaGlobalSecondaryIndexAutoScalingDescription$;
exports.ReplicaGlobalSecondaryIndexAutoScalingUpdate$ = ReplicaGlobalSecondaryIndexAutoScalingUpdate$;
exports.ReplicaGlobalSecondaryIndexDescription$ = ReplicaGlobalSecondaryIndexDescription$;
exports.ReplicaGlobalSecondaryIndexSettingsDescription$ = ReplicaGlobalSecondaryIndexSettingsDescription$;
exports.ReplicaGlobalSecondaryIndexSettingsUpdate$ = ReplicaGlobalSecondaryIndexSettingsUpdate$;
exports.ReplicaNotFoundException = ReplicaNotFoundException;
exports.ReplicaNotFoundException$ = ReplicaNotFoundException$;
exports.ReplicaSettingsDescription$ = ReplicaSettingsDescription$;
exports.ReplicaSettingsUpdate$ = ReplicaSettingsUpdate$;
exports.ReplicaStatus = ReplicaStatus;
exports.ReplicaUpdate$ = ReplicaUpdate$;
exports.ReplicatedWriteConflictException = ReplicatedWriteConflictException;
exports.ReplicatedWriteConflictException$ = ReplicatedWriteConflictException$;
exports.ReplicationGroupUpdate$ = ReplicationGroupUpdate$;
exports.RequestLimitExceeded = RequestLimitExceeded;
exports.RequestLimitExceeded$ = RequestLimitExceeded$;
exports.ResourceInUseException = ResourceInUseException;
exports.ResourceInUseException$ = ResourceInUseException$;
exports.ResourceNotFoundException = ResourceNotFoundException;
exports.ResourceNotFoundException$ = ResourceNotFoundException$;
exports.RestoreSummary$ = RestoreSummary$;
exports.RestoreTableFromBackup$ = RestoreTableFromBackup$;
exports.RestoreTableFromBackupCommand = RestoreTableFromBackupCommand;
exports.RestoreTableFromBackupInput$ = RestoreTableFromBackupInput$;
exports.RestoreTableFromBackupOutput$ = RestoreTableFromBackupOutput$;
exports.RestoreTableToPointInTime$ = RestoreTableToPointInTime$;
exports.RestoreTableToPointInTimeCommand = RestoreTableToPointInTimeCommand;
exports.RestoreTableToPointInTimeInput$ = RestoreTableToPointInTimeInput$;
exports.RestoreTableToPointInTimeOutput$ = RestoreTableToPointInTimeOutput$;
exports.ReturnConsumedCapacity = ReturnConsumedCapacity;
exports.ReturnItemCollectionMetrics = ReturnItemCollectionMetrics;
exports.ReturnValue = ReturnValue;
exports.ReturnValuesOnConditionCheckFailure = ReturnValuesOnConditionCheckFailure;
exports.S3BucketSource$ = S3BucketSource$;
exports.S3SseAlgorithm = S3SseAlgorithm;
exports.SSEDescription$ = SSEDescription$;
exports.SSESpecification$ = SSESpecification$;
exports.SSEStatus = SSEStatus;
exports.SSEType = SSEType;
exports.ScalarAttributeType = ScalarAttributeType;
exports.Scan$ = Scan$;
exports.ScanCommand = ScanCommand;
exports.ScanInput$ = ScanInput$;
exports.ScanOutput$ = ScanOutput$;
exports.SearchResultItem$ = SearchResultItem$;
exports.SearchSchemaElement$ = SearchSchemaElement$;
exports.SearchSchemaElementType = SearchSchemaElementType;
exports.SearchVectors$ = SearchVectors$;
exports.SearchVectorsCommand = SearchVectorsCommand;
exports.SearchVectorsInput$ = SearchVectorsInput$;
exports.SearchVectorsOutput$ = SearchVectorsOutput$;
exports.Select = Select;
exports.SourceTableDetails$ = SourceTableDetails$;
exports.SourceTableFeatureDetails$ = SourceTableFeatureDetails$;
exports.StreamSpecification$ = StreamSpecification$;
exports.StreamViewType = StreamViewType;
exports.TableAlreadyExistsException = TableAlreadyExistsException;
exports.TableAlreadyExistsException$ = TableAlreadyExistsException$;
exports.TableAutoScalingDescription$ = TableAutoScalingDescription$;
exports.TableClass = TableClass;
exports.TableClassSummary$ = TableClassSummary$;
exports.TableCreationParameters$ = TableCreationParameters$;
exports.TableDescription$ = TableDescription$;
exports.TableInUseException = TableInUseException;
exports.TableInUseException$ = TableInUseException$;
exports.TableNotFoundException = TableNotFoundException;
exports.TableNotFoundException$ = TableNotFoundException$;
exports.TableStatus = TableStatus;
exports.TableWarmThroughputDescription$ = TableWarmThroughputDescription$;
exports.Tag$ = Tag$;
exports.TagResource$ = TagResource$;
exports.TagResourceCommand = TagResourceCommand;
exports.TagResourceInput$ = TagResourceInput$;
exports.ThrottlingException = ThrottlingException;
exports.ThrottlingException$ = ThrottlingException$;
exports.ThrottlingReason$ = ThrottlingReason$;
exports.TimeToLiveDescription$ = TimeToLiveDescription$;
exports.TimeToLiveSpecification$ = TimeToLiveSpecification$;
exports.TimeToLiveStatus = TimeToLiveStatus;
exports.TransactGetItem$ = TransactGetItem$;
exports.TransactGetItems$ = TransactGetItems$;
exports.TransactGetItemsCommand = TransactGetItemsCommand;
exports.TransactGetItemsInput$ = TransactGetItemsInput$;
exports.TransactGetItemsOutput$ = TransactGetItemsOutput$;
exports.TransactWriteItem$ = TransactWriteItem$;
exports.TransactWriteItems$ = TransactWriteItems$;
exports.TransactWriteItemsCommand = TransactWriteItemsCommand;
exports.TransactWriteItemsInput$ = TransactWriteItemsInput$;
exports.TransactWriteItemsOutput$ = TransactWriteItemsOutput$;
exports.TransactionCanceledException = TransactionCanceledException;
exports.TransactionCanceledException$ = TransactionCanceledException$;
exports.TransactionConflictException = TransactionConflictException;
exports.TransactionConflictException$ = TransactionConflictException$;
exports.TransactionInProgressException = TransactionInProgressException;
exports.TransactionInProgressException$ = TransactionInProgressException$;
exports.UntagResource$ = UntagResource$;
exports.UntagResourceCommand = UntagResourceCommand;
exports.UntagResourceInput$ = UntagResourceInput$;
exports.Update$ = Update$;
exports.UpdateContinuousBackups$ = UpdateContinuousBackups$;
exports.UpdateContinuousBackupsCommand = UpdateContinuousBackupsCommand;
exports.UpdateContinuousBackupsInput$ = UpdateContinuousBackupsInput$;
exports.UpdateContinuousBackupsOutput$ = UpdateContinuousBackupsOutput$;
exports.UpdateContributorInsights$ = UpdateContributorInsights$;
exports.UpdateContributorInsightsCommand = UpdateContributorInsightsCommand;
exports.UpdateContributorInsightsInput$ = UpdateContributorInsightsInput$;
exports.UpdateContributorInsightsOutput$ = UpdateContributorInsightsOutput$;
exports.UpdateGlobalSecondaryIndexAction$ = UpdateGlobalSecondaryIndexAction$;
exports.UpdateGlobalTable$ = UpdateGlobalTable$;
exports.UpdateGlobalTableCommand = UpdateGlobalTableCommand;
exports.UpdateGlobalTableInput$ = UpdateGlobalTableInput$;
exports.UpdateGlobalTableOutput$ = UpdateGlobalTableOutput$;
exports.UpdateGlobalTableSettings$ = UpdateGlobalTableSettings$;
exports.UpdateGlobalTableSettingsCommand = UpdateGlobalTableSettingsCommand;
exports.UpdateGlobalTableSettingsInput$ = UpdateGlobalTableSettingsInput$;
exports.UpdateGlobalTableSettingsOutput$ = UpdateGlobalTableSettingsOutput$;
exports.UpdateItem$ = UpdateItem$;
exports.UpdateItemCommand = UpdateItemCommand;
exports.UpdateItemInput$ = UpdateItemInput$;
exports.UpdateItemOutput$ = UpdateItemOutput$;
exports.UpdateKinesisStreamingConfiguration$ = UpdateKinesisStreamingConfiguration$;
exports.UpdateKinesisStreamingDestination$ = UpdateKinesisStreamingDestination$;
exports.UpdateKinesisStreamingDestinationCommand = UpdateKinesisStreamingDestinationCommand;
exports.UpdateKinesisStreamingDestinationInput$ = UpdateKinesisStreamingDestinationInput$;
exports.UpdateKinesisStreamingDestinationOutput$ = UpdateKinesisStreamingDestinationOutput$;
exports.UpdateReplicationGroupMemberAction$ = UpdateReplicationGroupMemberAction$;
exports.UpdateTable$ = UpdateTable$;
exports.UpdateTableCommand = UpdateTableCommand;
exports.UpdateTableInput$ = UpdateTableInput$;
exports.UpdateTableOutput$ = UpdateTableOutput$;
exports.UpdateTableReplicaAutoScaling$ = UpdateTableReplicaAutoScaling$;
exports.UpdateTableReplicaAutoScalingCommand = UpdateTableReplicaAutoScalingCommand;
exports.UpdateTableReplicaAutoScalingInput$ = UpdateTableReplicaAutoScalingInput$;
exports.UpdateTableReplicaAutoScalingOutput$ = UpdateTableReplicaAutoScalingOutput$;
exports.UpdateTimeToLive$ = UpdateTimeToLive$;
exports.UpdateTimeToLiveCommand = UpdateTimeToLiveCommand;
exports.UpdateTimeToLiveInput$ = UpdateTimeToLiveInput$;
exports.UpdateTimeToLiveOutput$ = UpdateTimeToLiveOutput$;
exports.VectorAttributeDefinition$ = VectorAttributeDefinition$;
exports.VectorCapacity$ = VectorCapacity$;
exports.VectorDistanceFunction = VectorDistanceFunction;
exports.VectorIndex$ = VectorIndex$;
exports.VectorIndexDescription$ = VectorIndexDescription$;
exports.VectorIndexInfo$ = VectorIndexInfo$;
exports.VectorIndexUpdate$ = VectorIndexUpdate$;
exports.WarmThroughput$ = WarmThroughput$;
exports.WitnessStatus = WitnessStatus;
exports.WriteRequest$ = WriteRequest$;
exports.errorTypeRegistries = errorTypeRegistries;
exports.paginateListContributorInsights = paginateListContributorInsights;
exports.paginateListExports = paginateListExports;
exports.paginateListImports = paginateListImports;
exports.paginateListTables = paginateListTables;
exports.paginateQuery = paginateQuery;
exports.paginateScan = paginateScan;
exports.waitForContributorInsightsEnabled = waitForContributorInsightsEnabled;
exports.waitForExportCompleted = waitForExportCompleted;
exports.waitForImportCompleted = waitForImportCompleted;
exports.waitForKinesisStreamingDestinationActive = waitForKinesisStreamingDestinationActive;
exports.waitForTableExists = waitForTableExists;
exports.waitForTableNotExists = waitForTableNotExists;
exports.waitUntilContributorInsightsEnabled = waitUntilContributorInsightsEnabled;
exports.waitUntilExportCompleted = waitUntilExportCompleted;
exports.waitUntilImportCompleted = waitUntilImportCompleted;
exports.waitUntilKinesisStreamingDestinationActive = waitUntilKinesisStreamingDestinationActive;
exports.waitUntilTableExists = waitUntilTableExists;
exports.waitUntilTableNotExists = waitUntilTableNotExists;
