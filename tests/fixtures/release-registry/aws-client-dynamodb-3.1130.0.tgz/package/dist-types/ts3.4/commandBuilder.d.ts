import { EndpointParameterInstructions } from "@smithy/types";
import {
  DynamoDBClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "./DynamoDBClient";
export declare const command: <I extends ServiceInputTypes, O extends ServiceOutputTypes>(
  added: EndpointParameterInstructions,
  plugins: (
    CommandCtor: any,
    clientStack: any,
    config: any,
    options: any,
  ) => import("@smithy/types").Pluggable<any, any>[],
  op: string,
  $: import("@smithy/types").StaticOperationSchema,
  smithyContext?: Record<string, unknown>,
) => {
  new (
    input: I,
  ): import("@smithy/core/client").CommandImpl<
    I,
    O,
    DynamoDBClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    ...[input]: import("@smithy/types").OptionalParameter<I>
  ): import("@smithy/core/client").CommandImpl<
    I,
    O,
    DynamoDBClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): EndpointParameterInstructions;
};
export declare const _ep0: EndpointParameterInstructions;
export declare const _ep1: EndpointParameterInstructions;
export declare const _ep2: EndpointParameterInstructions;
export declare const _ep3: EndpointParameterInstructions;
export declare const _ep4: EndpointParameterInstructions;
export declare const _ep5: EndpointParameterInstructions;
export declare const _ep6: EndpointParameterInstructions;
export declare const _ep7: EndpointParameterInstructions;
export declare const _ep8: EndpointParameterInstructions;
export declare const _ep9: EndpointParameterInstructions;
export declare const _ep10: EndpointParameterInstructions;
export declare const _ep11: EndpointParameterInstructions;
export declare const _ep12: EndpointParameterInstructions;
export declare const _ep13: EndpointParameterInstructions;
export declare const _mw0: (Command: any, cs: any, config: any, o: any) => never[];
