import { WaiterConfiguration, WaiterResult } from "@smithy/core/client";
import {
  DescribeExportCommandInput,
  DescribeExportCommandOutput,
} from "../commands/DescribeExportCommand";
import { DynamoDBClient } from "../DynamoDBClient";
import { DynamoDBServiceException } from "../models/DynamoDBServiceException";
export declare const waitForExportCompleted: (
  params: WaiterConfiguration<DynamoDBClient>,
  input: DescribeExportCommandInput,
) => Promise<WaiterResult<DescribeExportCommandOutput | DynamoDBServiceException>>;
export declare const waitUntilExportCompleted: (
  params: WaiterConfiguration<DynamoDBClient>,
  input: DescribeExportCommandInput,
) => Promise<WaiterResult<DescribeExportCommandOutput>>;
