import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { BatchWriteItemInput, BatchWriteItemOutput } from "../models/models_0";
export { __MetadataBearer };
export interface BatchWriteItemCommandInput extends BatchWriteItemInput {}
export interface BatchWriteItemCommandOutput extends BatchWriteItemOutput, __MetadataBearer {}
declare const BatchWriteItemCommand_base: {
  new (
    input: BatchWriteItemCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    BatchWriteItemCommandInput,
    BatchWriteItemCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: BatchWriteItemCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    BatchWriteItemCommandInput,
    BatchWriteItemCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class BatchWriteItemCommand extends BatchWriteItemCommand_base {
  protected static __types: {
    api: {
      input: BatchWriteItemInput;
      output: BatchWriteItemOutput;
    };
    sdk: {
      input: BatchWriteItemCommandInput;
      output: BatchWriteItemCommandOutput;
    };
  };
}
