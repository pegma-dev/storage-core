import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DescribeKinesisStreamingDestinationInput,
  DescribeKinesisStreamingDestinationOutput,
} from "../models/models_0";
export { __MetadataBearer };
export interface DescribeKinesisStreamingDestinationCommandInput extends DescribeKinesisStreamingDestinationInput {}
export interface DescribeKinesisStreamingDestinationCommandOutput
  extends DescribeKinesisStreamingDestinationOutput, __MetadataBearer {}
declare const DescribeKinesisStreamingDestinationCommand_base: {
  new (
    input: DescribeKinesisStreamingDestinationCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeKinesisStreamingDestinationCommandInput,
    DescribeKinesisStreamingDestinationCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeKinesisStreamingDestinationCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeKinesisStreamingDestinationCommandInput,
    DescribeKinesisStreamingDestinationCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeKinesisStreamingDestinationCommand extends DescribeKinesisStreamingDestinationCommand_base {
  protected static __types: {
    api: {
      input: DescribeKinesisStreamingDestinationInput;
      output: DescribeKinesisStreamingDestinationOutput;
    };
    sdk: {
      input: DescribeKinesisStreamingDestinationCommandInput;
      output: DescribeKinesisStreamingDestinationCommandOutput;
    };
  };
}
