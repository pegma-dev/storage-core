import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { UpdateGlobalTableInput, UpdateGlobalTableOutput } from "../models/models_0";
export { __MetadataBearer };
export interface UpdateGlobalTableCommandInput extends UpdateGlobalTableInput {}
export interface UpdateGlobalTableCommandOutput extends UpdateGlobalTableOutput, __MetadataBearer {}
declare const UpdateGlobalTableCommand_base: {
  new (
    input: UpdateGlobalTableCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    UpdateGlobalTableCommandInput,
    UpdateGlobalTableCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: UpdateGlobalTableCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    UpdateGlobalTableCommandInput,
    UpdateGlobalTableCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class UpdateGlobalTableCommand extends UpdateGlobalTableCommand_base {
  protected static __types: {
    api: {
      input: UpdateGlobalTableInput;
      output: UpdateGlobalTableOutput;
    };
    sdk: {
      input: UpdateGlobalTableCommandInput;
      output: UpdateGlobalTableCommandOutput;
    };
  };
}
