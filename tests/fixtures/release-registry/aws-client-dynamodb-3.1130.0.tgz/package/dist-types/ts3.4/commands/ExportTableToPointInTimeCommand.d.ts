import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { ExportTableToPointInTimeInput, ExportTableToPointInTimeOutput } from "../models/models_0";
export { __MetadataBearer };
export interface ExportTableToPointInTimeCommandInput extends ExportTableToPointInTimeInput {}
export interface ExportTableToPointInTimeCommandOutput
  extends ExportTableToPointInTimeOutput, __MetadataBearer {}
declare const ExportTableToPointInTimeCommand_base: {
  new (
    input: ExportTableToPointInTimeCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    ExportTableToPointInTimeCommandInput,
    ExportTableToPointInTimeCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: ExportTableToPointInTimeCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    ExportTableToPointInTimeCommandInput,
    ExportTableToPointInTimeCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class ExportTableToPointInTimeCommand extends ExportTableToPointInTimeCommand_base {
  protected static __types: {
    api: {
      input: ExportTableToPointInTimeInput;
      output: ExportTableToPointInTimeOutput;
    };
    sdk: {
      input: ExportTableToPointInTimeCommandInput;
      output: ExportTableToPointInTimeCommandOutput;
    };
  };
}
