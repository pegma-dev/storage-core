import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DeleteBackupInput, DeleteBackupOutput } from "../models/models_0";
export { __MetadataBearer };
export interface DeleteBackupCommandInput extends DeleteBackupInput {}
export interface DeleteBackupCommandOutput extends DeleteBackupOutput, __MetadataBearer {}
declare const DeleteBackupCommand_base: {
  new (
    input: DeleteBackupCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeleteBackupCommandInput,
    DeleteBackupCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DeleteBackupCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeleteBackupCommandInput,
    DeleteBackupCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DeleteBackupCommand extends DeleteBackupCommand_base {
  protected static __types: {
    api: {
      input: DeleteBackupInput;
      output: DeleteBackupOutput;
    };
    sdk: {
      input: DeleteBackupCommandInput;
      output: DeleteBackupCommandOutput;
    };
  };
}
