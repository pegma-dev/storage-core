import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { ListGlobalTablesInput, ListGlobalTablesOutput } from "../models/models_0";
export { __MetadataBearer };
export interface ListGlobalTablesCommandInput extends ListGlobalTablesInput {}
export interface ListGlobalTablesCommandOutput extends ListGlobalTablesOutput, __MetadataBearer {}
declare const ListGlobalTablesCommand_base: {
  new (
    input: ListGlobalTablesCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    ListGlobalTablesCommandInput,
    ListGlobalTablesCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [ListGlobalTablesCommandInput]
  ): import("@smithy/core/client").CommandImpl<
    ListGlobalTablesCommandInput,
    ListGlobalTablesCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class ListGlobalTablesCommand extends ListGlobalTablesCommand_base {
  protected static __types: {
    api: {
      input: ListGlobalTablesInput;
      output: ListGlobalTablesOutput;
    };
    sdk: {
      input: ListGlobalTablesCommandInput;
      output: ListGlobalTablesCommandOutput;
    };
  };
}
