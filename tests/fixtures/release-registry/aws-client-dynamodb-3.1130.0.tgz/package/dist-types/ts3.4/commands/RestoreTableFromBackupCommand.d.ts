import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { RestoreTableFromBackupInput, RestoreTableFromBackupOutput } from "../models/models_0";
export { __MetadataBearer };
export interface RestoreTableFromBackupCommandInput extends RestoreTableFromBackupInput {}
export interface RestoreTableFromBackupCommandOutput
  extends RestoreTableFromBackupOutput, __MetadataBearer {}
declare const RestoreTableFromBackupCommand_base: {
  new (
    input: RestoreTableFromBackupCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    RestoreTableFromBackupCommandInput,
    RestoreTableFromBackupCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: RestoreTableFromBackupCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    RestoreTableFromBackupCommandInput,
    RestoreTableFromBackupCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class RestoreTableFromBackupCommand extends RestoreTableFromBackupCommand_base {
  protected static __types: {
    api: {
      input: RestoreTableFromBackupInput;
      output: RestoreTableFromBackupOutput;
    };
    sdk: {
      input: RestoreTableFromBackupCommandInput;
      output: RestoreTableFromBackupCommandOutput;
    };
  };
}
