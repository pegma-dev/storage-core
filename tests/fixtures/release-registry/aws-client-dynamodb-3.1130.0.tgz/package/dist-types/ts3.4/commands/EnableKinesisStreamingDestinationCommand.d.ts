import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  KinesisStreamingDestinationInput,
  KinesisStreamingDestinationOutput,
} from "../models/models_0";
export { __MetadataBearer };
export interface EnableKinesisStreamingDestinationCommandInput extends KinesisStreamingDestinationInput {}
export interface EnableKinesisStreamingDestinationCommandOutput
  extends KinesisStreamingDestinationOutput, __MetadataBearer {}
declare const EnableKinesisStreamingDestinationCommand_base: {
  new (
    input: EnableKinesisStreamingDestinationCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    EnableKinesisStreamingDestinationCommandInput,
    EnableKinesisStreamingDestinationCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: EnableKinesisStreamingDestinationCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    EnableKinesisStreamingDestinationCommandInput,
    EnableKinesisStreamingDestinationCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class EnableKinesisStreamingDestinationCommand extends EnableKinesisStreamingDestinationCommand_base {
  protected static __types: {
    api: {
      input: KinesisStreamingDestinationInput;
      output: KinesisStreamingDestinationOutput;
    };
    sdk: {
      input: EnableKinesisStreamingDestinationCommandInput;
      output: EnableKinesisStreamingDestinationCommandOutput;
    };
  };
}
