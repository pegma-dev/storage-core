import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DescribeLimitsInput, DescribeLimitsOutput } from "../models/models_0";
export { __MetadataBearer };
export interface DescribeLimitsCommandInput extends DescribeLimitsInput {}
export interface DescribeLimitsCommandOutput extends DescribeLimitsOutput, __MetadataBearer {}
declare const DescribeLimitsCommand_base: {
  new (
    input: DescribeLimitsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeLimitsCommandInput,
    DescribeLimitsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [DescribeLimitsCommandInput]
  ): import("@smithy/core/client").CommandImpl<
    DescribeLimitsCommandInput,
    DescribeLimitsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeLimitsCommand extends DescribeLimitsCommand_base {
  protected static __types: {
    api: {
      input: {};
      output: DescribeLimitsOutput;
    };
    sdk: {
      input: DescribeLimitsCommandInput;
      output: DescribeLimitsCommandOutput;
    };
  };
}
