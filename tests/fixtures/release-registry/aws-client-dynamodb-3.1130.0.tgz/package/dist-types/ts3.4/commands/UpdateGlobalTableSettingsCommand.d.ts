import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  UpdateGlobalTableSettingsInput,
  UpdateGlobalTableSettingsOutput,
} from "../models/models_0";
export { __MetadataBearer };
export interface UpdateGlobalTableSettingsCommandInput extends UpdateGlobalTableSettingsInput {}
export interface UpdateGlobalTableSettingsCommandOutput
  extends UpdateGlobalTableSettingsOutput, __MetadataBearer {}
declare const UpdateGlobalTableSettingsCommand_base: {
  new (
    input: UpdateGlobalTableSettingsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    UpdateGlobalTableSettingsCommandInput,
    UpdateGlobalTableSettingsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: UpdateGlobalTableSettingsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    UpdateGlobalTableSettingsCommandInput,
    UpdateGlobalTableSettingsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class UpdateGlobalTableSettingsCommand extends UpdateGlobalTableSettingsCommand_base {
  protected static __types: {
    api: {
      input: UpdateGlobalTableSettingsInput;
      output: UpdateGlobalTableSettingsOutput;
    };
    sdk: {
      input: UpdateGlobalTableSettingsCommandInput;
      output: UpdateGlobalTableSettingsCommandOutput;
    };
  };
}
