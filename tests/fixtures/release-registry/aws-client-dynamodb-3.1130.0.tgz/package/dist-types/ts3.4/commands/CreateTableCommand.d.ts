import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { CreateTableInput, CreateTableOutput } from "../models/models_0";
export { __MetadataBearer };
export interface CreateTableCommandInput extends CreateTableInput {}
export interface CreateTableCommandOutput extends CreateTableOutput, __MetadataBearer {}
declare const CreateTableCommand_base: {
  new (
    input: CreateTableCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    CreateTableCommandInput,
    CreateTableCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: CreateTableCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    CreateTableCommandInput,
    CreateTableCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class CreateTableCommand extends CreateTableCommand_base {
  protected static __types: {
    api: {
      input: CreateTableInput;
      output: CreateTableOutput;
    };
    sdk: {
      input: CreateTableCommandInput;
      output: CreateTableCommandOutput;
    };
  };
}
