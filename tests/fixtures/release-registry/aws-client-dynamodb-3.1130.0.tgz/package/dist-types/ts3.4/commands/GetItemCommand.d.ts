import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GetItemInput, GetItemOutput } from "../models/models_0";
export { __MetadataBearer };
export interface GetItemCommandInput extends GetItemInput {}
export interface GetItemCommandOutput extends GetItemOutput, __MetadataBearer {}
declare const GetItemCommand_base: {
  new (
    input: GetItemCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetItemCommandInput,
    GetItemCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: GetItemCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetItemCommandInput,
    GetItemCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetItemCommand extends GetItemCommand_base {
  protected static __types: {
    api: {
      input: GetItemInput;
      output: GetItemOutput;
    };
    sdk: {
      input: GetItemCommandInput;
      output: GetItemCommandOutput;
    };
  };
}
