import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DeleteResourcePolicyInput, DeleteResourcePolicyOutput } from "../models/models_0";
export { __MetadataBearer };
export interface DeleteResourcePolicyCommandInput extends DeleteResourcePolicyInput {}
export interface DeleteResourcePolicyCommandOutput
  extends DeleteResourcePolicyOutput, __MetadataBearer {}
declare const DeleteResourcePolicyCommand_base: {
  new (
    input: DeleteResourcePolicyCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeleteResourcePolicyCommandInput,
    DeleteResourcePolicyCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DeleteResourcePolicyCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DeleteResourcePolicyCommandInput,
    DeleteResourcePolicyCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DeleteResourcePolicyCommand extends DeleteResourcePolicyCommand_base {
  protected static __types: {
    api: {
      input: DeleteResourcePolicyInput;
      output: DeleteResourcePolicyOutput;
    };
    sdk: {
      input: DeleteResourcePolicyCommandInput;
      output: DeleteResourcePolicyCommandOutput;
    };
  };
}
