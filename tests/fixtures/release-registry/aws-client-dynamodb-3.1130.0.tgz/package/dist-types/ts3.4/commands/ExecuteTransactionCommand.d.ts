import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { ExecuteTransactionInput, ExecuteTransactionOutput } from "../models/models_0";
export { __MetadataBearer };
export interface ExecuteTransactionCommandInput extends ExecuteTransactionInput {}
export interface ExecuteTransactionCommandOutput
  extends ExecuteTransactionOutput, __MetadataBearer {}
declare const ExecuteTransactionCommand_base: {
  new (
    input: ExecuteTransactionCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    ExecuteTransactionCommandInput,
    ExecuteTransactionCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: ExecuteTransactionCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    ExecuteTransactionCommandInput,
    ExecuteTransactionCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class ExecuteTransactionCommand extends ExecuteTransactionCommand_base {
  protected static __types: {
    api: {
      input: ExecuteTransactionInput;
      output: ExecuteTransactionOutput;
    };
    sdk: {
      input: ExecuteTransactionCommandInput;
      output: ExecuteTransactionCommandOutput;
    };
  };
}
