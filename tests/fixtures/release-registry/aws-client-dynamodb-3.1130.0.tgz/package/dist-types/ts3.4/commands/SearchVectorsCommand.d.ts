import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { SearchVectorsInput, SearchVectorsOutput } from "../models/models_0";
export { __MetadataBearer };
export interface SearchVectorsCommandInput extends SearchVectorsInput {}
export interface SearchVectorsCommandOutput extends SearchVectorsOutput, __MetadataBearer {}
declare const SearchVectorsCommand_base: {
  new (
    input: SearchVectorsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    SearchVectorsCommandInput,
    SearchVectorsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: SearchVectorsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    SearchVectorsCommandInput,
    SearchVectorsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class SearchVectorsCommand extends SearchVectorsCommand_base {
  protected static __types: {
    api: {
      input: SearchVectorsInput;
      output: SearchVectorsOutput;
    };
    sdk: {
      input: SearchVectorsCommandInput;
      output: SearchVectorsCommandOutput;
    };
  };
}
