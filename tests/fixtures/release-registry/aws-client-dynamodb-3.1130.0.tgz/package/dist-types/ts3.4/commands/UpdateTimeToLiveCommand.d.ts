import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { UpdateTimeToLiveInput, UpdateTimeToLiveOutput } from "../models/models_0";
export { __MetadataBearer };
export interface UpdateTimeToLiveCommandInput extends UpdateTimeToLiveInput {}
export interface UpdateTimeToLiveCommandOutput extends UpdateTimeToLiveOutput, __MetadataBearer {}
declare const UpdateTimeToLiveCommand_base: {
  new (
    input: UpdateTimeToLiveCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    UpdateTimeToLiveCommandInput,
    UpdateTimeToLiveCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: UpdateTimeToLiveCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    UpdateTimeToLiveCommandInput,
    UpdateTimeToLiveCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class UpdateTimeToLiveCommand extends UpdateTimeToLiveCommand_base {
  protected static __types: {
    api: {
      input: UpdateTimeToLiveInput;
      output: UpdateTimeToLiveOutput;
    };
    sdk: {
      input: UpdateTimeToLiveCommandInput;
      output: UpdateTimeToLiveCommandOutput;
    };
  };
}
