import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { ListExportsInput, ListExportsOutput } from "../models/models_0";
export { __MetadataBearer };
export interface ListExportsCommandInput extends ListExportsInput {}
export interface ListExportsCommandOutput extends ListExportsOutput, __MetadataBearer {}
declare const ListExportsCommand_base: {
  new (
    input: ListExportsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    ListExportsCommandInput,
    ListExportsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [ListExportsCommandInput]
  ): import("@smithy/core/client").CommandImpl<
    ListExportsCommandInput,
    ListExportsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class ListExportsCommand extends ListExportsCommand_base {
  protected static __types: {
    api: {
      input: ListExportsInput;
      output: ListExportsOutput;
    };
    sdk: {
      input: ListExportsCommandInput;
      output: ListExportsCommandOutput;
    };
  };
}
