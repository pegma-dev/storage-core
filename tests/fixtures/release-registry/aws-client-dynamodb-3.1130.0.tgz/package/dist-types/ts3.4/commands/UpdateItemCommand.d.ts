import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { UpdateItemInput, UpdateItemOutput } from "../models/models_0";
export { __MetadataBearer };
export interface UpdateItemCommandInput extends UpdateItemInput {}
export interface UpdateItemCommandOutput extends UpdateItemOutput, __MetadataBearer {}
declare const UpdateItemCommand_base: {
  new (
    input: UpdateItemCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    UpdateItemCommandInput,
    UpdateItemCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: UpdateItemCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    UpdateItemCommandInput,
    UpdateItemCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class UpdateItemCommand extends UpdateItemCommand_base {
  protected static __types: {
    api: {
      input: UpdateItemInput;
      output: UpdateItemOutput;
    };
    sdk: {
      input: UpdateItemCommandInput;
      output: UpdateItemCommandOutput;
    };
  };
}
