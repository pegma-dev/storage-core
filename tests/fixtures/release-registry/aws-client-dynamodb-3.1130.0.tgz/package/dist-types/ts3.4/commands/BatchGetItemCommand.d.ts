import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { BatchGetItemInput, BatchGetItemOutput } from "../models/models_0";
export { __MetadataBearer };
export interface BatchGetItemCommandInput extends BatchGetItemInput {}
export interface BatchGetItemCommandOutput extends BatchGetItemOutput, __MetadataBearer {}
declare const BatchGetItemCommand_base: {
  new (
    input: BatchGetItemCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    BatchGetItemCommandInput,
    BatchGetItemCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: BatchGetItemCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    BatchGetItemCommandInput,
    BatchGetItemCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class BatchGetItemCommand extends BatchGetItemCommand_base {
  protected static __types: {
    api: {
      input: BatchGetItemInput;
      output: BatchGetItemOutput;
    };
    sdk: {
      input: BatchGetItemCommandInput;
      output: BatchGetItemCommandOutput;
    };
  };
}
