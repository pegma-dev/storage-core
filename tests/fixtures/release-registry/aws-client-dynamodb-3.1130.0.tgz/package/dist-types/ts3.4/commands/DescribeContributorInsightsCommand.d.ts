import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DescribeContributorInsightsInput,
  DescribeContributorInsightsOutput,
} from "../models/models_0";
export { __MetadataBearer };
export interface DescribeContributorInsightsCommandInput extends DescribeContributorInsightsInput {}
export interface DescribeContributorInsightsCommandOutput
  extends DescribeContributorInsightsOutput, __MetadataBearer {}
declare const DescribeContributorInsightsCommand_base: {
  new (
    input: DescribeContributorInsightsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeContributorInsightsCommandInput,
    DescribeContributorInsightsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeContributorInsightsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeContributorInsightsCommandInput,
    DescribeContributorInsightsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeContributorInsightsCommand extends DescribeContributorInsightsCommand_base {
  protected static __types: {
    api: {
      input: DescribeContributorInsightsInput;
      output: DescribeContributorInsightsOutput;
    };
    sdk: {
      input: DescribeContributorInsightsCommandInput;
      output: DescribeContributorInsightsCommandOutput;
    };
  };
}
