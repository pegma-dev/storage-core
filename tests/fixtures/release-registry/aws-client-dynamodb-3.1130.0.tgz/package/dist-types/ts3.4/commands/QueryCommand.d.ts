import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { QueryInput, QueryOutput } from "../models/models_0";
export { __MetadataBearer };
export interface QueryCommandInput extends QueryInput {}
export interface QueryCommandOutput extends QueryOutput, __MetadataBearer {}
declare const QueryCommand_base: {
  new (
    input: QueryCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    QueryCommandInput,
    QueryCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: QueryCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    QueryCommandInput,
    QueryCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class QueryCommand extends QueryCommand_base {
  protected static __types: {
    api: {
      input: QueryInput;
      output: QueryOutput;
    };
    sdk: {
      input: QueryCommandInput;
      output: QueryCommandOutput;
    };
  };
}
