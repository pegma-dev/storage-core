import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { ListContributorInsightsInput, ListContributorInsightsOutput } from "../models/models_0";
export { __MetadataBearer };
export interface ListContributorInsightsCommandInput extends ListContributorInsightsInput {}
export interface ListContributorInsightsCommandOutput
  extends ListContributorInsightsOutput, __MetadataBearer {}
declare const ListContributorInsightsCommand_base: {
  new (
    input: ListContributorInsightsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    ListContributorInsightsCommandInput,
    ListContributorInsightsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [ListContributorInsightsCommandInput]
  ): import("@smithy/core/client").CommandImpl<
    ListContributorInsightsCommandInput,
    ListContributorInsightsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class ListContributorInsightsCommand extends ListContributorInsightsCommand_base {
  protected static __types: {
    api: {
      input: ListContributorInsightsInput;
      output: ListContributorInsightsOutput;
    };
    sdk: {
      input: ListContributorInsightsCommandInput;
      output: ListContributorInsightsCommandOutput;
    };
  };
}
