import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { UpdateTableInput, UpdateTableOutput } from "../models/models_0";
export { __MetadataBearer };
export interface UpdateTableCommandInput extends UpdateTableInput {}
export interface UpdateTableCommandOutput extends UpdateTableOutput, __MetadataBearer {}
declare const UpdateTableCommand_base: {
  new (
    input: UpdateTableCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    UpdateTableCommandInput,
    UpdateTableCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: UpdateTableCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    UpdateTableCommandInput,
    UpdateTableCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class UpdateTableCommand extends UpdateTableCommand_base {
  protected static __types: {
    api: {
      input: UpdateTableInput;
      output: UpdateTableOutput;
    };
    sdk: {
      input: UpdateTableCommandInput;
      output: UpdateTableCommandOutput;
    };
  };
}
