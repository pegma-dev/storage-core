import { _ep2, _mw0, command } from "../commandBuilder";
import { DescribeContributorInsights$ } from "../schemas/schemas_0";
export class DescribeContributorInsightsCommand extends command(_ep2, _mw0, "DescribeContributorInsights", DescribeContributorInsights$) {
}
