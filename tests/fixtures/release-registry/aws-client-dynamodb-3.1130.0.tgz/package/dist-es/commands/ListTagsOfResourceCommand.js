import { _ep5, _mw0, command } from "../commandBuilder";
import { ListTagsOfResource$ } from "../schemas/schemas_0";
export class ListTagsOfResourceCommand extends command(_ep5, _mw0, "ListTagsOfResource", ListTagsOfResource$) {
}
