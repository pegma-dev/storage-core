import { _ep8, _mw0, command } from "../commandBuilder";
import { ListExports$ } from "../schemas/schemas_0";
export class ListExportsCommand extends command(_ep8, _mw0, "ListExports", ListExports$) {
}
