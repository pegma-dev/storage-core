import { _ep2, _mw0, command } from "../commandBuilder";
import { ListContributorInsights$ } from "../schemas/schemas_0";
export class ListContributorInsightsCommand extends command(_ep2, _mw0, "ListContributorInsights", ListContributorInsights$) {
}
