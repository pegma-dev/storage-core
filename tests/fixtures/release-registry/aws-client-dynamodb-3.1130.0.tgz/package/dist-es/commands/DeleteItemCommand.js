import { _ep2, _mw0, command } from "../commandBuilder";
import { DeleteItem$ } from "../schemas/schemas_0";
export class DeleteItemCommand extends command(_ep2, _mw0, "DeleteItem", DeleteItem$) {
}
