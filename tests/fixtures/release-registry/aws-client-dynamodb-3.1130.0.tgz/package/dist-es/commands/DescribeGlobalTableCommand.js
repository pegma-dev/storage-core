import { _ep3, _mw0, command } from "../commandBuilder";
import { DescribeGlobalTable$ } from "../schemas/schemas_0";
export class DescribeGlobalTableCommand extends command(_ep3, _mw0, "DescribeGlobalTable", DescribeGlobalTable$) {
}
