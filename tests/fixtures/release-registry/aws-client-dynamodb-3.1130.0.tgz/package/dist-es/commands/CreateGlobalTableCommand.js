import { _ep3, _mw0, command } from "../commandBuilder";
import { CreateGlobalTable$ } from "../schemas/schemas_0";
export class CreateGlobalTableCommand extends command(_ep3, _mw0, "CreateGlobalTable", CreateGlobalTable$) {
}
