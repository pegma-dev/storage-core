import { _ep2, _mw0, command } from "../commandBuilder";
import { DeleteTable$ } from "../schemas/schemas_0";
export class DeleteTableCommand extends command(_ep2, _mw0, "DeleteTable", DeleteTable$) {
}
