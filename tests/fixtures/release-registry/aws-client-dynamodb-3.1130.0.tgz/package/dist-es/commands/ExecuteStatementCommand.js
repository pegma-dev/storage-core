import { _ep0, _mw0, command } from "../commandBuilder";
import { ExecuteStatement$ } from "../schemas/schemas_0";
export class ExecuteStatementCommand extends command(_ep0, _mw0, "ExecuteStatement", ExecuteStatement$) {
}
