import { _ep2, _mw0, command } from "../commandBuilder";
import { UpdateTableReplicaAutoScaling$ } from "../schemas/schemas_0";
export class UpdateTableReplicaAutoScalingCommand extends command(_ep2, _mw0, "UpdateTableReplicaAutoScaling", UpdateTableReplicaAutoScaling$) {
}
