import { _ep9, _mw0, command } from "../commandBuilder";
import { ImportTable$ } from "../schemas/schemas_0";
export class ImportTableCommand extends command(_ep9, _mw0, "ImportTable", ImportTable$) {
}
