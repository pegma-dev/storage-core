import { _ep0, _mw0, command } from "../commandBuilder";
import { ListGlobalTables$ } from "../schemas/schemas_0";
export class ListGlobalTablesCommand extends command(_ep0, _mw0, "ListGlobalTables", ListGlobalTables$) {
}
