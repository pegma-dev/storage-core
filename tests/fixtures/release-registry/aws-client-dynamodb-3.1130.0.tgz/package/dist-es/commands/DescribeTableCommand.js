import { _ep2, _mw0, command } from "../commandBuilder";
import { DescribeTable$ } from "../schemas/schemas_0";
export class DescribeTableCommand extends command(_ep2, _mw0, "DescribeTable", DescribeTable$) {
}
