import { _ep5, _mw0, command } from "../commandBuilder";
import { GetResourcePolicy$ } from "../schemas/schemas_0";
export class GetResourcePolicyCommand extends command(_ep5, _mw0, "GetResourcePolicy", GetResourcePolicy$) {
}
