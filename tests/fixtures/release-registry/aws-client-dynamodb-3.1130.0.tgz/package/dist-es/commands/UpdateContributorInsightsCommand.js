import { _ep2, _mw0, command } from "../commandBuilder";
import { UpdateContributorInsights$ } from "../schemas/schemas_0";
export class UpdateContributorInsightsCommand extends command(_ep2, _mw0, "UpdateContributorInsights", UpdateContributorInsights$) {
}
