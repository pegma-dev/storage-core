import { _ep5, _mw0, command } from "../commandBuilder";
import { UntagResource$ } from "../schemas/schemas_0";
export class UntagResourceCommand extends command(_ep5, _mw0, "UntagResource", UntagResource$) {
}
