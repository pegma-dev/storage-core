import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeEndpoints$ } from "../schemas/schemas_0";
export class DescribeEndpointsCommand extends command(_ep0, _mw0, "DescribeEndpoints", DescribeEndpoints$) {
}
