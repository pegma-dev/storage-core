import { _ep2, _mw0, command } from "../commandBuilder";
import { DescribeContinuousBackups$ } from "../schemas/schemas_0";
export class DescribeContinuousBackupsCommand extends command(_ep2, _mw0, "DescribeContinuousBackups", DescribeContinuousBackups$) {
}
