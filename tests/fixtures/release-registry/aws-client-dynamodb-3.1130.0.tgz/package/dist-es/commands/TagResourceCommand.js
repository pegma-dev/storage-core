import { _ep5, _mw0, command } from "../commandBuilder";
import { TagResource$ } from "../schemas/schemas_0";
export class TagResourceCommand extends command(_ep5, _mw0, "TagResource", TagResource$) {
}
