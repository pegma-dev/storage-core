import { _ep2, _mw0, command } from "../commandBuilder";
import { PutItem$ } from "../schemas/schemas_0";
export class PutItemCommand extends command(_ep2, _mw0, "PutItem", PutItem$) {
}
