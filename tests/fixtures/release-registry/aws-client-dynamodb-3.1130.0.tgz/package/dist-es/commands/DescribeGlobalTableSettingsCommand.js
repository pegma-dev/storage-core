import { _ep3, _mw0, command } from "../commandBuilder";
import { DescribeGlobalTableSettings$ } from "../schemas/schemas_0";
export class DescribeGlobalTableSettingsCommand extends command(_ep3, _mw0, "DescribeGlobalTableSettings", DescribeGlobalTableSettings$) {
}
