import { _ep3, _mw0, command } from "../commandBuilder";
import { UpdateGlobalTableSettings$ } from "../schemas/schemas_0";
export class UpdateGlobalTableSettingsCommand extends command(_ep3, _mw0, "UpdateGlobalTableSettings", UpdateGlobalTableSettings$) {
}
