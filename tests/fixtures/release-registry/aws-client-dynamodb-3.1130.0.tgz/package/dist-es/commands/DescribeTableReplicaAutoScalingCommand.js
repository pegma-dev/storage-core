import { _ep2, _mw0, command } from "../commandBuilder";
import { DescribeTableReplicaAutoScaling$ } from "../schemas/schemas_0";
export class DescribeTableReplicaAutoScalingCommand extends command(_ep2, _mw0, "DescribeTableReplicaAutoScaling", DescribeTableReplicaAutoScaling$) {
}
