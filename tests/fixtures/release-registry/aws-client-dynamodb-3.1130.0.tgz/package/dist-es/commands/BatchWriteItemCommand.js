import { _ep1, _mw0, command } from "../commandBuilder";
import { BatchWriteItem$ } from "../schemas/schemas_0";
export class BatchWriteItemCommand extends command(_ep1, _mw0, "BatchWriteItem", BatchWriteItem$) {
}
